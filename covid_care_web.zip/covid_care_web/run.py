from app import app
# from flask_socketio import SocketIO, send, emit
# socketio = SocketIO( app )
if __name__ == "__main__":
	app.run()
    # app.run(debug = True,host='192.168.0.104')
    # app.run(debug = True)
    # socketio.run( app, debug = True )