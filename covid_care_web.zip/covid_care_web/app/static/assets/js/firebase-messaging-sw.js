importScripts('https://www.gstatic.com/firebasejs/8.6.8/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.6.8/firebase-messaging.js');

var firebaseConfig = {
    apiKey: "AIzaSyDYDi4W95SO5TzDQYPOOEfTSkeAmbaqxz0",
    authDomain: "covid-care-311005.firebaseapp.com",
    databaseURL: "https://covid-care-311005-default-rtdb.firebaseio.com",
    projectId: "covid-care-311005",
    storageBucket: "covid-care-311005.appspot.com",
    messagingSenderId: "772975492563",
    appId: "1:772975492563:web:a484a5e72a771c61a5c326"
};

firebase.initializeApp(firebaseConfig);
const messaging=firebase.messaging();

messaging.setBackgroundMessageHandler(function (payload) {
    console.log(payload);
    const notification=JSON.parse(payload);
    const notificationOption={
        body:notification.body,
        icon:notification.icon
    };
    return self.registration.showNotification(payload.notification.title,notificationOption);
});