from app import app
# import pyrebase
from flask import Flask, render_template, url_for,Response, request,flash, redirect,jsonify, url_for,session,escape
import os
import time, threading
from datetime import datetime,timedelta,date
# import datetime
import numpy as np
from covid_care_db import Db
from build_query import insert_query,update_query,select_query
import json
from flask_restful import Resource, Api, reqparse
from flask_cors import CORS,cross_origin
# from flask_moment import Moment
from werkzeug.utils import secure_filename
import uuid
import requests
from flask_session import Session
from cryptography.fernet import Fernet
import uuid
import math, random
# pip install twilio
# from twilio.rest import Client
# from flask_socketio import SocketIO, send, emit
import sqlite3
from sqlite3 import Error
import secrets
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from apscheduler.schedulers.background import BackgroundScheduler
# import hashlib
# from codeforces import api
# the following line needs your Twilio Account SID and Auth Token
# client = Client("ACdddae55deb998832b70b8c1239255751", "bcd140ac72427768f386f30ef55daa3e")

# from flask_talisman import Talisman, ALLOW_FROM

UPLOAD_FOLDER = '/uploads'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg'])
ALLOWED_PDFEXTENSIONS = set(['pdf'])
ALLOWED_PPTEXTENSIONS = set(['pptx','ppt'])
# Ctrl + k +1 folding
admin_id = 1

db=Db()
db.createDb()
# app = Flask(__name__)
# moment = Moment(app)
cors = CORS(app)
app.config["SECRET_KEY"] =secrets.token_urlsafe(16)
app.config.update(SESSION_COOKIE_NAME='some_new_name_bscow')
# app.secret_key = 'super secret key'
# app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'
# app.config['SESSION_TYPE'] = 'filesystem'
app.config["SESSION_PERMANENT"] = False
app.config['SESSION_TYPE'] = 'filesystem'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['CORS_HEADERS'] = 'Content-Type'
Session(app)
api = Api(app)

# // Your web app's Firebase configuration
# firebaseConfig = {
#     'apiKey': "AIzaSyDYDi4W95SO5TzDQYPOOEfTSkeAmbaqxz0",
#     'authDomain': "covid-care-311005.firebaseapp.com",
#     'databaseURL': "https://covid-care-311005-default-rtdb.firebaseio.com",
#     'projectId': "covid-care-311005",
#     'storageBucket': "covid-care-311005.appspot.com",
#     'messagingSenderId': "772975492563",
#     'appId': "1:772975492563:web:6978816eb93362c7a5c326"
#   }
#   # // Initialize Firebase
# firebase=pyrebase.initialize_app(firebaseConfig)
# auth=firebase.auth()
# help(auth)

from os import listdir
import firebase_admin
from firebase_admin import credentials
from firebase_admin import auth
from firebase_admin import messaging
cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred)

# user = auth.create_user(email ="1234569@gmail.com",password = "12345678")

# print(user.uid)

# user = auth.update_user(user.uid,password='new_password')
# print(user.uid)

limiter = Limiter(
    app,
    key_func=get_remote_address
)
def next_class_alert():
    """ Function for test purposes. """
    print("Scheduler is alive!")
    cltiml=time.time()+86400
    cltimm=time.time()+87000
    columns=" tc.class_titel,tt.user_id,tncd.next_class_date_id,tncd.class_time,tncd.msg_send"
    where_stetment="tncd.status = '1' and tncd.class_time >= '"+str(cltiml)+"' and tncd.class_time <= '"+str(cltiml)+"' "
    
    join_query="tblNextClassDate as tncd "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblClass as tc ON tc.class_id = tncd.class_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblCourse as tco ON tco.course_id = tc.course_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblTeacher as tt ON tt.teacher_id = tco.teacher_id "
    query=select_query(join_query,columns,where_stetment)    
    next_classes_teacher = db.get_data(query)

    cltiml=time.time()+1800
    cltimm=time.time()+2400
    columns=" tc.class_titel,ts.user_id,tncd.next_class_date_id,tncd.class_time,tncd.msg_send"
    where_stetment="tncd.status = '1' and tncd.class_time >= '"+str(cltiml)+"' and tncd.class_time <= '"+str(cltiml)+"' group by tsq.student_id"
    
    join_query="tblNextClassDate as tncd "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblClass as tc ON tc.class_id = tncd.class_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblStudentQuestion as tsq ON tsq.class_id = tncd.class_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblStudent as ts ON ts.student_id = tsq.student_id "
    query=select_query(join_query,columns,where_stetment)    
    next_classes_student = db.get_data(query)

# sched = BackgroundScheduler(daemon=True)
# sched.add_job(next_class_alert,'interval',minutes=1)
# sched.start()
# socketio = SocketIO( app )
# socket_users = {}

users = {}
def secret_key_setup():
    app.secret_key = os.urandom(32)
    # print(app.secret_key)

def account_balance_insert(user_id):
    db = Db()
    
    columns="account_balance_id"
    where_stetment="user_id = '"+str(user_id)+"' "   
    query=select_query("tblAccountBalance",columns,where_stetment)                    
    search = db.get_data_by_key(query)
    if search == None:

        column_names=['user_id',
                        'received',
                        'pay',
                        'update_date',
                        'status']
        values=[str(user_id),
                '0',
                '0',
                str(time.time()),
                '1']
        query=insert_query("tblAccountBalance",column_names,values,"account_balance_id")
        # print(query)
        account_balance_id = db.insert_data(query)

def app_setup():
    try:
        columns="user_id"
        where_stetment="status = '1' AND phone_number = '01718057283'"
        query=select_query("tblUser",columns,where_stetment)
        # print(query)
        db=Db()
        login_data = db.get_data_by_key(query)
        # print(login_data)        
        
        if login_data == None:
            column_names=['key',
                'ciphered_text',
                'auth_id',
                'phone_number',
                'phone_number_verified',
                'name',
                'gender',
                'profile_pic',
                'district',
                'town',
                'village',
                'home_longitude',
                'home_latitude',
                'ofice_longitude',
                'ofice_latitude',
                'fbuid',
                'create_date',
                'status']
            values=['','','','','1','','','','','','','0','0','0','0','fbuid',str(time.time()),'1']
                                               
            phone =  "01718057283"
            values[3]=phone
            password = 'admin123'
            values[5] = 'root admin'
            values[6] = 'পুরুষ'
            values[8] = 'Jhenaidah'
            values[9] = 'Harinakunda'
            values[10] = 'Boalia'
           
            
            key = Fernet.generate_key()
            cipher_suite = Fernet(key)
            # print(password.encode('ASCII'))
            ciphered_text = cipher_suite.encrypt(password.encode('ASCII'))   #required to be bytes
            # auth_id = uuid.uuid4()
            values[0]= key.decode('ASCII')
            values[1] = ciphered_text.decode('ASCII')
            values[2] = str(uuid.uuid4())

            email = phone+"@gmail.com"            
            
            try:
                user = auth.create_user(email =email,password = password)
            except Exception as e:
                user = auth.get_user_by_email(email)

            # print(user.uid)
            values[15] = user.uid

              
            # column_names[1]=session['user']['localId']
            query=insert_query("tblUser",column_names,values,"user_id")
            # print(query)
            user_id = db.insert_data(query)

            column_names=['user_id',
                        'admin_type',
                        'access',
                        'create_date',
                        'security_key',
                        'status']
            values=[str(user_id),
                        'root admin',
                        '1',
                        str(time.time()),
                        'security_key',
                        '1']


            security_key =str(len(values[0])+len(values[1])+len(values[2])+len(values[3])+len(values[5]))
            ciphered_key = cipher_suite.encrypt(security_key.encode('ASCII'))   #required to be bytes
           
            values[4] = ciphered_key.decode('ASCII')

            query=insert_query("tblAdmin",column_names,values,"admin_id")
            # print(query)
            admin_id = db.insert_data(query)
            # secret_key_setup()
            account_balance_insert(user_id)

    except Exception as e:
        print(e)
        pass
 

app_setup()
def authentication():
    try:
        if session['user'] == None:
            session['login'] =False
            return False
        elif session['login']==False:
            session['user'] =None
            return False
        elif session['user'][3] == 0:
            return False

    except Exception as e:
        session['login'] =False
        session['user'] = None
        session['login_user']=['',0,0,0]
        print("except:authentication")
        return False

    return True
    
# function to generate OTP 
def generateOTP() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
  
   # length of password can be chaged 
   # by changing value in range 
    for i in range(4) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP
def generateCode() : 
  
    # Declare a digits variable   
    # which stores all digits  
    digits = "0123456789"
    OTP = "" 
  
   # length of password can be chaged 
   # by changing value in range 
    for i in range(6) : 
        OTP += digits[math.floor(random.random() * 10)] 
  
    return OTP

def get_user_id():
    try:
        return session['login_user'][3]
    except Exception as e:
        redirect(url_for('login'))
        return 0

def rmqt(data):
    data=data.replace("'", "''")
    data=data.replace('"', '""')
    # print(data)
    return data

@app.teardown_appcontext
def close_connection(exception):
    # pass
    db = Db()
    if db is not None:
        db.close_db()
        print("close db")

       
def load_medicine():
    db = Db()
    i =1
    for filename in listdir("data/plaintext"):
        path = "data/plaintext/"+ filename
        with open(path) as file_in:
            medicine = []
            for line in file_in:
                line=line.rstrip()
                if len(line)<1:
                    if len(medicine)>=4:
                        # add madicine....
                        if len(medicine)==5:
                            brand_medicine_name = rmqt(medicine[0])
                            strength = medicine[1]
                            medicine_dosage_form = medicine[2]
                            generic_medicine_name = rmqt(medicine[3])
                            brand_name = rmqt(medicine[4])
                        else:
                            brand_medicine_name = rmqt(medicine[0])
                            strength = '00'
                            medicine_dosage_form = medicine[1]
                            generic_medicine_name = rmqt(medicine[2])
                            brand_name = rmqt(medicine[3])


                        columns="medicine_id"
                        where_stetment="generic_medicine_name = '"+generic_medicine_name+"' AND brand_medicine_name = '"+brand_medicine_name+"' AND strength = '"+strength+"'  AND medicine_dosage_form = '"+medicine_dosage_form+"' "  
                        query=select_query("tblMedicine",columns,where_stetment)                    
                        search = db.get_data_by_key(query)
                        if search == None:

                            column_names=['generic_medicine_name',
                                            'brand_medicine_name',
                                            'medicine_dosage_form',
                                            'strength',
                                            'brand_name',
                                            'status']
                            values=[generic_medicine_name,
                                    brand_medicine_name,
                                    medicine_dosage_form,
                                    strength,
                                    brand_name,
                                    '1']
                            query=insert_query("tblMedicine",column_names,values,"medicine_id")
                            # print(query)
                            medicine_id = db.insert_data(query)
                    medicine = []
                else:
                    medicine.append(line)

            break
# load_medicine()
@app.route("/")
@app.route("/index")
def index():
    # db=Db() 

    # columns=" ts.*, COUNT(tco.course_id)"    
    # where_stetment="ts.status = '1'   group by ts.subject_id"   
    # join_query="tblSubject as ts "
    # join_query=join_query+"LEFT JOIN "
    # join_query=join_query+"tblCourse as tco ON tco.subject_id = ts.subject_id and tco.course_verification = '1' "
    # query=select_query(join_query,columns,where_stetment)                    
    # subjects = db.get_data(query)

    # columns=" tco.*,array_agg(DISTINCT tu.user_id),array_agg(DISTINCT tu.profile_pic),SUM(tcr.rating1),SUM(tcr.rating2),SUM(tcr.rating3),SUM(tcr.rating4),SUM(tcr.rating5),COUNT(tc.class_id) "    
    # where_stetment="tco.status = '1' and tco.course_verification = '1'  group BY tco.course_id  ORDER BY tco.course_id DESC LIMIT 9  OFFSET 0"    
    # join_query="tblCourse as tco "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblTeacher as tt ON tt.teacher_id = tco.teacher_id "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblUser as tu ON tu.user_id = tt.user_id "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblClass as tc ON tc.course_id = tco.course_id "
    # join_query=join_query+"LEFT JOIN "
    # join_query=join_query+"tblClassRating as tcr ON tcr.class_id = tc.class_id "
    # query=select_query(join_query,columns,where_stetment)                    
    # courses = db.get_data(query)


    # columns=" tta.your_duty,tu.user_id,tu.name,tu.profile_pic,tta.skill "    
    # where_stetment="tta.status = '1' AND tta.accepted = '1' ORDER BY tta.create_date DESC LIMIT 9  OFFSET 0"    
    # join_query="tblTeacherApplication as tta "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblUser as tu ON tu.user_id = tta.user_id "
    # query=select_query(join_query,columns,where_stetment)                    
    # teachers = db.get_data(query)

    return render_template('index.html', title='Covid Care',subjects=[],courses=[],teachers=[])

@app.route("/contact", methods=['GET', 'POST'])
def contact():
    return render_template('contact.html',title='Contact')

@app.route("/user_report", methods=['GET', 'POST'])
def user_report():
    return render_template('user_report.html',title='User Report')

@app.route("/about_us")
def about_us():
    return render_template('about_us.html',title='Contact')

@app.route("/categories")
def categories():
    
    return render_template('categories.html')


@app.route("/video_recorder")
def video_recorder():
    # insert_query("tbl",['a','b'],['1','2'])
    if authentication()==False:
        return render_template('index.html')
    return render_template('video_recorder.html')


@app.route("/password_recover", methods=['GET', 'POST'])
def password_recover():
    
    first_time=0
    phone_number=''
                  
    if request.method == 'POST':

        if request.form['action']=="submit":

            # try:   
            verification_code = request.form['verification_code']
            phone_number = request.form['phone_number']
            password = request.form['password']
            repassword = request.form['repassword']
            if (time.time() - session[phone_number][1])>150:
                flash("সময় শেষ, অনুগ্রহ করে যাচাইকরণ কোডটি আবার প্রেরণ করুন।")
            elif verification_code == session[phone_number][0]:
                # Update database........here....
                if password == repassword:
                    key = Fernet.generate_key()
                    cipher_suite = Fernet(key)
                    # print(password.encode('ASCII'))
                    ciphered_text = cipher_suite.encrypt(password.encode('ASCII'))   #required to be bytes
                    
                    column_names=['key','ciphered_text']
                    values=[key.decode('ASCII'),ciphered_text.decode('ASCII')]

                    where_stetment = "phone_number = '"+str(phone_number)+"'"
                    query=update_query("tblUser",column_names,values,where_stetment)
                    # print(query)
                    db=Db()
                    res = db.update_data(query)
                    # print(res)
                    if res:                        
                        return redirect(url_for('login'))
                    else:
                        flash('যাচাই ব্যর্থ হয়েছে। আবার চেষ্টা করুন।')
                
            else:
                flash('যাচাই ব্যর্থ হয়েছে। আবার চেষ্টা করুন।')

        elif request.form['action']=="resend":
            phone_number = request.form['phone_number']
            flg=True
            try:
                if (time.time() - session[phone_number][1])<150:
                    flash('যাচাইকরণ কোডটি ইতোমধ্যে আপনার ফোনে প্রেরণ করা হয়েছে। নতুন কোডের জন্য কয়েক মিনিটের পরে চেষ্টা করুন।')
                    flg = False
                elif session[phone_number][2]>3:
                    if (time.time() - session[phone_number][1])>500:
                        session[phone_number]=['vcode@',time.time(),0]
                    else:
                        flash("কয়েক মিনিট পরে চেষ্টা করুন।")
                        flg = False
            except Exception as e:
                session[phone_number]=['vcode@',time.time(),0]

            if flg == True:
                vcode =generateCode()
                if send_code(phone_number,vcode)==1:
                    session[phone_number]=[vcode,time.time(),(session[phone_number][2]+1)]
    
    

    return render_template('password_recover.html',title='Password Recover',phone_number=phone_number)

@app.route("/phone_verification", methods=['GET', 'POST'])
def phone_verification():

    if session['login']==False:
        return redirect(url_for('login'))

    first_time=0
    if session['user'][3] == 0:
        # print("request",request.method)                
        if request.method == 'POST':

            if request.form['action']=="submit":

                # try:   
                verification_code = request.form['verification_code']
                # print((time.time() - session['OTP'][1]))
                if (time.time() - session['OTP'][1])>100:
                    flash("সময় শেষ, অনুগ্রহ করে যাচাইকরণ কোডটি আবার প্রেরণ করুন।")
                elif verification_code == session['OTP'][0]:
                    # Update database........here....
                    column_names=['phone_number_verified']
                    values=['1']
                    where_stetment = 'user_id = '+str(session['user'][0])
                    query=update_query("tblUser",column_names,values,where_stetment)
                    # print(query)
                    db=Db()
                    res = db.update_data(query)
                    if res:
                        # flash('Verification successfully')
                        lst=list(session['user'])
                        lst[3]=1
                        session['user'] = tuple(lst)
                        return redirect(url_for('index'))
                    else:
                        flash('যাচাই ব্যর্থ হয়েছে। আবার চেষ্টা করুন।')
                    
                else:
                    flash('যাচাই ব্যর্থ হয়েছে। আবার চেষ্টা করুন।')

            elif request.form['action']=="resend":

                flg=True
                try:
                    if (time.time() - session['OTP'][1])<100:
                        flash('যাচাইকরণ কোডটি ইতোমধ্যে আপনার ফোনে প্রেরণ করা হয়েছে। নতুন কোডের জন্য কয়েক মিনিটের পরে চেষ্টা করুন।')
                        flg = False
                    elif session['OTP'][2]>3:
                        if (time.time() - session['OTP'][1])>500:
                            session['OTP']=['OTP@',time.time(),0]
                        else:
                            flash("কয়েক মিনিট পরে চেষ্টা করুন।")
                            flg = False
                except Exception as e:
                    session['OTP']=['OTP@',time.time(),0]

                if flg == True:
                    OTP =generateOTP()
                    if send_code(session['user'][2],OTP)==1:
                        session['OTP']=[OTP,time.time(),(session['OTP'][2]+1)]
        else:
            try:
                session['OTP'][1]
            except Exception as e:
                session['OTP']=['OTP@',time.time(),0]
                first_time=1
    else:
        # print("index...")
        return redirect(url_for('index'))

    return render_template('phone_verification.html',title='Phone Verification')

def send_code(to,OTP):

    YOUR_API_USERNAME="shahin198"
    YOUR_API_HASH_TOKEN = "6b0f49678d2d1e183f48aeb5280938bc"
    # to="01718057283"
    msg = "ডেইলি কেয়ারে আপনার ফোন যাচাইকরণ কোড হলঃ "+OTP

    response = requests.get("http://alphasms.biz/index.php?app=ws&u="+YOUR_API_USERNAME+"&h="+YOUR_API_HASH_TOKEN+"&op=pv&to="+to+"&msg="+msg)
    # print(response)
    # flash(response.status_code)
    if response.status_code == 200:
        return 1

    return 0

def call_api(to,msg):
    YOUR_API_USERNAME="shahin198"
    YOUR_API_HASH_TOKEN = "6b0f49678d2d1e183f48aeb5280938bc"
    try:
        response = requests.get("http://alphasms.biz/index.php?app=ws&u="+YOUR_API_USERNAME+"&h="+YOUR_API_HASH_TOKEN+"&op=pv&to="+to+"&msg="+msg)
        
    except Exception as e:
        pass

def send_mobile_msg(to,msg):

    
    # to="01718057283"
    # msg = "Verification form Covid-19 health care. Your OTP is "+OTP
    # http://alphasms.biz/index.php?app=ws&u=shahin198&h=6b0f49678d2d1e183f48aeb5280938bc&op=pv&to=01817867007&msg=msg
    # url="http://alphasms.biz/index.php?app=ws&u="+YOUR_API_USERNAME+"&h="+YOUR_API_HASH_TOKEN+"&op=pv&to="+to+"&msg="+msg
    threading.Thread(target=call_api, args=(to,msg)).start()

    return 0

def send_mobile_msg_by_user_id(user_id,msg,db):
    
    columns="phone_number"
    where_stetment="user_id = '"+str(user_id)+"' " 
    query=select_query("tblUser",columns,where_stetment)                    
    phone_number = db.get_data_by_key(query)
    send_mobile_msg(phone_number[0],msg)

def token_maching(c_token):
    
    if c_token==session['token'][0]:
        return True
    else:
        return False

class FCMApi(Resource):
    def get(self):
        code =200
        if authentication()==False:
            return {'login': None}, code
        
        return {'login': session['login_user']}, code

    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        
        db=Db()
        
        if args['method']=='post':

            patient_id =  data['patient_id']

            columns=" tu.auth_id  "    
            where_stetment="tcp.patient_id = '"+str(patient_id)+"' "
            join_query="tblPatient as tcp "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = tcp.user_id "
            query=select_query(join_query,columns,where_stetment)        
            search = db.get_data_by_key(query)
            # print("sss",login_data)
            if search != None:
                # [START send_to_token]
               
                # See documentation on defining a message payload.
                # message = messaging.Message(
                #     data={
                #         'title': '850',
                #         'body': '2:45',
                #         'icon': 'icon',
                #         'meetingId': '2:45',
                #     },
                #     token=auth_id,
                # )
                room_name = str(uuid.uuid4())

                message = messaging.Message(
                    android=messaging.AndroidConfig(
                        ttl=timedelta(seconds=3600),
                        priority='normal',
                        notification=messaging.AndroidNotification(
                            title='Doctor Calling',
                            body='Click here for attend call.',
                            icon='icon',
                            color='#f45342',
                            room_name=room_name
                        ),
                    ),
                    token=search[0],
                )

                # Send a message to the device corresponding to the provided
                # registration token.
                response = messaging.send(message)
                # Response is a message ID string.
                print('Successfully sent message:', response)
                # [END send_to_token]
                return {'room_name': room_name}, 200

                
        return {'room_name': None}, 200

    
api.add_resource(FCMApi, '/fbcm_api')

def android_message():
    # [START android_message]
    message = messaging.Message(
        android=messaging.AndroidConfig(
            ttl=datetime.timedelta(seconds=3600),
            priority='normal',
            notification=messaging.AndroidNotification(
                title='$GOOG up 1.43% on the day',
                body='$GOOG gained 11.80 points to close at 835.67, up 1.43% on the day.',
                icon='stock_ticker_update',
                color='#f45342'
            ),
        ),
        topic='industry-tech',
    )
    # [END android_message]
    return message


def received_wallet(user_id,amount):
    db=Db()
    columns="received"
    where_stetment="user_id = '"+str(user_id)+"' "  
    query=select_query("tblAccountBalance",columns,where_stetment)                    
    wallet = db.get_data_by_key(query)

    if wallet!=None:
        column_names=['received',
                        'update_date']
        values=[str(wallet[0]+amount),
                str(time.time())]

        where_stetment="user_id = '"+str(user_id)+"'"
        query=update_query("tblAccountBalance",column_names,values,where_stetment)
        # print(query)
    
        res = db.update_data(query)

def pay_wallet(user_id,amount):
    db=Db()
    columns="pay"
    where_stetment="user_id = '"+str(user_id)+"' "  
    query=select_query("tblAccountBalance",columns,where_stetment)                    
    wallet = db.get_data_by_key(query)

    if wallet!=None:
        column_names=['pay',
                        'update_date']
        values=[str(wallet[0]+amount),
                str(time.time())]

        where_stetment="user_id = '"+str(user_id)+"'"
        query=update_query("tblAccountBalance",column_names,values,where_stetment)
        # print(query)
    
        res = db.update_data(query)

@app.route("/logout")
def logout():    
    # session.clear()
    session['user']=None
    session['login'] =False
    session['login_user']=['',0,0,0]
    print("Logout successfully.")
    # flash("Logout successfully.")
    return redirect(url_for('login'))

@app.route("/login", methods=['GET', 'POST'])
def login():
    
    # try:
    #     if session['login']==True:
    #         return redirect(url_for('logout'))
    # except Exception as e:
    #     session['user']=None
    #     session['login'] =False
    #     session['login_user']=['',0,0,0]
    

    if request.method == 'POST':
        
        if request.form['action']=="submit":
            
            # try:   
            phone = request.form['phone']
            password = request.form['password']

            columns="key,ciphered_text,user_id ,auth_id,phone_number,phone_number_verified,name,gender,profile_pic,district,town"
            where_stetment="status = '1' AND phone_number = '"+phone+"'"
            query=select_query("tblUser",columns,where_stetment)
            # print(query)
            db=Db()
            login_data = db.get_data_by_key(query)
            # print("sss",login_data)
            if login_data != None:

                cipher_suite = Fernet(login_data[0].encode('ASCII'))
                unciphered_text = (cipher_suite.decrypt(login_data[1].encode('ASCII')))
                # print(unciphered_text)
                if unciphered_text == password.encode('ASCII'):
                    # print(query)
                    session['key']= login_data[0]
                    session['user'] = login_data[2:]
                    # print(session['user'])
                    session['login'] =True
                    key = str(uuid.uuid4())
                    session['token']=[key,time.time()]
                    
                    # flash('Login successful')

                    columns="admin_type,access"
                    where_stetment="status = '1' AND user_id = '"+str(session['user'][0])+"'"
                    query=select_query("tblAdmin",columns,where_stetment)                    
                    admin_user = db.get_data_by_key(query)
                    if admin_user != None:
                        session['login_user']=[session['user'][4],1,(1+int(admin_user[1])),session['user'][0]]
                        # print(session['login_user'])
                    else:
                        session['login_user']=[session['user'][4],1,0,session['user'][0]]

                    session.modified=True

                    if session['user'][3] == 0:
                        OTP =generateOTP()
                        if send_code(session['user'][2],OTP)==1:
                            session['OTP']=['OTP@',time.time(),0]
                            session['OTP']=[OTP,time.time(),(session['OTP'][2]+1)]
                            
                        return redirect(url_for('phone_verification'))
                    else:
                        return redirect(url_for('doctor_dashboard'))
                else:
                    session['login'] =False
                    session['user'] = None
                    session['login_user']=['',0,0,0]
                    flash("Login failed. Please check your password or phone number")
            else:
                flash("You do not have registered")                    

        else:
            session['user'] =[]

    try:
        if session['login_user']:
            pass
    except Exception as e:
        session['login_user']=['',0,0,0]
    

    
    return render_template('login.html', title='User Login')

class LoginApi(Resource):
    def get(self):
        code =200
        if authentication()==False:
            return {'login': None}, code
        
        return {'login': session['login_user']}, code

    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        
        db=Db()
        
        if args['method']=='post':

            phone = data['phone']
            password = data['password']

            columns="key,ciphered_text,user_id ,auth_id,phone_number,phone_number_verified,name,gender,profile_pic,district,town"
            where_stetment="status = '1' AND phone_number = '"+phone+"'"
            query=select_query("tblUser",columns,where_stetment)
            # print(query)
            db=Db()
            login_data = db.get_data_by_key(query)
            # print("sss",login_data)
            if login_data != None:

                cipher_suite = Fernet(login_data[0].encode('ASCII'))
                unciphered_text = (cipher_suite.decrypt(login_data[1].encode('ASCII')))
                # print(unciphered_text)
                if unciphered_text == password.encode('ASCII'):
                    # print(query)
                    session['key']= login_data[0]
                    session['user'] = login_data[2:]
                    # print(session['user'])
                    session['login'] =True
                    key = str(uuid.uuid4())
                    session['token']=[key,time.time()]
                    
                    # flash('Login successful')

                    columns="admin_type,access"
                    where_stetment="status = '1' AND user_id = '"+str(session['user'][0])+"'"
                    query=select_query("tblAdmin",columns,where_stetment)                    
                    admin_user = db.get_data_by_key(query)
                    if admin_user != None:
                        session['login_user']=[session['user'][4],1,(1+int(admin_user[1])),session['user'][0]]
                        # print(session['login_user'])
                    else:
                        session['login_user']=[session['user'][4],1,0,session['user'][0]]

                    session.modified=True

                    if session['user'][3] == 0:
                        OTP =generateOTP()
                        if send_code(session['user'][2],OTP)==1:
                            session['OTP']=['OTP@',time.time(),0]
                            session['OTP']=[OTP,time.time(),(session['OTP'][2]+1)]
                            
                        return redirect(url_for('phone_verification'))
                    else:
                        return {'login': session['login_user']}, 200
                else:
                    session['login'] =False
                    session['user'] = None
                    session['login_user']=['',0,0,0]
                    flash("Login failed. Please check your password or phone number")
            else:
                flash("You do not have registered")

        return {'flg':0,'user': []}, 200

    
api.add_resource(LoginApi, '/login_api')


@app.route("/login_check", methods=['GET'])
def login_check():
    login=0
    if authentication():
        login=1

    result={"login":login}

    return jsonify(result)

class RefreshTokenApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('c_token', required=True)
        args = parser.parse_args()

        c_token = args['c_token']
        if authentication()==False:
            return {'token': None}, 401

        if token_maching(c_token)==True:
            key = str(uuid.uuid4())
            session['token']=[key,time.time()]
            session.modified=True
            code =200
            return {'token': key}, code

        return {'token': None}, 401
    
api.add_resource(RefreshTokenApi, '/refresh_token_api')

@app.route("/registration", methods=['GET', 'POST'])
def registration():
    db=Db()
    user_id=0
    if request.method == 'POST':
        
        if request.form['action']=="submit":
            # try:
            column_names=['key',
                'ciphered_text',
                'auth_id',
                'phone_number',
                'phone_number_verified',
                'name',
                'gender',
                'profile_pic',
                'district',
                'town',
                'village',
                'home_longitude',
                'home_latitude',
                'ofice_longitude',
                'ofice_latitude',
                'fbuid',
                'create_date',
                'status']
            values=['','','','','0','','','','','','','0','0','0','0','',str(time.time()),'1']
                                               
            phone =  request.form['phone']
            values[3]=phone
            password = request.form['password']
            repassword = request.form['repassword']
            values[5] = request.form['user_name']
            values[6] = request.form['gender']

            columns="user_id"
            where_stetment="phone_number = '"+phone+"' " 
            query=select_query("tblUser",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search != None:
                flash("মোবাইল নম্বরটি ইতোমধ্যে ব্যবহৃত হয়েছে।")
                # return  redirect(url_for('login'))
            elif password == repassword:
                key = Fernet.generate_key()
                cipher_suite = Fernet(key)
                # print(password.encode('ASCII'))
                ciphered_text = cipher_suite.encrypt(password.encode('ASCII'))   #required to be bytes
                # auth_id = uuid.uuid4()
                values[0]= key.decode('ASCII')
                values[1] = ciphered_text.decode('ASCII')
                values[2] = str(uuid.uuid4())

                email = phone+"@gmail.com"

                try:
                    user = auth.create_user(email =email,password = password)
                except Exception as e:
                    user = auth.get_user_by_email(email)
                values[15] = user.uid

                query=insert_query("tblUser",column_names,values,"user_id")
                # print(query)
                user_id = db.insert_data(query)

                account_balance_insert(user_id)
                msg=" আপনাকে ডেইলি কেয়ারে রেজিষ্ট্রেশনের জন্য ধন্যবাদ। বিস্তারিত জানতে ভিজিট করুনঃ http://dailycarebd.com/"
                subject="রেজিস্ট্রেশন"
                send_notification(user_id,subject,msg)
                                
                send_mobile_msg(phone,msg)

                flash('ডেইলি কেয়ারে নিবন্ধন সম্পন্ন হয়েছে।')
            else:
                flash("পাসওয়ার্ড সঠিক নয়।")

    # districts = db.get_all_district()
    return render_template('registration.html', title='User Registration',res_id=user_id)

class RegistrationApi(Resource):
    
        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        
        db=Db()
        
        if args['method']=='post':

            phone_number =  data['phone_number']
            name = data['name']
            gender = data['gender']
            password = data['password']
            rePassword =data['rePassword']
            auth_id =data['auth_id']
            fbuid =data['fbuid']

            if password == rePassword:
                key = Fernet.generate_key()
                cipher_suite = Fernet(key)
                # print(password.encode('ASCII'))
                ciphered_text = cipher_suite.encrypt(password.encode('ASCII'))   #required to be bytes
                # auth_id = uuid.uuid4()
                key= key.decode('ASCII')
                ciphered_text = ciphered_text.decode('ASCII')

            else:
                return {'flg':0,'data': []}, 200

            columns="user_id"
            where_stetment="phone_number = '"+phone_number+"' " 
            query=select_query("tblUser",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['key',
                    'ciphered_text',
                    'auth_id',
                    'phone_number',
                    'phone_number_verified',
                    'name',
                    'gender',
                    'profile_pic',
                    'district',
                    'town',
                    'village',
                    'home_longitude',
                    'home_latitude',
                    'ofice_longitude',
                    'ofice_latitude',
                    'fbuid',
                    'create_date',
                    'status']
                values=[key,ciphered_text,auth_id,phone_number,'0',name,gender,
                '','','','','0','0','0','0',fbuid,str(time.time()),'1']

                query=insert_query("tblUser",column_names,values,"user_id")
                # print(query)
                user_id = db.insert_data(query)

                account_balance_insert(user_id)

                msg=" আপনাকে কোভিড-কেয়ারে রেজিষ্ট্রেশনের জন্য ধন্যবাদ। বিস্তারিত জানতে ভিজিট করুনঃ http://dailycarebd.com/"
                subject="রেজিস্ট্রেশন"
                send_notification(user_id,subject,msg)
                                
                send_mobile_msg(phone_number,msg)
                return {'flg':1,'data': user_id}, 200
            else:
                return {'flg':2,'data': 0}, 200

        elif args['method']=='update':
            user_id = data['user_id']
            profile_pic = data['profile_pic']
                
            if profile_pic!='':
                column_names=['profile_pic']
                values=[profile_pic]
                where_stetment="user_id = '"+str(user_id)+"'"
                query=update_query("tblUser",column_names,values,where_stetment)
                # print(query)
                
                res = db.update_data(query)
                return {'res': res}, 200

        elif args['method']=='phone_verification':

            user_id = data['user_id']

            column_names=['phone_number_verified']
            values=['1']

            where_stetment="user_id = '"+str(user_id)+"'"
            query=update_query("tblUser",column_names,values,where_stetment)
            # print(query)
            
            res = db.update_data(query)
            return {'res': res}, 200

        elif args['method']=='change_password':

            user_id = data['user_id']
            new_password = data['new_password']

            columns="fbuid"
            where_stetment="status = '1' AND user_id = '"+str(user_id)+"' "
            query=select_query("tblUser",columns,where_stetment)

            user_data = db.get_data_by_key(query)

            if user_data != None:
                try:
                    user = auth.update_user(user_data[0],password=new_password)

                    key = Fernet.generate_key()
                    cipher_suite = Fernet(key)
                    # print(password.encode('ASCII'))
                    ciphered_text = cipher_suite.encrypt(new_password.encode('ASCII'))   #required to be bytes
                    
                    column_names=['key','ciphered_text']
                    values=[key.decode('ASCII'),ciphered_text.decode('ASCII')]

                    where_stetment = "user_id = '"+str(user_id)+"'"
                    query=update_query("tblUser",column_names,values,where_stetment)

                    res = db.update_data(query)

                    return {'res': res}, 200

                except:
                    print("Invalid email or password")
                    return {'res': '0'}, 200
                    

        return {'res': msg}, code

api.add_resource(RegistrationApi, '/registration_api')


@app.route("/get_user_data", methods=['GET'])
def get_user_data():

    id = request.args.get('id')
    
    db = Db()


    columns="key,ciphered_text,user_id ,auth_id"
    where_stetment="user_id = '"+str(id)+"' "  
    query=select_query("tblUser",columns,where_stetment)                    
    test_reports = db.get_data(query)

    result={"test_reports":test_reports}
    # print(result)

    return jsonify(result)


@app.route("/patients", methods=['GET', 'POST'])
def patients():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('patients.html', title='patients')


class PatientApi(Resource):
    def get(self):
        parser = reqparse.RequestParser() 
        parser.add_argument('offset', required=True)        
        args = parser.parse_args()
        offset = args['offset']
        msg="unauthorized request"
        code =401
        patients=None
        user_id = get_user_id()
        db=Db()
        
        columns=" tp.*  "    
        where_stetment="tpc.status = '1' and tpc.user_id = '"+str(user_id)+"' ORDER BY tp.create_date DESC LIMIT 10  OFFSET "+offset   
        join_query="tblPatientConnection as tpc "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tpc.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        patients = db.get_data(query)

        code =200

        return {'patients': patients}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        covid_patient=None
        patient_id=0
        

        db=Db()
        user_id = get_user_id()
        if user_id<=0:
            return {'data': []}, code

        if args['method']=='post':
            
            patient_name = data['patient_name']
            age = data['age']
            gender = data['gender']
            hight = data['hight']
            weight = data['weight']
            profile_pic = data['profile_pic']            
            blood_group = data['blood_group']
            district = data['district']
            town = data['town']
            village = data['village']
            phone_number = data['phone_number']

            columns="patient_id"
            where_stetment="phone_number = '"+phone_number+"' AND patient_name = '"+patient_name+"'"   
            query=select_query("tblPatient",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['phone_number',
                                'patient_name',
                                'age',
                                'gender',
                                'hight',
                                'weight',
                                'blood_group',
                                'profile_pic',
                                'district',
                                'town',
                                'village',
                                'create_date',
                                'status']
                values=[phone_number,
                        patient_name,
                        str(age),
                        gender,
                        str(hight),
                        str(weight),
                        blood_group,
                        profile_pic,
                        district,
                        town,
                        village,
                        str(time.time()),
                        '1']
                query=insert_query("tblPatient",column_names,values,"patient_id")
                # print(query)
                patient_id = db.insert_data(query)

                column_names=['user_id',
                                'patient_id',
                                'create_date',
                                'status']
                values=[str(user_id),
                        str(patient_id),
                        str(time.time()),
                        '1']
                query=insert_query("tblPatientConnection",column_names,values,"patient_connection_id")
                # print(query)
                patient_connection_id = db.insert_data(query)

                msg="প্রিয় "+patient_name+" , ডেইলি কেয়ারে যুক্ত হওয়ায় আপনাকে ধন্যবাদ। "
                subject="ডাক্তার অ্যাপয়েন্টমেন্ট "
                send_notification(user_id,subject,msg)
                                
                send_mobile_msg(phone_number,msg)

            else:
                return {'msg':["আপনি ইতিমধ্যে এই রোগীর নাম যুক্ত করেছেন।"],'data': None}, 200

        elif args['method']=='update':

            patient_id = data['patient_id']

            columns="patient_id"
            where_stetment="status = '1' AND user_id = '"+str(user_id)+"' AND patient_id = '"+str(patient_id)+"'"   
            query=select_query("tblPatientConnection",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search != None:

                phone_number = data['phone_number']
                patient_name = data['patient_name']
                age = data['age']
                gender = data['gender']
                hight = data['hight']
                weight = data['weight']
                profile_pic = data['profile_pic']            
                blood_group = data['blood_group']            
                district = data['district']
                town = data['town']
                village = data['village']

                column_names=['phone_number',
                                'patient_name',
                                'age',
                                'gender',
                                'hight',
                                'weight',
                                'district',
                                'town',
                                'village',
                                'blood_group']
                values=[phone_number,
                        patient_name,
                        str(age),
                        gender,
                        str(hight),
                        str(weight),
                        district,
                        town,
                        village,
                        blood_group]

                if profile_pic!="":
                    column_names.append('profile_pic')
                    values.append(profile_pic)
                
                where_stetment="patient_id = '"+str(patient_id)+"'"
                query=update_query("tblPatient",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

        elif args['method']=='patient_connection':

            patient_id = data['patient_id']
            connection_otp = data['connection_otp']
            s_id=str(user_id)+str(patient_id)
            if (time.time() - session[s_id][1])>150:

                return {'flg': 0,'msg':"সময় শেষ, অনুগ্রহ করে যাচাইকরণ কোডটি আবার প্রেরণ করুন।"}, 200

            elif connection_otp == session[s_id][0]:

                columns="patient_connection_id,status"
                where_stetment="user_id = '"+str(user_id)+"' AND patient_id = '"+str(patient_id)+"'  "   
                query=select_query("tblPatientConnection",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search == None:
                    column_names=['user_id',
                                    'patient_id',
                                    'create_date',
                                    'status']
                    values=[str(user_id),
                            str(patient_id),
                            str(time.time()),
                            '1']
                    query=insert_query("tblPatientConnection",column_names,values,"patient_connection_id")
                    # print(query)
                    patient_connection_id = db.insert_data(query)

                    session.pop(s_id, None)

                    return {'flg': 1,'msg':"রোগী সফলভাবে সংযুক্ত হয়েছে।"}, 200

                elif search[1]==0:


                    column_names=['status']

                    values=['1']

                    
                    where_stetment="patient_connection_id = '"+str(search[0])+"'"
                    query=update_query("tblPatientConnection",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)
                    return {'flg': 1,'msg':"রোগী সফলভাবে সংযুক্ত হয়েছে।"}, 200
                    
                return {'flg': 0,'msg':"কিছু ভুল হয়েছে, কিছু সময় পরে আবার চেষ্টা করুন।"}, 200

        elif args['method']=='connection_request':                
            patient_id = data['patient_id']

            columns="phone_number"
            where_stetment="patient_id = '"+str(patient_id)+"' "   
            query=select_query("tblPatient",columns,where_stetment)                    
            search = db.get_data_by_key(query)

            phone_number = search[0]

            s_id=str(user_id)+str(patient_id)

            try:
                if session[s_id] ==None:
                    session[s_id]=[0,0,0]
            except Exception as e:
                session[s_id]=[0,0,0]
            
            if (time.time() - session[s_id][1])<500:

                return {'flg': 1,'msg':"ইতোমধ্যে যাচাইকরণ কোডটি রোগীর মোবাইল নম্বর এ পাঠানো হয়েছে। না পেয়ে থাকলে কিছুখন পর আবার চেষ্টা করুন।"}, 200
            elif (time.time() - session[s_id][1])>500:
                vcode =generateCode()
                if send_code(phone_number,vcode)==1:
                    session[s_id]=[vcode,time.time(),0]
                    return {'flg': 1,'msg':"যাচাইকরণ কোডটি রোগীর মোবাইল নম্বর এ পাঠানো হয়েছে।"}, 200
            elif session[s_id][2]>=3:

                return {'flg': 2,'msg':"কিছু সময় পরে আবার চেষ্টা করুন।"}, 200
            else:
                vcode =generateCode()
                if send_code(phone_number,vcode)==1:
                    session[s_id]=[vcode,time.time(),(session[s_id][2]+1)]
                    return {'flg': 1,'msg':"যাচাইকরণ কোডটি রোগীর মোবাইল নম্বর এ পাঠানো হয়েছে।"}, 200

            return {'flg': 2,'msg':"কিছু ভুল হয়েছে, কিছু সময় পরে আবার চেষ্টা করুন। "}, 200

        elif args['method']=='delete':                
            patient_id = data['patient_id']

            query="DELETE FROM tblPatient WHERE patient_id = '"+str(patient_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        columns="*"
        where_stetment="patient_id = '"+str(patient_id)+"'"  
        query=select_query("tblPatient",columns,where_stetment)                    
        covid_patient = db.get_data_by_key(query)
        code =200               
                    

        return {'data': covid_patient}, code

api.add_resource(PatientApi, '/patient_api')


@app.route("/find_patients_using_phone", methods=['GET'])
def find_patients_using_phone():

    user_id = get_user_id()    
    phone_number = request.args.get('phone')
    db = Db() 
         

    columns=" tcp.*,tpc.patient_connection_id "    
    where_stetment="tcp.phone_number = '"+str(phone_number)+"'  "
    join_query="tblPatient as tcp "
    join_query=join_query+"LEFT JOIN "
    join_query=join_query+"tblPatientConnection as tpc ON tpc.user_id = '"+str(user_id)+"' AND tpc.patient_id = tcp.patient_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    find_patients = db.get_data(query)
    code =200

    result={"find_patients":find_patients}
    

    return jsonify(result)


@app.route("/find_patients_using_patient_id", methods=['GET'])
def find_patients_using_patient_id():
       
    patient_id = request.args.get('id')
    user_id = get_user_id()
    db = Db()

    columns=" tcp.*,tpc.patient_connection_id "    
    where_stetment="tcp.patient_id = '"+str(patient_id)+"'  "
    join_query="tblPatient as tcp "
    join_query=join_query+"LEFT JOIN "
    join_query=join_query+"tblPatientConnection as tpc ON tpc.user_id = '"+str(user_id)+"' AND tpc.patient_id = tcp.patient_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    find_patients = db.get_data(query)
    code =200

    result={"find_patients":find_patients}
    

    return jsonify(result)

@app.route("/get_balance", methods=['GET'])
def get_balance():

    db = Db()
    user_id = get_user_id()
    current_balance=None
    if authentication() == True:        

        columns=" array_agg(DISTINCT tu.current_balance),SUM(COALESCE(tpm.total_bill,0))  "    
        where_stetment="tu.status = '1' and tu.user_id = '"+str(user_id)+"' group BY tpm.user_id "
        join_query="tblUser as tu "
        join_query=join_query+"LEFT JOIN "
        join_query=join_query+"tblPayMoney as tpm ON tu.user_id = tpm.user_id "
        query=select_query(join_query,columns,where_stetment)                    
        current_balance = db.get_data_by_key(query)

    result={"data":current_balance}
    # print(result)

    return jsonify(result)

def is_admin():
    try:
        if session['login_user'][2]<2:
            return False
        else:
            return True
    except Exception as e:
        return False

    return False
    

@app.route("/account_balance", methods=['GET', 'POST'])
def account_balance():
    if authentication()==False:
        return redirect(url_for('login'))

    # user_id = get_user_id()
    # account_balance_insert(user_id)    
    
    return render_template('account_balance.html', title='Add Symptom')

@app.route("/get_account_balance", methods=['GET'])
def get_account_balance():

    db = Db()
    user_id = get_user_id()
    account_balance=None
    if authentication() == True:
        columns="received,pay,update_date"
        where_stetment="status = '1' AND user_id = '"+str(user_id)+"'"  
        query=select_query("tblAccountBalance",columns,where_stetment)                    
        account_balance = db.get_data_by_key(query)

    result={"account_balance":account_balance}
    # print(result)

    return jsonify(result)

@app.route("/get_pandding_payment_request_by_user", methods=['GET'])
def get_pandding_payment_request_by_user():
    offset = request.args.get('offset')
    db = Db()
    user_id = get_user_id()
    payment_requests=None
    if authentication() == True:
        columns=" payment_request_id,transaction_url,create_date,transaction_id "
        where_stetment="user_id = '"+str(user_id)+"' AND status = '1' AND done = '0' ORDER BY create_date ASC LIMIT 10  OFFSET "+offset        
        query=select_query("tblPaymentRequest",columns,where_stetment)                    
        payment_requests = db.get_data(query)

        flg=0
        for i in range(len(payment_requests)):
            transaction_id=payment_requests[i][3]
            url='https://www.dailycarebd.com/v1/ecom-payment/details?transaction_id='+transaction_id
            requests.get(url, headers = {"client-id": "client-id","client-secret": "client-secret"})
            # print(response.code)
            if response.code == 200:
                result = response.json()
                amount = result['data']['amount']
                payment_status = result['data']['payment_status']
                if payment_status == 'completed':
                    column_names=['done']
                    values=['1']

                    where_stetment="payment_request_id = '"+str(payment_requests[i][0])+"'"
                    query=update_query("tblPaymentRequest",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)

                    received_wallet(user_id,amount)
                    flg=1
        if flg==1:
            columns=" payment_request_id,transaction_url,create_date,transaction_id "
            where_stetment="user_id = '"+str(user_id)+"' AND status = '1' AND done = '0' ORDER BY create_date ASC LIMIT 10  OFFSET "+offset        
            query=select_query("tblPaymentRequest",columns,where_stetment)                    
            payment_requests = db.get_data(query)

    result={"payment_requests":payment_requests}
    # print(result)

    return jsonify(result)


@app.route("/delete_pandding_payment_request_by_user", methods=['GET'])
def delete_pandding_payment_request_by_user():
    payment_request_id = request.args.get('id')
    db = Db()
    user_id = get_user_id()
    res=0
    if authentication() == True:
        columns=" payment_request_id "
        where_stetment="user_id = '"+str(user_id)+"' AND payment_request_id = '"+str(payment_request_id)+"' AND done = '0' "        
        query=select_query("tblPaymentRequest",columns,where_stetment)                    
        payment_request = db.get_data_by_key(query)

        if payment_request!=None:
            query="DELETE FROM tblPaymentRequest WHERE payment_request_id = '"+str(payment_request_id)+"'" 
            msg = db.update_data(query)
            res=1        

    result={"res":res}
    # print(result)

    return jsonify(result)

@app.route("/get_received_money_by_user", methods=['GET'])
def get_received_money_by_user():
    offset = request.args.get('offset')
    db = Db()
    user_id = get_user_id()
    received_moneys=None
    if authentication() == True:
        columns=" received_money_id,paymentID,transactionStatus,amount,create_date "
        where_stetment="user_id = '"+str(user_id)+"' AND status = '1' ORDER BY create_date DESC LIMIT 10  OFFSET "+offset        
        query=select_query("tblReceivedMoney",columns,where_stetment)                    
        received_moneys = db.get_data(query)

    result={"received_moneys":received_moneys}
    # print(result)

    return jsonify(result)

@app.route("/get_payment_receive_by_dc", methods=['GET'])
def get_payment_receive_by_dc():
    offset = request.args.get('offset')
    db = Db()
    payment_receives=None
    if is_admin() == True:

        columns=" tu.name,tu.profile_pic,trm.received_money_id,trm.paymentID,trm.transactionStatus,trm.amount,trm.create_date "    
        where_stetment="trm.status = '1' ORDER BY trm.create_date DESC LIMIT 10  OFFSET "+offset    
        join_query="tblReceivedMoney as trm "
        join_query=join_query+"LEFT JOIN "
        join_query=join_query+"tblUser as tu ON trm.user_id = tu.user_id "
        query=select_query(join_query,columns,where_stetment)                    
        payment_receives = db.get_data(query)

    result={"payment_receives":payment_receives}
    # print(result)

    return jsonify(result)


@app.route("/get_pay_doctor_fee_by_user", methods=['GET'])
def get_pay_doctor_fee_by_user():

    db = Db()
    user_id = get_user_id()
    doctor_fees=None
    offset = request.args.get('offset')
    if authentication() == True:
        columns=" tu.name,tda.doctor_fee,tpdf.daily_care_charge,tpdf.pay_date,tp.patient_name,tda.patient_id,tda.doctor_id "    
        where_stetment="tpdf.status = '1' AND tpdf.user_id = '"+str(user_id)+"' ORDER BY tpdf.pay_date DESC LIMIT 10  OFFSET "+offset    
        join_query="tblPayDoctorFee as tpdf "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDoctorAppointment as tda ON tda.doctor_appointment_id = tpdf.doctor_appointment_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tda.patient_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
        query=select_query(join_query,columns,where_stetment)                    
        doctor_fees = db.get_data(query)

    result={"doctor_fees":doctor_fees}
    # print(result)

    return jsonify(result)

@app.route("/get_pay_doctor_fee_by_doctor", methods=['GET'])
def get_pay_doctor_fee_by_doctor():

    db = Db()
    user_id = get_user_id()
    doctor_id = get_doctor_id(user_id,db)
    doctor_collections=None
    offset = request.args.get('offset')
    if doctor_id>0:
        columns=" tp.patient_name,tp.profile_pic,tda.doctor_fee,tpdf.pay_date,tda.patient_id "    
        where_stetment="tpdf.status = '1' AND tda.doctor_visited = '1' AND tda.doctor_id = '"+str(doctor_id)+"' ORDER BY tpdf.pay_date DESC LIMIT 10  OFFSET "+offset    
        join_query="tblPayDoctorFee as tpdf "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDoctorAppointment as tda ON tda.doctor_appointment_id = tpdf.doctor_appointment_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tda.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        doctor_collections = db.get_data(query)

    result={"doctor_collections":doctor_collections}
    # print(result)

    return jsonify(result)

@app.route("/get_withdrawal_money", methods=['GET'])
def get_withdrawal_money():

    db = Db()
    user_id = get_user_id()
    withdrawal_moneys=None
    offset = request.args.get('offset')
    if authentication() == True:
        columns="withdrawal_amount,processing_fee,withdrawal_detail,bank_transaction_id,withdrawal_date"
        where_stetment="status = '1' AND user_id = '"+str(user_id)+"' ORDER BY withdrawal_date DESC LIMIT 10  OFFSET "+offset 
        query=select_query("tblWithdrawalMoney",columns,where_stetment)                    
        withdrawal_moneys = db.get_data(query)

    result={"withdrawal_moneys":withdrawal_moneys}
    # print(result)

    return jsonify(result)


@app.route("/get_withdrawal_request", methods=['GET'])
def get_withdrawal_request():

    db = Db()
    user_id = get_user_id()
    withdrawal_requests=None
    offset = request.args.get('offset')
    if authentication() == True:
        columns="withdrawal_amount,request_date"
        where_stetment="status = '1' AND user_id = '"+str(user_id)+"' ORDER BY request_date DESC LIMIT 10  OFFSET "+offset   
        query=select_query("tblWithdrawalRequest",columns,where_stetment)                    
        withdrawal_requests = db.get_data(query)

    result={"withdrawal_requests":withdrawal_requests}
    # print(result)

    return jsonify(result)

@app.route("/symptom", methods=['GET', 'POST'])
def symptom():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('symptom.html', title='Add Symptom')

class SymptomApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        symptoms=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblSymptom",columns,where_stetment)                    
        symptoms = db.get_data(query)

        code =200

        return {'symptoms': symptoms}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        symptom=None
        symptom_id=0
        

        db=Db()

        if args['method']=='post':
            symptom = rmqt(data['symptom'])
            body_area = data['body_area']

            columns="symptom_id"
            where_stetment="symptom = '"+symptom+"' AND body_area = '"+body_area+"'"   
            query=select_query("tblSymptom",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['symptom',
                                'body_area',
                                'approved',
                                'create_date',
                                'status']
                values=[symptom,
                        body_area,
                        '0',
                        str(time.time()),
                        '1']
                query=insert_query("tblSymptom",column_names,values,"symptom_id")
                # print(query)
                symptom_id = db.insert_data(query)
            else:
                symptom_id = search[0]

        elif args['method']=='update':                
            symptom_id = data['symptom_id']

            symptom = rmqt(data['symptom'])
            body_area = data['body_area']

            column_names=['symptom',
                            'body_area']
            values=[symptom,
                    body_area]
            
            where_stetment="symptom_id = '"+str(symptom_id)+"'"
            query=update_query("tblSymptom",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

        elif args['method']=='approved':
            if is_admin() == True:                
                symptom_id = data['symptom_id']

                column_names=['approved']
                values=['1']
                
                where_stetment="symptom_id = '"+str(symptom_id)+"'"
                query=update_query("tblSymptom",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
            

        elif args['method']=='delete':                
            symptom_id = data['symptom_id']

            query="DELETE FROM tblSymptom WHERE symptom_id = '"+str(symptom_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        columns="*"
        where_stetment="symptom_id = '"+str(symptom_id)+"'"  
        query=select_query("tblSymptom",columns,where_stetment)                    
        symptom = db.get_data_by_key(query)
        code =200               
                    

        return {'data': symptom}, code

api.add_resource(SymptomApi, '/symptom_api')


@app.route("/body_area", methods=['GET', 'POST'])
def body_area():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('body_area.html', title='Add body_area')

class BodyAreaApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        body_areas=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblBodyArea",columns,where_stetment)                    
        body_areas = db.get_data(query)

        code =200

        return {'body_areas': body_areas}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        body_area=None
        body_area_id=0
        

        db=Db()

        if args['method']=='post':
            body_area = rmqt(data['body_area'])

            columns="body_area_id"
            where_stetment="body_area = '"+body_area+"'"   
            query=select_query("tblBodyArea",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['body_area',
                                'status']
                values=[body_area,
                        '1']
                query=insert_query("tblBodyArea",column_names,values,"body_area_id")
                # print(query)
                body_area_id = db.insert_data(query)
            

        elif args['method']=='delete':                
            body_area_id = data['body_area_id']

            if is_admin()==True:
                query="DELETE FROM tblBodyArea WHERE body_area_id = '"+str(body_area_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
          
        
        columns="*"
        where_stetment="body_area_id = '"+str(body_area_id)+"'"  
        query=select_query("tblBodyArea",columns,where_stetment)                    
        body_area = db.get_data_by_key(query)
        code =200               
                    

        return {'data': body_area}, code

api.add_resource(BodyAreaApi, '/body_area_api')


@app.route("/disease", methods=['GET', 'POST'])
def disease():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('disease.html', title='Add Disease')

class DiseaseApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        diseases=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblDisease",columns,where_stetment)                    
        diseases = db.get_data(query)

        code =200

        return {'diseases': diseases}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        disease=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                disease = rmqt(data['disease'])
                disease_en = rmqt(data['disease_en'])
                body_area = data['body_area']

                columns="disease_id"
                where_stetment="disease = '"+disease+"' AND body_area = '"+body_area+"'"   
                query=select_query("tblDisease",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['disease',
                                    'disease_en',
                                    'body_area',
                                    'approved',
                                    'create_date',
                                    'status']
                    values=[disease,
                            disease_en,
                            body_area,
                            '0',
                            str(time.time()),
                            '1']
                    query=insert_query("tblDisease",column_names,values,"disease_id")
                    # print(query)
                    disease_id = db.insert_data(query)

            elif args['method']=='update':                
                disease_id = data['disease_id']

                disease = rmqt(data['disease'])
                disease_en = rmqt(data['disease_en'])
                body_area = data['body_area']

                column_names=['disease',
                                'disease_en',
                                'body_area']
                values=[disease,
                        disease_en,
                        body_area]
                
                where_stetment="disease_id = '"+str(disease_id)+"'"
                query=update_query("tblDisease",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                disease_id = data['disease_id']

                query="DELETE FROM tblDisease WHERE disease_id = '"+str(disease_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="disease_id = '"+str(disease_id)+"'"  
            query=select_query("tblDisease",columns,where_stetment)                    
            disease = db.get_data_by_key(query)
            code =200               
                    

        return {'data': disease}, code

api.add_resource(DiseaseApi, '/disease_api')


class DiseaseIdentifyApi(Resource):
    def get(self):
        parser = reqparse.RequestParser() 
        parser.add_argument('id', required=True)        
        args = parser.parse_args()
        doctor_appointment_id = args['id']
        msg="unauthorized request"
        code =401
        disease_identifys=None
        db=Db()

        columns=" tdi.disease_identify_id,td.disease_id,td.disease,td.body_area,tdi.measure "    
        where_stetment="tdi.doctor_appointment_id = '"+str(doctor_appointment_id)+"' "
        join_query="tblDiseaseIdentify as tdi "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDisease as td ON td.disease_id = tdi.disease_id "
        query=select_query(join_query,columns,where_stetment)                    
        disease_identifys = db.get_data(query)

        code =200

        return {'disease_identifys': disease_identifys}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        disease_identify=None
        disease_identify_id=0
        
        db=Db()

        user_id = get_user_id()
        doctor_id = get_doctor_id(user_id,db)
        doctor_appointment_id = data['doctor_appointment_id']

        columns="doctor_appointment_id"
        where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"' AND doctor_id = '"+str(doctor_id)+"'"   
        query=select_query("tblDoctorAppointment",columns,where_stetment)                    
        dap = db.get_data_by_key(query)
        if dap != None:

            if args['method']=='post':

                doctor_appointment_id = data['doctor_appointment_id']
                disease_id = data['disease_id']
                measure = data['measure']

                columns="disease_identify_id"
                where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"' AND disease_id = '"+str(disease_id)+"'"   
                query=select_query("tblDiseaseIdentify",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['doctor_appointment_id',
                                    'disease_id',
                                    'measure',
                                    'create_date',
                                    'status']
                    values=[str(doctor_appointment_id),
                            str(disease_id),
                            str(measure),
                            str(time.time()),
                            '1']
                    query=insert_query("tblDiseaseIdentify",column_names,values,"disease_identify_id")
                    # print(query)
                    disease_identify_id = db.insert_data(query)

            elif args['method']=='update':                
                disease_identify_id = data['disease_identify_id']

                doctor_appointment_id = data['doctor_appointment_id']
                disease_id = data['disease_id']
                measure = data['measure']

                column_names=['doctor_appointment_id',
                                'disease_id',
                                'measure']
                values=[str(doctor_appointment_id),
                        str(disease_id),
                        str(measure)]
                
                where_stetment="disease_identify_id = '"+str(disease_identify_id)+"'"
                query=update_query("tblDiseaseIdentify",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                disease_identify_id = data['disease_identify_id']

                query="DELETE FROM tblDiseaseIdentify WHERE disease_identify_id = '"+str(disease_identify_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns=" tdi.disease_identify_id,td.disease_id,td.disease,td.body_area,tdi.measure "    
            where_stetment="tdi.disease_identify_id = '"+str(disease_identify_id)+"' "
            join_query="tblDiseaseIdentify as tdi "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDisease as td ON td.disease_id = tdi.disease_id "
            query=select_query(join_query,columns,where_stetment)                    
            disease_identify = db.get_data_by_key(query)
            code =200               
                    

        return {'data': disease_identify}, code

api.add_resource(DiseaseIdentifyApi, '/disease_identify_api')

@app.route("/symptom_grouping", methods=['GET', 'POST'])
def symptom_grouping():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('symptom_grouping.html', title='Add Symptom Grouping')

class SymptomGroupingApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        symptom_groups=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblSymptomGroup",columns,where_stetment)                    
        symptom_groups = db.get_data(query)

        code =200

        return {'symptom_groups': symptom_groups}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        symptom_group=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                group_name = rmqt(data['group_name'])
                gender = data['gender']
                from_age = data['from_age']
                to_age = data['to_age']
                covid_symptoms = data['covid_symptoms']
                previous_diseases = data['previous_diseases']
                test_reports = data['test_reports']
                # print([3, 2])
                # return {'data': []}, 200

                columns="symptom_group_id"
                where_stetment="group_name = '"+group_name+"' "   
                query=select_query("tblSymptomGroup",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['group_name',
                                    'gender',
                                    'from_age',
                                    'to_age',
                                    'create_date',
                                    'status']
                    values=[group_name,
                            gender,
                            str(from_age),
                            str(to_age),
                            str(time.time()),
                            '1']
                    query=insert_query("tblSymptomGroup",column_names,values,"symptom_group_id")
                    # print(query)
                    symptom_group_id = db.insert_data(query)

                    for x in covid_symptoms:
                        column_names=['symptom_group_id',
                                        'covid_symptom_id',
                                        'status']
                        values=[str(symptom_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblCovidSymptomGroup",column_names,values,"covid_symptom_group_id")
                        # print(query)
                        covid_symptom_group_id = db.insert_data(query)

                    for x in previous_diseases:
                        column_names=['symptom_group_id',
                                        'previous_disease_id',
                                        'status']
                        values=[str(symptom_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblPreviousDiseaseGroup",column_names,values,"previous_disease_group_id")
                        # print(query)
                        previous_disease_group_id = db.insert_data(query)

                    for x in test_reports:
                        column_names=['symptom_group_id',
                                        'test_report_id',
                                        'status']
                        values=[str(symptom_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblTestReportGroup",column_names,values,"test_report_group_id")
                        # print(query)
                        test_report_group_id = db.insert_data(query)



                else:
                    return {'msg': ["Already have, Change group name."],'data': []}, 200

            elif args['method']=='update':                
                symptom_group_id = data['symptom_group_id']

                gender = data['gender']
                from_age = data['from_age']
                to_age = data['to_age']
                covid_symptoms = data['covid_symptoms']
                previous_diseases = data['previous_diseases']
                test_reports = data['test_reports']

                column_names=['group_name',
                                'gender',
                                'from_age',
                                'to_age']
                values=[group_name,
                        gender,
                        str(from_age),
                        str(to_age)]
                
                where_stetment="symptom_group_id = '"+str(symptom_group_id)+"'"
                query=update_query("tblSymptomGroup",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

                for x in covid_symptoms:
                    column_names=['symptom_group_id',
                                    'covid_symptom_id',
                                    'status']
                    values=[str(symptom_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblCovidSymptomGroup",column_names,values,"covid_symptom_group_id")
                    # print(query)
                    covid_symptom_group_id = db.insert_data(query)

                for x in previous_diseases:
                    column_names=['symptom_group_id',
                                    'previous_disease_id',
                                    'status']
                    values=[str(symptom_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblPreviousDiseaseGroup",column_names,values,"previous_disease_group_id")
                    # print(query)
                    previous_disease_group_id = db.insert_data(query)

                for x in test_reports:
                    column_names=['symptom_group_id',
                                    'test_report_id',
                                    'status']
                    values=[str(symptom_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblTestReportGroup",column_names,values,"test_report_group_id")
                    # print(query)
                    test_report_group_id = db.insert_data(query)

            elif args['method']=='group_check':
                
                group_ids = data['group_ids']
                covid_symptoms = data['covid_symptoms']
                previous_diseases = data['previous_diseases']
                test_reports = data['test_reports']
                # print([3, 2])
                group_ids = ','.join(str(e) for e in group_ids)

                if covid_symptoms >0:

                    columns="symptom_group_id,COUNT(symptom_group_id) as symptom_group_cnt "
                    where_stetment="symptom_group_id in ("+group_ids+") group by symptom_group_id "
                    query=select_query("tblCovidSymptomGroup",columns,where_stetment)                    
                    symptom_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in symptom_groups:
                        if x[1]==covid_symptoms:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])


                if previous_diseases >0 and len(group_ids) >0:

                    columns="symptom_group_id,COUNT(symptom_group_id) as symptom_group_cnt "
                    where_stetment="symptom_group_id in ("+group_ids+") group by symptom_group_id "
                    query=select_query("tblPreviousDiseaseGroup",columns,where_stetment)                    
                    previous_disease_group = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in previous_disease_group:
                        if x[1]==previous_diseases:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if test_reports >0 and len(group_ids) >0:

                    columns="symptom_group_id,COUNT(symptom_group_id) as symptom_group_cnt "
                    where_stetment="symptom_group_id in ("+group_ids+") group by symptom_group_id "
                    query=select_query("tblTestReportGroup",columns,where_stetment)                    
                    test_report_group = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in test_report_group:
                        if x[1]==test_reports:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if len(group_ids) >0:
                    columns="symptom_group_id,group_name,gender,from_age,to_age "
                    where_stetment="symptom_group_id in ("+group_ids+") "
                    query=select_query("tblSymptomGroup",columns,where_stetment)                    
                    symptom_groups = db.get_data(query)

                    return {'symptom_groups': symptom_groups}, 200
                    
                else:
                    return {'symptom_groups': []}, 200

            elif args['method']=='delete':                
                symptom_group_id = data['symptom_group_id']

                query="DELETE FROM tblSymptomGroup WHERE symptom_group_id = '"+str(symptom_group_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="symptom_group_id = '"+str(symptom_group_id)+"'"  
            query=select_query("tblSymptomGroup",columns,where_stetment)                    
            symptom_group = db.get_data_by_key(query)
            code =200               
                    

        return {'data': symptom_group}, code

api.add_resource(SymptomGroupingApi, '/symptom_grouping_api')

def create_group(gender,from_age,to_age,covid_symptoms,previous_diseases,test_reports):

    db=Db()
    group_name = gender+"-"+str(from_age)+"-"+str(to_age)   

    column_names=['group_name',
                    'gender',
                    'from_age',
                    'to_age',
                    'create_date',
                    'status']
    values=[group_name,
            gender,
            str(from_age),
            str(to_age),
            str(time.time()),
            '1']
    query=insert_query("tblSymptomGroup",column_names,values,"symptom_group_id")
    # print(query)
    symptom_group_id = db.insert_data(query)

    for x in covid_symptoms:
        column_names=['symptom_group_id',
                        'covid_symptom_id',
                        'status']
        values=[str(symptom_group_id),
                str(x),
                '1']
        query=insert_query("tblCovidSymptomGroup",column_names,values,"covid_symptom_group_id")
        # print(query)
        covid_symptom_group_id = db.insert_data(query)

    for x in previous_diseases:
        column_names=['symptom_group_id',
                        'previous_disease_id',
                        'status']
        values=[str(symptom_group_id),
                str(x),
                '1']
        query=insert_query("tblPreviousDiseaseGroup",column_names,values,"previous_disease_group_id")
        # print(query)
        previous_disease_group_id = db.insert_data(query)

    for x in test_reports:
        column_names=['symptom_group_id',
                        'test_report_id',
                        'status']
        values=[str(symptom_group_id),
                str(x),
                '1']
        query=insert_query("tblTestReportGroup",column_names,values,"test_report_group_id")
        # print(query)
        test_report_group_id = db.insert_data(query)

    return symptom_group_id

class FindSymptomGroupApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        symptom_groups=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblSymptomGroup",columns,where_stetment)                    
        symptom_groups = db.get_data(query)

        code =200

        return {'symptom_groups': symptom_groups}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        symptom_group=None

        db=Db()

        if args['method']=='find_group':

            gender = data['gender']
            from_age = data['from_age']
            to_age = data['to_age']

            covid_symptoms =data['covid_symptoms']
            previous_diseases = data['previous_diseases']
            test_reports = data['test_reports']
            
            symptom_group_ids=[]
            if len(covid_symptoms) >0:
                print(covid_symptoms)
                print(type(covid_symptoms))
                ids = ','.join(str(e) for e in covid_symptoms)

                columns="symptom_group_id,COUNT(symptom_group_id) as symptom_group_cnt "
                where_stetment="covid_symptom_id in ("+ids+") group by symptom_group_id "
                query=select_query("tblCovidSymptomGroup",columns,where_stetment)                    
                symptom_groups = db.get_data(query)
               
                
                for x in symptom_groups:
                    if x[1]==len(covid_symptoms):
                        symptom_group_ids.append(x[0])


            previous_disease_group_ids=[]
            if len(previous_diseases) >0:
                ids = ','.join(str(e) for e in previous_diseases)

                columns="symptom_group_id,COUNT(symptom_group_id) as symptom_group_cnt "
                where_stetment="previous_disease_id in ("+ids+") group by symptom_group_id "
                query=select_query("tblPreviousDiseaseGroup",columns,where_stetment)                    
                previous_disease_groups = db.get_data(query)

                for x in previous_disease_groups:
                    if x[1]==len(previous_diseases):
                        previous_disease_group_ids.append(x[0])


            test_report_group_ids=[]
            if len(test_reports) >0:
                ids = ','.join(str(e) for e in test_reports)
                columns="symptom_group_id,COUNT(symptom_group_id) as symptom_group_cnt "
                where_stetment="test_report_id in ("+ids+") group by symptom_group_id "
                query=select_query("tblTestReportGroup",columns,where_stetment)                    
                test_report_groups = db.get_data(query)

                for x in test_report_groups:
                    if x[1]==len(test_reports):
                        test_report_group_ids.append(x[0])

            group_ids=[]
            if len(covid_symptoms)>0:
                group_ids = symptom_group_ids

                if len(previous_diseases)>0:
                    group_ids = list(set(group_ids) & set(previous_disease_group_ids))

                if len(test_reports)>0:
                    group_ids = list(set(group_ids) & set(test_report_group_ids))

            elif len(previous_diseases)>0:
                group_ids = previous_disease_group_ids
                if len(test_reports)>0:
                    group_ids = list(set(group_ids) & set(test_report_group_ids))
            
            elif len(test_reports)>0:
                group_ids = test_report_group_ids


            if len(group_ids) >0:
                ids = ','.join(str(e) for e in group_ids)
                columns="symptom_group_id "
                where_stetment="gender = '"+gender+"' AND (from_age >= '"+str(from_age)+"'  AND to_age <= '"+str(to_age)+"') AND symptom_group_id in ("+ids+") "
                query=select_query("tblSymptomGroup",columns,where_stetment)                    
                symptom_group = db.get_data_by_key(query)
                if symptom_group!=None:
                    return {'symptom_group_id': symptom_group[0]}, 200
                else:
                    # Create Group
                    symptom_group_id = create_group(gender,from_age,to_age,covid_symptoms,previous_diseases,test_reports)
                    return {'symptom_group_id': symptom_group_id}, 200
                
            else:
                # Create Group
                symptom_group_id = create_group(gender,from_age,to_age,covid_symptoms,previous_diseases,test_reports)
                return {'symptom_group_id': symptom_group_id}, 200
       
                    

        return {'symptom_group_id': 0}, code

api.add_resource(FindSymptomGroupApi, '/find_symptom_group_api')

@app.route("/get_public_treatment", methods=['GET'])
def get_public_treatment():

    symptom_group_id = request.args.get('id')
    
    db = Db()

    columns=" tpt.rx_group_id,COUNT(tpt.rx_group_id) as rx_group_id_cnt,max(tpt.doctor_id) "    
    where_stetment=" tpt.status = '1' AND tpt.symptom_group_id = '"+str(symptom_group_id)+"'  group by tpt.rx_group_id ORDER BY rx_group_id_cnt DESC "
    join_query="tblPublicTreatment as tpt "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblCovidTreatment as tct ON tct.rx_group_id = tpt.rx_group_id "
    query=select_query(join_query,columns,where_stetment)                    
    public_treatment = db.get_data_by_key(query)

    result={"public_treatment":public_treatment}

    return jsonify(result)

class CovidSymptomApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        covid_symptoms=None
        db=Db() 

        columns=" tcs.covid_symptom_id,ts.symptom_id,ts.symptom,ts.body_area,tcs.measure,tcs.symptom_days "    
        where_stetment=" tcs.status = '1' "
        join_query="tblCovidSymptom as tcs "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tcs.symptom_id "
        query=select_query(join_query,columns,where_stetment)                    
        covid_symptoms = db.get_data(query)

        code =200

        return {'covid_symptoms': covid_symptoms}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        covid_symptom=None
        covid_symptom_id=0
        

        db=Db()

        if args['method']=='post':
            symptom_id = data['symptom_id']
            measure = data['measure']
            symptom_days = data['symptom_days']

            columns="covid_symptom_id"
            where_stetment="symptom_id = '"+str(symptom_id)+"' AND measure = '"+str(measure)+"' AND symptom_days = '"+str(symptom_days)+"' "   
            query=select_query("tblCovidSymptom",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['symptom_id',
                                'measure',
                                'symptom_days',
                                'create_date',
                                'status']
                values=[str(symptom_id),
                        str(measure),
                        str(symptom_days),
                        str(time.time()),
                        '1']
                query=insert_query("tblCovidSymptom",column_names,values,"covid_symptom_id")
                # print(query)
                covid_symptom_id = db.insert_data(query)
            else:
                covid_symptom_id = search[0]

        elif args['method']=='update':                
            covid_symptom_id = data['covid_symptom_id']

            symptom_id = data['symptom_id']
            measure = data['measure']
            symptom_days = data['symptom_days']

            column_names=['symptom_id',
                            'measure',
                            'symptom_days']
            values=[str(symptom_id),
                    str(measure),
                    str(symptom_days)]
            
            where_stetment="covid_symptom_id = '"+str(covid_symptom_id)+"'"
            query=update_query("tblCovidSymptom",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

        elif args['method']=='delete':                
            covid_symptom_id = data['covid_symptom_id']

            query="DELETE FROM tblCovidSymptom WHERE covid_symptom_id = '"+str(covid_symptom_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        # columns="*"
        # where_stetment="covid_symptom_id = '"+str(covid_symptom_id)+"'"  
        # query=select_query("tblCovidSymptom",columns,where_stetment)                    
        # covid_symptom = db.get_data_by_key(query)

        columns=" tcs.covid_symptom_id,ts.symptom_id,ts.symptom,ts.body_area,tcs.measure,tcs.symptom_days "    
        where_stetment="tcs.covid_symptom_id = '"+str(covid_symptom_id)+"' "
        join_query="tblCovidSymptom as tcs "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tcs.symptom_id "
        query=select_query(join_query,columns,where_stetment)                    
        covid_symptom = db.get_data_by_key(query)

        columns="covid_symptom_id,symptom_group_id "
        where_stetment="covid_symptom_id = '"+str(covid_symptom_id)+"' "
        query=select_query("tblCovidSymptomGroup",columns,where_stetment)                    
        covid_symptom_groups = db.get_data(query)
        code =200               
                    

        return {'data': covid_symptom,'covid_symptom_groups':covid_symptom_groups}, code

api.add_resource(CovidSymptomApi, '/covid_symptom_api')


@app.route("/get_covid_symptom_by_ids", methods=['GET'])
def get_covid_symptom_by_ids():

    ids = request.args.get('ids')

    db = Db()


    columns=" tcs.covid_symptom_id,ts.symptom_id,ts.symptom,ts.body_area,tcs.measure,tcs.symptom_days "    
    where_stetment=" tcs.status = '1' AND tcs.covid_symptom_id in ("+ids+")"
    join_query="tblCovidSymptom as tcs "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tcs.symptom_id "
    query=select_query(join_query,columns,where_stetment)                    
    covid_symptoms = db.get_data(query)

    result={"covid_symptoms":covid_symptoms}
    # print(result)

    return jsonify(result)

class PreviousDiseaseApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        previous_diseases=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblPreviousDisease",columns,where_stetment)                    
        previous_diseases = db.get_data(query)

        code =200

        return {'previous_diseases': previous_diseases}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        previous_disease=None
        previous_disease_id=0

        db=Db()

        if args['method']=='post':
            disease_id = data['disease_id']
            measure = data['measure']
            present = data['present']
            medicine = data['medicine']

            columns="previous_disease_id"
            where_stetment="disease_id = '"+str(disease_id)+"' AND present = '"+str(present)+"' AND medicine = '"+str(medicine)+"' AND measure = '"+str(measure)+"'"   
            query=select_query("tblPreviousDisease",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['disease_id',
                                'present',
                                'medicine',
                                'measure',
                                'create_date',
                                'status']
                values=[str(disease_id),
                        str(present),
                        str(medicine),
                        str(measure),
                        str(time.time()),
                        '1']
                query=insert_query("tblPreviousDisease",column_names,values,"previous_disease_id")
                # print(query)
                previous_disease_id = db.insert_data(query)
            else:
                previous_disease_id = search[0]

        elif args['method']=='update':                
            previous_disease_id = data['previous_disease_id']

            disease_id = data['disease_id']
            measure = data['measure']
            present = data['present']
            medicine = data['medicine']

            column_names=['disease_id',
                            'present',
                            'medicine',
                            'measure']
            values=[str(disease_id),
                    str(present),
                    str(medicine),
                    str(measure)]
            
            where_stetment="previous_disease_id = '"+str(previous_disease_id)+"'"
            query=update_query("tblPreviousDisease",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

        elif args['method']=='delete':                
            previous_disease_id = data['previous_disease_id']

            query="DELETE FROM tblPreviousDisease WHERE previous_disease_id = '"+str(previous_disease_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        # columns="*"
        # where_stetment="previous_disease_id = '"+str(previous_disease_id)+"'"  
        # query=select_query("tblPreviousDisease",columns,where_stetment)                    
        # previous_disease = db.get_data_by_key(query)

        columns=" tpd.previous_disease_id,td.disease_id,td.disease,td.body_area,tpd.present,tpd.medicine,tpd.measure "    
        where_stetment="tpd.previous_disease_id = '"+str(previous_disease_id)+"' "
        join_query="tblPreviousDisease as tpd "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDisease as td ON td.disease_id = tpd.disease_id "
        query=select_query(join_query,columns,where_stetment)                    
        previous_disease = db.get_data_by_key(query)

        columns="previous_disease_id,symptom_group_id "
        where_stetment="previous_disease_id = '"+str(previous_disease_id)+"' "
        query=select_query("tblPreviousDiseaseGroup",columns,where_stetment)                    
        previous_disease_groups = db.get_data(query)
        code =200               
                    

        return {'data': previous_disease,'previous_disease_groups':previous_disease_groups}, code

api.add_resource(PreviousDiseaseApi, '/previous_disease_api')


@app.route("/get_previous_disease_by_ids", methods=['GET'])
def get_previous_disease_by_ids():

    ids = request.args.get('ids')
    
    db = Db()


    columns=" tpd.previous_disease_id,td.disease_id,td.disease,td.body_area,tpd.present,tpd.medicine,tpd.measure "    
    where_stetment="tpd.status ='1' AND tpd.previous_disease_id in ("+ids+") "
    join_query="tblPreviousDisease as tpd "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDisease as td ON td.disease_id = tpd.disease_id "
    query=select_query(join_query,columns,where_stetment)                    
    previous_diseases = db.get_data(query)

    result={"previous_diseases":previous_diseases}
    # print(result)

    return jsonify(result)

class TestReportApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        test_reports=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblTestReport",columns,where_stetment)                    
        test_reports = db.get_data(query)

        code =200

        return {'test_reports': test_reports}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        test_report=None
        test_report_id=0
        
        db=Db()

        if args['method']=='post':
            test_name = rmqt(data['test_name'])
            min_value = data['min_value']
            max_value = data['max_value']
            report_result = data['report_result']

            columns="test_report_id"
            where_stetment="test_name = '"+test_name+"' AND min_value = '"+str(min_value)+"' AND max_value = '"+str(max_value)+"' AND report_result = '"+str(report_result)+"'"   
            query=select_query("tblTestReport",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['test_name',
                                'min_value',
                                'max_value',
                                'report_result',
                                'create_date',
                                'status']
                values=[test_name,
                        str(min_value),
                        str(max_value),
                        str(report_result),
                        str(time.time()),
                        '1']
                query=insert_query("tblTestReport",column_names,values,"test_report_id")
                # print(query)
                test_report_id = db.insert_data(query)
            else:
                test_report_id = search[0]

        elif args['method']=='update':                
            test_report_id = data['test_report_id']

            test_name = rmqt(data['test_name'])
            min_value = data['min_value']
            max_value = data['max_value']
            report_result = data['report_result']

            column_names=['test_name',
                            'min_value',
                            'max_value',
                            'report_result']
            values=[test_name,
                    str(min_value),
                    str(max_value),
                    str(report_result)]
            
            where_stetment="test_report_id = '"+str(test_report_id)+"'"
            query=update_query("tblTestReport",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

        elif args['method']=='delete':                
            test_report_id = data['test_report_id']

            query="DELETE FROM tblTestReport WHERE test_report_id = '"+str(test_report_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200


        elif args['method']=='doctor_report':                
            test_report_id = data['test_report_id']
            report_result = data['report_result']

            column_names=['report_result']
            values=[str(report_result)]
            
            where_stetment="test_report_id = '"+str(test_report_id)+"'"
            query=update_query("tblTestReport",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

            return {'data': [res]}, 200
          
        
        columns="*"
        where_stetment="test_report_id = '"+str(test_report_id)+"'"  
        query=select_query("tblTestReport",columns,where_stetment)                    
        test_report = db.get_data_by_key(query)

        columns="test_report_id,symptom_group_id "
        where_stetment="test_report_id = '"+str(test_report_id)+"' "
        query=select_query("tblTestReportGroup",columns,where_stetment)                    
        test_report_groups = db.get_data(query)
        code =200               
                    

        return {'data': test_report,'test_report_groups':test_report_groups}, code

api.add_resource(TestReportApi, '/test_report_api')


@app.route("/get_test_report_by_ids", methods=['GET'])
def get_test_report_by_ids():

    ids = request.args.get('ids')
    
    db = Db()


    columns="*"
    where_stetment="test_report_id in ("+str(ids)+") "  
    query=select_query("tblTestReport",columns,where_stetment)                    
    test_reports = db.get_data(query)

    result={"test_reports":test_reports}
    # print(result)

    return jsonify(result)


@app.route("/get_medical_tests", methods=['GET'])
def get_medical_tests():

    rx_group_id = request.args.get('id')
    db = Db()


    columns="tmtr.*"    
    where_stetment="trg.status = '1' and trg.rx_group_id = '"+str(rx_group_id)+"'  "    
    join_query="tblRxGroup as trg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicalTestRxGroup as tmtrg ON tmtrg.rx_group_id = trg.rx_group_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicalTestRx as tmtr ON tmtr.medical_test_rx_id = tmtrg.medical_test_rx_id "
    query=select_query(join_query,columns,where_stetment)                    
    medical_tests = db.get_data(query)

    result={"medical_tests":medical_tests}

    return jsonify(result)

@app.route("/doctor_dashboard", methods=['GET', 'POST'])
def doctor_dashboard():

    user_id = get_user_id()
    doctor_id = 0
    if authentication() == True:
        db=Db()
        doctor_id = get_doctor_id(user_id,db)
    else:
        return redirect(url_for('index'))
   
    return render_template('doctor_dashboard.html', title='doctor_dashboard', doctor = doctor_id)


@app.route("/dashboard", methods=['GET', 'POST'])
def dashboard():
    
    if authentication() == False:
        return redirect(url_for('index'))

    is_doct=is_doctor()
   
    return render_template('dashboard.html', title='dashboard',is_doctor=is_doct)

@app.route("/get_symptom_group_details", methods=['GET'])
def get_symptom_group_details():

    symptom_group_id = request.args.get('id')
    db = Db()


    columns=" tcs.covid_symptom_id,ts.symptom_id,ts.symptom,ts.body_area,tcs.measure,tcs.symptom_days,tcsg.symptom_group_id "    
    where_stetment="tcsg.symptom_group_id = '"+str(symptom_group_id)+"' "   
    join_query="tblCovidSymptomGroup as tcsg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblCovidSymptom as tcs ON tcs.covid_symptom_id = tcsg.covid_symptom_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tcs.symptom_id "
    query=select_query(join_query,columns,where_stetment)                    
    covid_symptoms = db.get_data(query)

    columns=" tpd.previous_disease_id,td.disease_id,td.disease,td.body_area,tpd.present,tpd.medicine,tpd.measure,tpdg.symptom_group_id "    
    where_stetment="tpdg.symptom_group_id = '"+str(symptom_group_id)+"' "   
    join_query="tblPreviousDiseaseGroup as tpdg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPreviousDisease as tpd ON tpd.previous_disease_id = tpdg.previous_disease_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDisease as td ON td.disease_id = tpd.disease_id "
    query=select_query(join_query,columns,where_stetment)                    
    previous_diseases = db.get_data(query)

    columns=" ttr.*,ttrg.symptom_group_id "    
    where_stetment="ttrg.symptom_group_id = '"+str(symptom_group_id)+"' "   
    join_query="tblTestReportGroup as ttrg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblTestReport as ttr ON ttr.test_report_id = ttrg.test_report_id "
    query=select_query(join_query,columns,where_stetment)                    
    test_reports = db.get_data(query)

    result={"covid_symptoms":covid_symptoms,"previous_diseases":previous_diseases,"test_reports":test_reports}
    # print(result)

    return jsonify(result)


@app.route("/get_symptom_group_ids", methods=['GET'])
def get_symptom_group_ids():

    symptom_group_id = request.args.get('id')
    db = Db()


    # columns=" tcs.covid_symptom_id,ts.symptom_id,ts.symptom,ts.body_area,tcs.measure,tcsg.symptom_group_id "    
    # where_stetment="tcsg.symptom_group_id = '"+str(symptom_group_id)+"' "   
    # join_query="tblCovidSymptomGroup as tcsg "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblCovidSymptom as tcs ON tcs.covid_symptom_id = tcsg.covid_symptom_id "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tcs.symptom_id "
    # query=select_query(join_query,columns,where_stetment)                    
    # covid_symptoms = db.get_data(query)

    columns="covid_symptom_id"
    where_stetment="symptom_group_id = '"+str(symptom_group_id)+"' " 
    query=select_query("tblCovidSymptomGroup",columns,where_stetment)                    
    covid_symptoms = db.get_data(query)

    # columns=" tpd.previous_disease_id,td.disease_id,td.disease,td.body_area,tpd.present,tpd.medicine,tpd.measure,tpdg.symptom_group_id "    
    # where_stetment="tpdg.symptom_group_id = '"+str(symptom_group_id)+"' "   
    # join_query="tblPreviousDiseaseGroup as tpdg "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblPreviousDisease as tpd ON tpd.previous_disease_id = tpdg.previous_disease_id "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblDisease as td ON td.disease_id = tpd.disease_id "
    # query=select_query(join_query,columns,where_stetment)                    
    # previous_diseases = db.get_data(query)

    columns="previous_disease_id"
    where_stetment="symptom_group_id = '"+str(symptom_group_id)+"' " 
    query=select_query("tblPreviousDiseaseGroup",columns,where_stetment)                    
    previous_diseases = db.get_data(query)

    # columns=" ttr.*,ttrg.symptom_group_id "    
    # where_stetment="ttrg.symptom_group_id = '"+str(symptom_group_id)+"' "   
    # join_query="tblTestReportGroup as ttrg "
    # join_query=join_query+"INNER JOIN "
    # join_query=join_query+"tblTestReport as ttr ON ttr.test_report_id = ttrg.test_report_id "
    # query=select_query(join_query,columns,where_stetment)                    
    # test_reports = db.get_data(query)

    columns="test_report_id"
    where_stetment="symptom_group_id = '"+str(symptom_group_id)+"' " 
    query=select_query("tblTestReportGroup",columns,where_stetment)                    
    test_reports = db.get_data(query)

    result={"covid_symptoms":covid_symptoms,"previous_diseases":previous_diseases,"test_reports":test_reports}
    # print(result)

    return jsonify(result)

@app.route("/get_rx_group_details", methods=['GET'])
def get_rx_group_details():

    rx_group_id = request.args.get('id')
    db = Db()

    

    columns=" tfr.*,tfrg.rx_group_id "    
    where_stetment="tfrg.rx_group_id = '"+str(rx_group_id)+"' "   
    join_query="tblFoodRxGroup as tfrg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblFoodRx as tfr ON tfr.food_rx_id = tfrg.food_rx_id "
    query=select_query(join_query,columns,where_stetment)                    
    food_rxs = db.get_data(query)

    columns=" tmr.*,tm.medicine_dosage_form,tm.brand_medicine_name,tm.strength,tds.daily_schedule,tbe.befor_eating,tfrg.rx_group_id "    
    where_stetment="tfrg.status = '1' and tfrg.rx_group_id = '"+str(rx_group_id)+"' "    
    join_query="tblMedicineRxGroup as tfrg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicineRx as tmr  ON tmr.medicine_rx_id = tfrg.medicine_rx_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tmr.medicine_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDailySchedule as tds ON tds.daily_schedule_id = tmr.daily_schedule_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblBeforEating as tbe ON tbe.befor_eating_id = tmr.befor_eating_id "
    query=select_query(join_query,columns,where_stetment)                    
    medicine_rxs = db.get_data(query)

    columns=" tfr.*,tfrg.rx_group_id "    
    where_stetment="tfrg.rx_group_id = '"+str(rx_group_id)+"' "   
    join_query="tblExerciseRxGroup as tfrg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblExerciseRx as tfr ON tfr.exercise_rx_id = tfrg.exercise_rx_id "
    query=select_query(join_query,columns,where_stetment)                    
    exercise_rxs = db.get_data(query)

    columns=" tfr.*,tfrg.rx_group_id "    
    where_stetment="tfrg.rx_group_id = '"+str(rx_group_id)+"' "   
    join_query="tblExtendRxGroup as tfrg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblExtendRx as tfr ON tfr.extend_rx_id = tfrg.extend_rx_id "
    query=select_query(join_query,columns,where_stetment)                    
    extend_rxs = db.get_data(query)

    columns=" tfr.*,tfrg.rx_group_id "    
    where_stetment="tfrg.rx_group_id = '"+str(rx_group_id)+"' "   
    join_query="tblMedicalTestRxGroup as tfrg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicalTestRx as tfr ON tfr.medical_test_rx_id = tfrg.medical_test_rx_id "
    query=select_query(join_query,columns,where_stetment)                    
    medical_test_rxs = db.get_data(query)

    result={"food_rxs":food_rxs,"medicine_rxs":medicine_rxs,"exercise_rxs":exercise_rxs,"extend_rxs":extend_rxs,"medical_test_rxs":medical_test_rxs}
    # print(result)

    return jsonify(result)

@app.route("/prescription", methods=['GET', 'POST'])
def prescription():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('prescription.html', title='Add Prescription')

class PrescriptionApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        rx_groups=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblRxGroup",columns,where_stetment)                    
        rx_groups = db.get_data(query)

        code =200

        return {'rx_groups': rx_groups}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        symptom_group=None
        subject_id=0
        user_id = get_user_id()
        if is_admin() == True:

            db=Db()

            if args['method']=='post': 

                symptom_group_id = data['symptom_group_id']
                doctor_id = get_doctor_id(user_id,db)
                if doctor_id ==0:
                    return {'data': []}, 401

                food_rxs = data['food_rxs']
                medicine_rxs = data['medicine_rxs']
                exercise_rxs = data['exercise_rxs']
                extend_rxs = data['extend_rxs']
                medical_test_rxs = data['medical_test_rxs']

                column_names=['symptom_group_id',
                                'doctor_id',
                                'create_date',
                                'status']
                values=[str(symptom_group_id),
                        str(doctor_id),
                        str(time.time()),
                        '1']
                query=insert_query("tblRxGroup",column_names,values,"rx_group_id")
                # print(query)
                rx_group_id = db.insert_data(query)



                if len(food_rxs) >0:
                    str_rx = ','.join(str(e) for e in food_rxs)

                    columns="food_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND food_rx_id in ("+str_rx+")  "
                    query=select_query("tblFoodRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)
                    # print("Foood:",food_rxs_have)

                for x in food_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'food_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblFoodRxGroup",column_names,values,"food_rx_group_id")
                        # print(query)
                        food_rx_group_id = db.insert_data(query)


                if len(medicine_rxs) >0:
                    str_rx = ','.join(str(e) for e in medicine_rxs)

                    columns="medicine_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND medicine_rx_id in ("+str_rx+")  "
                    query=select_query("tblMedicineRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in medicine_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'medicine_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblMedicineRxGroup",column_names,values,"medicine_rx_group_id")
                        # print(query)
                        medicine_rx_group_id = db.insert_data(query)


                if len(exercise_rxs) >0:
                    str_rx = ','.join(str(e) for e in exercise_rxs)

                    columns="exercise_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND exercise_rx_id in ("+str_rx+")  "
                    query=select_query("tblExerciseRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in exercise_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'exercise_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblExerciseRxGroup",column_names,values,"exercise_rx_group_id")
                        # print(query)
                        exercise_rx_group_id = db.insert_data(query)


                if len(extend_rxs) >0:
                    str_rx = ','.join(str(e) for e in extend_rxs)

                    columns="extend_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND extend_rx_id in ("+str_rx+")  "
                    query=select_query("tblExtendRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in extend_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'extend_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblExtendRxGroup",column_names,values,"extend_rx_group_id")
                        # print(query)
                        extend_rx_group_id = db.insert_data(query)


                if len(medical_test_rxs) >0:
                    str_rx = ','.join(str(e) for e in medical_test_rxs)

                    columns="medical_test_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND medical_test_rx_id in ("+str_rx+")  "
                    query=select_query("tblMedicalTestRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in medical_test_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'medical_test_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblMedicalTestRxGroup",column_names,values,"medical_test_rx_group_id")
                        # print(query)
                        medical_test_rx_group_id = db.insert_data(query)



            elif args['method']=='update':                
                rx_group_id = data['rx_group_id']

                gender = data['gender']
                from_age = data['from_age']
                to_age = data['to_age']
                covid_symptoms = data['covid_symptoms']
                previous_diseases = data['previous_diseases']
                test_reports = data['test_reports']

                column_names=['group_name',
                                'gender',
                                'from_age',
                                'to_age']
                values=[group_name,
                        gender,
                        str(from_age),
                        str(to_age)]
                
                where_stetment="rx_group_id = '"+str(rx_group_id)+"'"
                query=update_query("tblRxGroup",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

                for x in covid_symptoms:
                    column_names=['rx_group_id',
                                    'covid_symptom_id',
                                    'status']
                    values=[str(rx_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblCovidSymptomGroup",column_names,values,"covid_symptom_group_id")
                    # print(query)
                    covid_symptom_group_id = db.insert_data(query)

                for x in previous_diseases:
                    column_names=['rx_group_id',
                                    'previous_disease_id',
                                    'status']
                    values=[str(rx_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblPreviousDiseaseGroup",column_names,values,"previous_disease_group_id")
                    # print(query)
                    previous_disease_group_id = db.insert_data(query)

                for x in test_reports:
                    column_names=['rx_group_id',
                                    'test_report_id',
                                    'status']
                    values=[str(rx_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblTestReportGroup",column_names,values,"test_report_group_id")
                    # print(query)
                    test_report_group_id = db.insert_data(query)

            elif args['method']=='group_check':
                
                group_ids = data['group_ids']
                food_rxs = data['food_rxs']
                medicine_rxs = data['medicine_rxs']
                exercise_rxs = data['exercise_rxs']
                extend_rxs = data['extend_rxs']
                medical_test_rxs = data['medical_test_rxs']
                
                group_ids = ','.join(str(e) for e in group_ids)

                if food_rxs >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblFoodRxGroup",columns,where_stetment)                    
                    food_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in food_rx_groups:
                        if x[1]==food_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])


                if medicine_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblMedicineRxGroup",columns,where_stetment)                    
                    medicine_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in medicine_rx_groups:
                        if x[1]==medicine_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if exercise_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblExerciseRxGroup",columns,where_stetment)                    
                    exercise_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in exercise_rx_groups:
                        if x[1]==exercise_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if extend_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblExtendRxGroup",columns,where_stetment)                    
                    extend_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in extend_rx_groups:
                        if x[1]==extend_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if medical_test_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblMedicalTestRxGroup",columns,where_stetment)                    
                    medical_test_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in medical_test_rx_groups:
                        if x[1]==medical_test_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if len(group_ids) >0:
                    columns="* "
                    where_stetment="rx_group_id in ("+group_ids+") "
                    query=select_query("tblRxGroup",columns,where_stetment)                    
                    rx_groups = db.get_data(query)

                    return {'rx_groups': rx_groups}, 200
                    
                else:
                    return {'rx_groups': []}, 200

            elif args['method']=='delete':                
                rx_group_id = data['rx_group_id']

                query="DELETE FROM tblRxGroup WHERE rx_group_id = '"+str(rx_group_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            
            columns="trg.*,tu.name,td.doctor_designation"    
            where_stetment="trg.status = '1' and trg.rx_group_id = '"+str(rx_group_id)+"'  "    
            join_query="tblRxGroup as trg "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctor as td ON td.doctor_id = trg.doctor_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
            query=select_query(join_query,columns,where_stetment)                    
            rx_group = db.get_data_by_key(query)
            code =200               
                    

        return {'data': rx_group}, code

api.add_resource(PrescriptionApi, '/prescription_api')


class CovidTreatmentApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)
        args = parser.parse_args()

        patient_id = args['id']
        code =401
        covid_treatments=None
        db=Db() 

        columns=" tct.covid_treatment_id, tct.symptom_group_id,tct.rx_group_id,tct.create_date,tu.name,td.specialist,td.doctor_id,tu.profile_pic,tct.start_treatment,tct.stop_treatment "    
        where_stetment=" tct.status = '1' AND tct.patient_id = '"+str(patient_id)+"' ORDER BY tct.covid_treatment_id DESC "
        join_query="tblCovidTreatment as tct "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDoctor as td ON td.doctor_id = tct.doctor_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
        
        query=select_query(join_query,columns,where_stetment)                    
        covid_treatments = db.get_data(query)
        # print(covid_treatments)

        code =200

        return {'covid_treatments': covid_treatments}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        covid_symptom=None
        covid_treatment_id=0
        

        db=Db()

        if args['method']=='post':
            patient_id = data['patient_id']
            doctor_id = data['doctor_id']
            symptom_group_id = data['symptom_group_id']
            rx_group_id = data['rx_group_id']
            doctor_appointment_id = data['doctor_appointment_id']

            columns="covid_treatment_id"
            where_stetment="status = '1' AND doctor_appointment_id = '"+str(doctor_appointment_id)+"'  AND patient_id = '"+str(patient_id)+"' AND doctor_id = '"+str(doctor_id)+"' AND symptom_group_id = '"+str(symptom_group_id)+"' AND rx_group_id = '"+str(rx_group_id)+"' "   
            query=select_query("tblCovidTreatment",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:
                column_names=['doctor_appointment_id',
                                'patient_id',
                                'doctor_id',
                                'symptom_group_id',
                                'rx_group_id',
                                'start_treatment',
                                'stop_treatment',
                                'create_date',
                                'status']
                values=[str(doctor_appointment_id),
                        str(patient_id),
                        str(doctor_id),
                        str(symptom_group_id),
                        str(rx_group_id),
                        '0',
                        '0',
                        str(time.time()),
                        '1']
                query=insert_query("tblCovidTreatment",column_names,values,"covid_treatment_id")
                # print(query)
                covid_treatment_id = db.insert_data(query)

                

                column_names=['doctor_visited']
                values=['1']
                
                where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
                query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)



                columns="patient_name,phone_number"
                where_stetment="patient_id = '"+str(doctor_appointment[3])+"' " 
                query=select_query("tblPatient",columns,where_stetment)                    
                patient = db.get_data_by_key(query)

                columns=" td.user_id,tu.name,tda.doctor_fee,tda.user_id,tp.patient_name,tp.phone_number "    
                where_stetment=" tda.patient_id = '"+str(doctor_appointment_id)+"'  "
                join_query="tblDoctorAppointment as tda "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblPatient as tp ON tp.patient_id = tda.patient_id "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
                query=select_query(join_query,columns,where_stetment)                    
                doctor_appointment = db.get_data_by_key(query)

                received_wallet(doctor_appointment[0],doctor_appointment[2])

                msg="প্রিয় "+doctor_appointment[4]+" , ডাক্তার "+doctor_appointment[1]+" এর সাথে আপনার সাক্ষাৎ সম্পন্ন হয়েছে।"
                subject="ডাক্তারের সাথে সাক্ষাৎ "
                send_notification(doctor_appointment[3],subject,msg)
                                
                send_mobile_msg(doctor_appointment[5],msg)

            else:
                covid_treatment_id = search[0]

        elif args['method']=='start_treatment':                
            covid_treatment_id = data['covid_treatment_id']

            columns=" tct_.covid_treatment_id "    
            where_stetment=" tct.covid_treatment_id = '"+str(covid_treatment_id)+"' "
            join_query="tblCovidTreatment as tct "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblCovidTreatment as tct_ ON tct_.patient_id = tct.patient_id AND tct_.start_treatment = '1' AND tct_.stop_treatment = '0' "
            query=select_query(join_query,columns,where_stetment)                    
            covid_treatment = db.get_data_by_key(query)
            print(covid_treatment)

            if covid_treatment == None:

                column_names=['start_treatment','stop_treatment']
                values=['1','0']
                
                where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"'"
                query=update_query("tblCovidTreatment",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

                columns="covid_treatment_id"
                where_stetment="status = '1' AND covid_treatment_id = '"+str(covid_treatment_id)+"' AND start_treatment > '0' AND stop_treatment = '0' "   
                query=select_query("tblTreatmentStart",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['covid_treatment_id',
                                    'start_treatment',
                                    'stop_treatment',
                                    'status']
                    values=[str(covid_treatment_id),
                            str(time.time()),
                            '0',
                            '1']
                    query=insert_query("tblTreatmentStart",column_names,values,"treatment_start_id")
                    # print(query)
                    treatment_start_id = db.insert_data(query)
            else:
                return {'data': None}, 200
        
        elif args['method']=='stop_treatment':                
            covid_treatment_id = data['covid_treatment_id']

            column_names=['stop_treatment']
            values=['1']
            
            where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"'"
            query=update_query("tblCovidTreatment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

            columns="treatment_start_id"
            where_stetment="status = '1' AND covid_treatment_id = '"+str(covid_treatment_id)+"' AND start_treatment > '0' AND stop_treatment = '0' "   
            query=select_query("tblTreatmentStart",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search != None:
                column_names=['stop_treatment']
                values=[str(time.time())]
                
                where_stetment="treatment_start_id = '"+str(search[0])+"'"
                query=update_query("tblTreatmentStart",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)


        elif args['method']=='start_again':                
            covid_treatment_id = data['covid_treatment_id']

            column_names=['stop_treatment']
            values=['0']
            
            where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"'"
            query=update_query("tblCovidTreatment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)
            
            columns="covid_treatment_id"
            where_stetment="status = '1' AND covid_treatment_id = '"+str(covid_treatment_id)+"' AND start_treatment > '0' AND stop_treatment = '0' "   
            query=select_query("tblTreatmentStart",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['covid_treatment_id',
                                'start_treatment',
                                'stop_treatment',
                                'status']
                values=[str(covid_treatment_id),
                        str(time.time()),
                        '0',
                        '1']
                query=insert_query("tblTreatmentStart",column_names,values,"treatment_start_id")
                # print(query)
                treatment_start_id = db.insert_data(query)

        elif args['method']=='update':                
            covid_treatment_id = data['covid_treatment_id']

            patient_id = data['patient_id']
            doctor_id = data['doctor_id']
            symptom_group_id = data['symptom_group_id']
            rx_group_id = data['rx_group_id']

            column_names=['patient_id',
                            'doctor_id',
                            'symptom_group_id',
                            'rx_group_id']
            values=[str(patient_id),
                    str(doctor_id),
                    str(symptom_group_id),
                    str(rx_group_id)]
            
            where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"'"
            query=update_query("tblCovidTreatment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

        elif args['method']=='delete':                
            covid_treatment_id = data['covid_treatment_id']

            query="DELETE FROM tblCovidTreatment WHERE covid_treatment_id = '"+str(covid_treatment_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
                

        columns="* "
        where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"' "
        query=select_query("tblCovidTreatment",columns,where_stetment)                    
        covid_treatment = db.get_data_by_key(query)
        code =200               
                    

        return {'data': covid_treatment}, code

api.add_resource(CovidTreatmentApi, '/covid_treatment_api')


@app.route("/get_covid_treatment_by_id", methods=['GET'])
def get_covid_treatment_by_id():

    covid_treatment_id = request.args.get('id')

    db = Db()


    columns=" tct.* "    
    where_stetment=" tct.status = '1' AND tct.covid_treatment_id = '"+str(covid_treatment_id)+"'"
    join_query="tblCovidTreatment as tct "
    query=select_query(join_query,columns,where_stetment)                    
    covid_treatment = db.get_data_by_key(query)

    result={"covid_treatment":covid_treatment}
    # print(result)

    return jsonify(result)


@app.route("/lab_report", methods=['GET', 'POST'])
def lab_report():
    if authentication()==False:
        return redirect(url_for('login'))
    
    user_id = get_user_id()
    ct_id = request.args.get('id')
    db = Db()
    
    columns=" tp.* "    
    where_stetment="tct.covid_treatment_id = '"+str(ct_id)+"'  "
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tp ON tp.patient_id = tct.patient_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatientConnection as tpc ON tpc.patient_id = tp.patient_id AND tpc.user_id = '"+str(user_id)+"' "
    query=select_query(join_query,columns,where_stetment)                    
                         
    patient = db.get_data_by_key(query)

    if patient==None:
        return redirect(url_for('index'))
    
    return render_template('lab_report.html', title='lab_report',ct_id=ct_id,patient=patient)


@app.route("/patient_visit_doctor", methods=['GET', 'POST'])
def patient_visit_doctor():
    if authentication()==False:
        return redirect(url_for('login'))
    patient_id = request.args.get('id')
    
    return render_template('patient_visit_doctor.html', title='Patient Visit Doctor',patient_id=patient_id)

def is_doctor():

    db=Db() 
    user_id =get_user_id()

    columns="doctor_id"
    where_stetment="status = '1' AND user_id = '"+str(session['login_user'][3])+"'"  
    query=select_query("tblDoctor",columns,where_stetment)                    
    doctor = db.get_data_by_key(query)
    if doctor!=None:
        return True
    else:
        return False;

@app.route("/doctor_visit_patient", methods=['GET', 'POST'])
def doctor_visit_patient():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_doctor()==False:
        return redirect(url_for('index'))
    
    
    return render_template('doctor_visit_patient.html', title='Doctor Visit Patient')

class DoctorVisitPatientApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        rx_groups=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblRxGroup",columns,where_stetment)                    
        rx_groups = db.get_data(query)

        code =200

        return {'rx_groups': rx_groups}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        symptom_group=None
        subject_id=0
        user_id = get_user_id()
        if is_admin() == True:

            db=Db()

            if args['method']=='post':                

                parents_rx_group_id = data['rx_group_id']
                symptom_group_id = data['symptom_group_id']
                doctor_id = get_doctor_id(user_id,db)
                if doctor_id ==0:
                    return {'data': []}, 401

                food_rxs = data['food_rxs']
                medicine_rxs = data['medicine_rxs']
                exercise_rxs = data['exercise_rxs']
                extend_rxs = data['extend_rxs']
                medical_test_rxs = data['medical_test_rxs']
                # print([3, 2])
                # return {'data': []}, 200

                columns="rx_group_id"
                where_stetment="symptom_group_id = '"+str(symptom_group_id)+"' AND ( rx_group_id = '"+str(parents_rx_group_id)+"' OR  parents_rx_group_id = '"+str(parents_rx_group_id)+"') "   
                query=select_query("tblRxGroup",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                
                if search == None:
                    if parents_rx_group_id==-1:
                        parents_rx_group_id =0

                    column_names=['symptom_group_id',
                                    'parents_rx_group_id',
                                    'doctor_id',
                                    'create_date',
                                    'status']
                    values=[str(symptom_group_id),
                            str(parents_rx_group_id),
                            str(doctor_id),
                            str(time.time()),
                            '1']
                    query=insert_query("tblRxGroup",column_names,values,"rx_group_id")
                    # print(query)
                    rx_group_id = db.insert_data(query)
                else:
                    rx_group_id =search[0]



                if len(food_rxs) >0:
                    str_rx = ','.join(str(e) for e in food_rxs)

                    columns="food_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND food_rx_id in ("+str_rx+")  "
                    query=select_query("tblFoodRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)
                    # print("Foood:",food_rxs_have)

                for x in food_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'food_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblFoodRxGroup",column_names,values,"food_rx_group_id")
                        # print(query)
                        food_rx_group_id = db.insert_data(query)


                if len(medicine_rxs) >0:
                    str_rx = ','.join(str(e) for e in medicine_rxs)

                    columns="medicine_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND medicine_rx_id in ("+str_rx+")  "
                    query=select_query("tblMedicineRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in medicine_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'medicine_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblMedicineRxGroup",column_names,values,"medicine_rx_group_id")
                        # print(query)
                        medicine_rx_group_id = db.insert_data(query)


                if len(exercise_rxs) >0:
                    str_rx = ','.join(str(e) for e in exercise_rxs)

                    columns="exercise_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND exercise_rx_id in ("+str_rx+")  "
                    query=select_query("tblExerciseRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in exercise_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'exercise_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblExerciseRxGroup",column_names,values,"exercise_rx_group_id")
                        # print(query)
                        exercise_rx_group_id = db.insert_data(query)


                if len(extend_rxs) >0:
                    str_rx = ','.join(str(e) for e in extend_rxs)

                    columns="extend_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND extend_rx_id in ("+str_rx+")  "
                    query=select_query("tblExtendRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in extend_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'extend_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblExtendRxGroup",column_names,values,"extend_rx_group_id")
                        # print(query)
                        extend_rx_group_id = db.insert_data(query)


                if len(medical_test_rxs) >0:
                    str_rx = ','.join(str(e) for e in medical_test_rxs)

                    columns="medical_test_rx_id "
                    where_stetment=" rx_group_id = '"+str(rx_group_id)+"' AND medical_test_rx_id in ("+str_rx+")  "
                    query=select_query("tblMedicalTestRxGroup",columns,where_stetment)                    
                    rxs_have = db.get_data(query)

                for x in medical_test_rxs:
                    ix=(x,)
                    if ix in rxs_have:
                        pass
                    else:
                        column_names=['rx_group_id',
                                        'medical_test_rx_id',
                                        'status']
                        values=[str(rx_group_id),
                                str(x),
                                '1']
                        query=insert_query("tblMedicalTestRxGroup",column_names,values,"medical_test_rx_group_id")
                        # print(query)
                        medical_test_rx_group_id = db.insert_data(query)



            elif args['method']=='update':                
                rx_group_id = data['rx_group_id']

                gender = data['gender']
                from_age = data['from_age']
                to_age = data['to_age']
                covid_symptoms = data['covid_symptoms']
                previous_diseases = data['previous_diseases']
                test_reports = data['test_reports']

                column_names=['group_name',
                                'gender',
                                'from_age',
                                'to_age']
                values=[group_name,
                        gender,
                        str(from_age),
                        str(to_age)]
                
                where_stetment="rx_group_id = '"+str(rx_group_id)+"'"
                query=update_query("tblRxGroup",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

                for x in covid_symptoms:
                    column_names=['rx_group_id',
                                    'covid_symptom_id',
                                    'status']
                    values=[str(rx_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblCovidSymptomGroup",column_names,values,"covid_symptom_group_id")
                    # print(query)
                    covid_symptom_group_id = db.insert_data(query)

                for x in previous_diseases:
                    column_names=['rx_group_id',
                                    'previous_disease_id',
                                    'status']
                    values=[str(rx_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblPreviousDiseaseGroup",column_names,values,"previous_disease_group_id")
                    # print(query)
                    previous_disease_group_id = db.insert_data(query)

                for x in test_reports:
                    column_names=['rx_group_id',
                                    'test_report_id',
                                    'status']
                    values=[str(rx_group_id),
                            str(x),
                            '1']
                    query=insert_query("tblTestReportGroup",column_names,values,"test_report_group_id")
                    # print(query)
                    test_report_group_id = db.insert_data(query)

            elif args['method']=='group_check':
                
                group_ids = data['group_ids']
                food_rxs = data['food_rxs']
                medicine_rxs = data['medicine_rxs']
                exercise_rxs = data['exercise_rxs']
                extend_rxs = data['extend_rxs']
                medical_test_rxs = data['medical_test_rxs']
                
                group_ids = ','.join(str(e) for e in group_ids)

                if food_rxs >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblFoodRxGroup",columns,where_stetment)                    
                    food_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in food_rx_groups:
                        if x[1]==food_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])


                if medicine_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblMedicineRxGroup",columns,where_stetment)                    
                    medicine_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in medicine_rx_groups:
                        if x[1]==medicine_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if exercise_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblExerciseRxGroup",columns,where_stetment)                    
                    exercise_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in exercise_rx_groups:
                        if x[1]==exercise_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if extend_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblExtendRxGroup",columns,where_stetment)                    
                    extend_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in extend_rx_groups:
                        if x[1]==extend_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if medical_test_rxs >0 and len(group_ids) >0:

                    columns="rx_group_id,COUNT(rx_group_id) as rx_group_cnt "
                    where_stetment="rx_group_id in ("+group_ids+") group by rx_group_id "
                    query=select_query("tblMedicalTestRxGroup",columns,where_stetment)                    
                    medical_test_rx_groups = db.get_data(query)

                    group_ids=""
                    flg=0
                    for x in medical_test_rx_groups:
                        if x[1]==medical_test_rxs:
                            if flg==0:
                                group_ids=group_ids+str(x[0])
                                flg =1 
                            else:
                                group_ids=group_ids+","+str(x[0])

                if len(group_ids) >0:
                    columns="* "
                    where_stetment="rx_group_id in ("+group_ids+") "
                    query=select_query("tblRxGroup",columns,where_stetment)                    
                    rx_groups = db.get_data(query)

                    return {'rx_groups': rx_groups}, 200
                    
                else:
                    return {'rx_groups': []}, 200

            elif args['method']=='delete':                
                rx_group_id = data['rx_group_id']

                query="DELETE FROM tblRxGroup WHERE rx_group_id = '"+str(rx_group_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="rx_group_id = '"+str(rx_group_id)+"'"  
            query=select_query("tblRxGroup",columns,where_stetment)                    
            rx_group = db.get_data_by_key(query)
            code =200               
                    

        return {'data': rx_group}, code

api.add_resource(DoctorVisitPatientApi, '/doctor_visit_patient_api')


@app.route("/doctor_all_patients", methods=['GET', 'POST'])
def doctor_all_patients():

    if authentication()==False:
        return redirect(url_for('login'))

    if is_doctor()==False:
        return redirect(url_for('index'))
    
    
    return render_template('doctor_all_patients.html', title='doctor_all_patients')


@app.route("/doctor_active_patients", methods=['GET', 'POST'])
def doctor_active_patients():

    if authentication()==False:
        return redirect(url_for('login'))

    if is_doctor()==False:
        return redirect(url_for('index'))
    
    
    return render_template('doctor_active_patients.html', title='doctor_active_patients')


@app.route("/get_patients_by_doctor", methods=['GET'])
def get_patients_by_doctor():

    user_id = get_user_id()    
    offset = request.args.get('offset')
    act = request.args.get('act')
    db = Db() 
    doctor_id = get_doctor_id(user_id,db)
    patients=None 
          
    if act=='0':
        columns=" tcp.patient_id,tcp.patient_name,tcp.gender,tcp.age,tcp.profile_pic,max(tct.covid_treatment_id),max(tct.create_date) "    
        where_stetment="tct.doctor_id = '"+str(doctor_id)+"'  group by tcp.patient_id  ORDER BY max(tct.create_date) DESC LIMIT 10  OFFSET "+offset 
        join_query="tblCovidTreatment as tct "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tcp ON tcp.patient_id = tct.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
                         
        patients = db.get_data(query)
    else:
        columns=" tcp.patient_id,tcp.patient_name,tcp.gender,tcp.age,tcp.profile_pic,max(tct.covid_treatment_id),max(tct.create_date) "    
        where_stetment="tct.doctor_id = '"+str(doctor_id)+"' AND tct.start_treatment = '1' AND tct.stop_treatment = '0'  group by tcp.patient_id  ORDER BY max(tct.create_date) DESC LIMIT 10  OFFSET "+offset 
        join_query="tblCovidTreatment as tct "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tcp ON tcp.patient_id = tct.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
                         
        patients = db.get_data(query)
    code =200

    result={"patients":patients}
    

    return jsonify(result)

@app.route("/active_patients_by_doctor", methods=['GET'])
def active_patients_by_doctor():

    user_id = get_user_id()    
    offset = request.args.get('offset')
    db = Db() 
    doctor_id = get_doctor_id(user_id,db) 
          

    columns=" tcp.patient_id,tcp.patient_name,tcp.gender,tcp.age,max(tct.covid_treatment_id) "    
    where_stetment="tct.start_treatment = '1' AND tct.stop_treatment = '0' AND tct.doctor_id = '"+str(doctor_id)+"'  group by tcp.patient_id  ORDER BY max(tct.create_date) DESC LIMIT 10  OFFSET "+offset 
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tcp ON tcp.patient_id = tct.patient_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = tcp.user_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    patients = db.get_data(query)
    code =200

    result={"patients":patients}
    

    return jsonify(result)

@app.route("/find_patients_using_phone_by_doctor", methods=['GET'])
def find_patients_using_phone_by_doctor():

    user_id = get_user_id()    
    phone_number = request.args.get('phone')
    db = Db() 
    doctor_id = get_doctor_id(user_id,db) 
          

    columns=" tcp.patient_id,tcp.patient_name,tcp.gender,tcp.age,tcp.profile_pic,max(tct.covid_treatment_id) "    
    where_stetment="tcp.phone_number = '"+str(phone_number)+"' AND tct.doctor_id = '"+str(doctor_id)+"' group by tcp.patient_id "
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tcp ON tcp.patient_id = tct.patient_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    find_patients = db.get_data(query)
    code =200

    result={"find_patients":find_patients}
    

    return jsonify(result)


@app.route("/patient_rx", methods=['GET', 'POST'])
def patient_rx():
    if authentication()==False:
        return redirect(url_for('login'))

    
    user_id = get_user_id()
    ct_id = request.args.get('id')
    db = Db()
    doctor_id = get_doctor_id(user_id,db)   
    if doctor_id > 0:
        
        columns=" tp.* "    
        where_stetment="tct.covid_treatment_id = '"+str(ct_id)+"' AND tct.doctor_id = '"+str(doctor_id)+"'  "
        join_query="tblCovidTreatment as tct "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tct.patient_id "        
        query=select_query(join_query,columns,where_stetment)  
    else:
        columns=" tp.* "    
        where_stetment="tct.covid_treatment_id = '"+str(ct_id)+"'  "
        join_query="tblCovidTreatment as tct "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tct.patient_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatientConnection as tpc ON tpc.patient_id = tp.patient_id AND tpc.user_id = '"+str(user_id)+"' "
        query=select_query(join_query,columns,where_stetment)                    
                         
    patient = db.get_data_by_key(query)

    if patient==None:
        return redirect(url_for('index'))
    
    
    return render_template('patient_rx.html', title='Patient Rx',ct_id=ct_id,patient=patient)


@app.route("/get_patient_rx", methods=['GET'])
def get_patient_rx():

    patient_id = request.args.get('id')
    user_id = get_user_id()    
    db = Db() 
    doctor_id = get_doctor_id(user_id,db)

    columns=" tct.covid_treatment_id, tct.symptom_group_id,tct.rx_group_id,tct.create_date,tu.name,td.specialist,tct.start_treatment,tct.stop_treatment,(tct.doctor_id = "+str(doctor_id)+") "    
    where_stetment=" tct.status = '1' AND tct.patient_id = '"+str(patient_id)+"' "
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDoctor as td ON td.doctor_id = tct.doctor_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
    query=select_query(join_query,columns,where_stetment)                    
    covid_treatments = db.get_data(query)

    result={"covid_treatments":covid_treatments}
    

    return jsonify(result)

@app.route("/get_rx_groups_by_symptom_group_id", methods=['GET'])
def get_rx_groups_by_symptom_group_id():

    symptom_group_id = request.args.get('id')
    db = Db() 

    columns="trg.*,tu.name,td.specialist"    
    where_stetment="trg.status = '1' and trg.symptom_group_id = '"+str(symptom_group_id)+"'  "    
    join_query="tblRxGroup as trg "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDoctor as td ON td.doctor_id = trg.doctor_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
    query=select_query(join_query,columns,where_stetment)                    
    rx_groups = db.get_data(query)

    result={"rx_groups":rx_groups}
    

    return jsonify(result)

@app.route("/lab_test_report_view", methods=['GET', 'POST'])
def lab_test_report_view():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_doctor()==False:
        return redirect(url_for('index'))

    
    
    return render_template('lab_test_report_view.html', title='Patient Report View')

class ReportViewApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        covid_treatment_id = args['id']

        code =401
        patient_test_reports=None
        
        db=Db()

        columns="tmtr.*,tptr.patient_test_report_id,tptr.report_urls,tptr.doctor_report,tptr.view,tptr.create_date"    
        where_stetment="tct.status = '1' and tct.covid_treatment_id = '"+str(covid_treatment_id)+"'  ORDER BY tptr.view ASC "    
        join_query="tblCovidTreatment as tct "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblMedicalTestRxGroup as tmtrg ON tmtrg.rx_group_id = tct.rx_group_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblMedicalTestRx as tmtr ON tmtr.medical_test_rx_id = tmtrg.medical_test_rx_id "        
        join_query=join_query+"LEFT JOIN "
        join_query=join_query+"tblPatientTestReport as tptr ON tmtr.medical_test_rx_id = tptr.medical_test_rx_id "        
        query=select_query(join_query,columns,where_stetment)                    
        patient_test_reports = db.get_data(query)
        # print(patient_test_reports)

        code =200

        return {'patient_test_reports': patient_test_reports}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        patient_test_report=None
        patient_test_report_id=0
        
        db=Db()

        if args['method']=='post':
            medical_test_rx_id = data['medical_test_rx_id'] 
            covid_treatment_id = data['covid_treatment_id']
            report_urls = data['report_urls']

            columns="patient_test_report_id"
            where_stetment="medical_test_rx_id = '"+str(medical_test_rx_id)+"' AND covid_treatment_id = '"+str(covid_treatment_id)+"' "   
            query=select_query("tblPatientTestReport",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            # print("url: ",report_urls)
            if search == None:

                column_names=['medical_test_rx_id',
                                'covid_treatment_id',
                                'report_urls',
                                'create_date',
                                'view',
                                'doctor_report',
                                'status']
                values=[str(medical_test_rx_id),
                        str(covid_treatment_id),
                        report_urls,
                        str(time.time()),
                        '0',
                        '',
                        '1']
                query=insert_query("tblPatientTestReport",column_names,values,"patient_test_report_id")
                # print(query)
                patient_test_report_id = db.insert_data(query)
            else:
                patient_test_report_id = search[0]

                column_names=['report_urls',
                                'view']
                values=[report_urls,
                        '0']
                
                where_stetment="patient_test_report_id = '"+str(patient_test_report_id)+"'"
                query=update_query("tblPatientTestReport",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

        elif args['method']=='doctor_report':

            dReports = data['dReports']
            for report in dReports:

                patient_test_report_id = report[0]
                doctor_report = report[1]

                column_names=['doctor_report',
                                'view']
                values=[doctor_report,
                        '1']
                
                where_stetment="patient_test_report_id = '"+str(patient_test_report_id)+"'"
                query=update_query("tblPatientTestReport",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
                
            return {'data': []}, 200


        elif args['method']=='delete':                
            patient_test_report_id = data['patient_test_report_id']

            query="DELETE FROM tblPatientTestReport WHERE patient_test_report_id = '"+str(patient_test_report_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        # columns="*"
        # where_stetment="patient_test_report_id = '"+str(patient_test_report_id)+"'"  
        # query=select_query("tblPatientTestReport",columns,where_stetment)                    
        # patient_test_report = db.get_data_by_key(query)

        columns="tmtr.*,tptr.patient_test_report_id,tptr.report_urls,tptr.doctor_report,tptr.view,tptr.create_date"    
        where_stetment="tptr.status = '1' and tptr.patient_test_report_id = '"+str(patient_test_report_id)+"'  "    
        join_query="tblPatientTestReport as tptr "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblMedicalTestRx as tmtr ON tmtr.medical_test_rx_id = tptr.medical_test_rx_id "
        query=select_query(join_query,columns,where_stetment)                    
        patient_test_report = db.get_data_by_key(query)
        code =200               
                    

        return {'data': patient_test_report}, code

api.add_resource(ReportViewApi, '/report_view_api')

@app.route("/get_reports_by_doctor", methods=['GET'])
def get_reports_by_doctor():

    user_id = get_user_id()    
    offset = request.args.get('offset')
    db = Db() 
    doctor_id = get_doctor_id(user_id,db) 
          

    columns=" tcp.patient_id,tcp.patient_name,tcp.gender,tcp.age,tcp.hight,tcp.weight,tcp.blood_group,tcp.profile_pic,tptr.cnt,tct.symptom_group_id,tct.rx_group_id,tct.covid_treatment_id "    
    where_stetment="tct.doctor_id = '"+str(doctor_id)+"'  ORDER BY tct.create_date DESC LIMIT 10  OFFSET "+offset 
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tcp ON tcp.patient_id = tct.patient_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"(select covid_treatment_id, COUNT(covid_treatment_id) as cnt from tblPatientTestReport where view = '0' group by covid_treatment_id) as tptr  ON tptr.covid_treatment_id = tct.covid_treatment_id " 
    
    query=select_query(join_query,columns,where_stetment)
    reports = db.get_data(query)
    code =200

    result={"reports":reports}
    

    return jsonify(result)


@app.route("/patient_monitoring", methods=['GET', 'POST'])
def patient_monitoring():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_doctor()==False:
        return redirect(url_for('index'))

    pt_id = request.args.get('id')
     
    
    return render_template('patient_monitoring.html', title='patient_monitoring',pt_id=pt_id)

class DoctorMessageApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        patient_id = args['id']
        msg="unauthorized request"
        code =401
        doctor_messages=None
        db=Db()
        user_id = get_user_id()
        doctor_id = get_doctor_id(user_id,db)
        
        columns="*"
        where_stetment="doctor_id = '"+str(doctor_id)+"'  AND patient_id = '"+str(patient_id)+"' "  
        query=select_query("tblDoctorMessage",columns,where_stetment)
        doctor_messages = db.get_data(query)

        code =200

        return {'doctor_messages': doctor_messages}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        doctor_message=None
        doctor_message_id=0
        
        db=Db()

        if args['method']=='post':
            user_id = get_user_id()
            doctor_id = get_doctor_id(user_id,db) 
            patient_id = data['patient_id']
            message = rmqt(data['message'])

            columns="covid_treatment_id"
            where_stetment="doctor_id = '"+str(doctor_id)+"' AND patient_id = '"+str(patient_id)+"' AND start_treatment = '1' AND stop_treatment = '0' "   
            query=select_query("tblCovidTreatment",columns,where_stetment)                    
            search = db.get_data_by_key(query)

            if search!=None:
                column_names=['doctor_id',
                                'patient_id',
                                'message',
                                'view',
                                'create_date',
                                'status']
                values=[str(doctor_id),
                        str(patient_id),
                        message,
                        '0',
                        str(time.time()),
                        '1']
                query=insert_query("tblDoctorMessage",column_names,values,"doctor_message_id")
                # print(query)
                doctor_message_id = db.insert_data(query)

        elif args['method']=='view':

            user_id = get_user_id()                 
            doctor_message_id = data['doctor_message_id']

            columns="tdm.doctor_message_id "
            where_stetment="tpc.user_id = '"+str(user_id)+"' "                    
            
            join_query="tblPatientConnection as tpc "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctorMessage as tdm ON tmd.patient_id = tpc.patient_id  AND tdm.doctor_message_id = '"+str(doctor_message_id)+"' "
            query=select_query(join_query,columns,where_stetment)                     
            doctor_message = db.get_data_by_key(query)
            
            if search!=None:
                column_names=['view']
                values=['1']
                
                where_stetment="doctor_message_id = '"+str(doctor_message_id)+"'"
                query=update_query("tblDoctorMessage",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

        elif args['method']=='delete':

            user_id = get_user_id()
            doctor_id = get_doctor_id(user_id,db)                 
            doctor_message_id = data['doctor_message_id']

            columns="doctor_message_id"
            where_stetment="doctor_id = '"+str(doctor_id)+"' AND doctor_message_id = '"+str(doctor_message_id)+"' AND view = '0' "   
            query=select_query("tblDoctorMessage",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            
            if search!=None:

                query="DELETE FROM tblDoctorMessage WHERE doctor_message_id = '"+str(doctor_message_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
          
        
        
        columns="*"
        where_stetment="doctor_message_id = '"+str(doctor_message_id)+"' "   
        query=select_query("tblDoctorMessage",columns,where_stetment)
        doctor_message = db.get_data_by_key(query)
        code =200               
                    

        return {'data': doctor_message}, code

api.add_resource(DoctorMessageApi, '/doctor_message_api')

class CovidTreatmentResultApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        covid_treatment_id = args['id']
        msg="unauthorized request"
        code =401
        covid_treatment_results=None
        db=Db()

        
        columns="tctr.*,ts.symptom"
        where_stetment="tctr.status = '1'" 
        join_query="(select max(covid_treatment_result_id) as maxid from tblCovidTreatmentResult where covid_treatment_id = '"+str(covid_treatment_id)+"' group by symptom_id) as b  "        
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblCovidTreatmentResult as tctr on  tctr.covid_treatment_result_id = b.maxid "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tctr.symptom_id "
        query=select_query(join_query,columns,where_stetment)                     
        covid_treatment_results = db.get_data(query)
        # print(covid_treatment_results)

        code =200

        return {'covid_treatment_results': covid_treatment_results}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        covid_treatment_result=None
        covid_treatment_result_id=0
        
        db=Db()

        if args['method']=='post':
            covid_treatment_id = data['covid_treatment_id'] 
            symptom_id = data['symptom_id']  
            measure = data['measure'] 
            user_msg = rmqt(data['user_msg'])
            new_symptom = data['new_symptom']

            column_names=['covid_treatment_id',
                            'symptom_id',
                            'measure',
                            'user_msg',
                            'new_symptom',
                            'create_date',
                            'status']
            values=[str(covid_treatment_id),
                    str(symptom_id),
                    str(measure),
                    user_msg,
                    str(new_symptom),
                    str(time.time()),
                    '1']
            query=insert_query("tblCovidTreatmentResult",column_names,values,"covid_treatment_result_id")
            # print(query)
            covid_treatment_result_id = db.insert_data(query)

        elif args['method']=='delete':                
            covid_treatment_result_id = data['covid_treatment_result_id']

            query="DELETE FROM tblCovidTreatmentResult WHERE covid_treatment_result_id = '"+str(covid_treatment_result_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        
        columns="tctr.*,ts.symptom "
        where_stetment="tctr.covid_treatment_result_id = '"+str(covid_treatment_result_id)+"' "                    
        
        join_query="tblCovidTreatmentResult as tctr "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tctr.symptom_id "
        query=select_query(join_query,columns,where_stetment)                     
        covid_treatment_result = db.get_data_by_key(query)
        code =200               
                    

        return {'data': covid_treatment_result}, code

api.add_resource(CovidTreatmentResultApi, '/covid_treatment_result_api')

@app.route("/get_patient_monitoring_data", methods=['GET'])
def get_patient_monitoring_data():
  
    patient_id = request.args.get('id')
    days = request.args.get('days')
    db = Db()

    from_date = time.time()-float(days)*86400 
          

    columns="tctr.*,ts.symptom"
    where_stetment="tctr.create_date >= '"+str(from_date)+"' AND tct.patient_id = '"+str(patient_id)+"' ORDER by tctr.create_date ASC " 
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblCovidTreatmentResult as tctr ON tctr.covid_treatment_id = tct.covid_treatment_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tctr.symptom_id "
    query=select_query(join_query,columns,where_stetment)                     
    monitoring_data = db.get_data(query)
    
    code =200

    result={"monitoring_data":monitoring_data}
    

    return jsonify(result)


@app.route("/daily_report", methods=['GET', 'POST'])
def daily_report():
    if authentication()==False:
        return redirect(url_for('login'))

    # user_id = get_user_id()
    pt_id = request.args.get('id')
        
    
    return render_template('daily_report.html', title='daily_report',pt_id=pt_id)


class PatientDPTRApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        patient_id = args['id']
        msg="unauthorized request"
        code =401
        patient_dptrs=None
        db=Db()

        
        columns="tpd.*,tpt.primary_test"
        where_stetment="tpd.status = '1' " 
        join_query="(select max(patient_dptr_id) as maxid from tblPatientDPTR where patient_id = '"+str(patient_id)+"' group by primary_test_id) as b  "        
        join_query=join_query+"INNER JOIN "        
        join_query=join_query+"tblPatientDPTR as tpd ON tpd.patient_dptr_id = b.maxid "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPrimaryTest as tpt ON tpt.primary_test_id = tpd.primary_test_id "
        query=select_query(join_query,columns,where_stetment)                     
        patient_dptrs = db.get_data(query)

        code =200

        return {'patient_dptrs': patient_dptrs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        patient_dptr=None
        patient_dptr_id=0
        
        db=Db()

        if args['method']=='post':
            patient_id = data['patient_id'] 
            primary_test_id = data['primary_test_id']  
            test_value = data['test_value'] 
            report = data['report']

            column_names=['patient_id',
                            'primary_test_id',
                            'test_value',
                            'report',
                            'create_date',
                            'status']
            values=[str(patient_id),
                    str(primary_test_id),
                    str(test_value),
                    str(report),
                    str(time.time()),
                    '1']
            query=insert_query("tblPatientDPTR",column_names,values,"patient_dptr_id")
            # print(query)
            patient_dptr_id = db.insert_data(query)

        elif args['method']=='delete':                
            patient_dptr_id = data['patient_dptr_id']

            query="DELETE FROM tblPatientDPTR WHERE patient_dptr_id = '"+str(patient_dptr_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        
        columns="tpd.*,tpt.primary_test"
        where_stetment="tpd.status = '1' AND tpd.patient_dptr_id = '"+str(patient_dptr_id)+"' " 
        join_query="tblPatientDPTR as tpd "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPrimaryTest as tpt ON tpt.primary_test_id = tpd.primary_test_id "
        query=select_query(join_query,columns,where_stetment)                     
        patient_dptr = db.get_data_by_key(query)
        code =200               
                    

        return {'data': patient_dptr}, code

api.add_resource(PatientDPTRApi, '/patient_dptr_api')

@app.route("/get_patient_dptr", methods=['GET'])
def get_patient_dptr():
  
    patient_id = request.args.get('id')
    days = request.args.get('days')
    db = Db()

    from_date = time.time()-float(days)*86400


    columns="tpd.*,tpt.primary_test"
    where_stetment="tpd.create_date >= '"+str(from_date)+"' AND tpd.patient_id = '"+str(patient_id)+"'  ORDER by tpd.create_date ASC " 
    join_query="tblPatientDPTR as tpd "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPrimaryTest as tpt ON tpt.primary_test_id = tpd.primary_test_id "
    query=select_query(join_query,columns,where_stetment)                     
    patient_dptrs = db.get_data(query)
    
    code =200

    result={"patient_dptrs":patient_dptrs}
    

    return jsonify(result)


@app.route("/patient_daily_medicine", methods=['GET', 'POST'])
def patient_daily_medicine():
    if authentication()==False:
        return redirect(url_for('login'))

    # user_id = get_user_id()
    pt_id = request.args.get('id')
        
    
    return render_template('patient_daily_medicine.html', title='patient_daily_medicine',pt_id=pt_id)

@app.route("/get_medicine_by_treatment_id", methods=['GET'])
def get_medicine_by_treatment_id():

    covid_treatment_id = request.args.get('id')
    db = Db()

    columns="tm.medicine_id,tm.brand_medicine_name,tm.strength,tm.medicine_dosage_form,tds.daily_schedule,tbe.befor_eating,tmr.days_number,tmr.days_unit"
    where_stetment="tct.covid_treatment_id = '"+str(covid_treatment_id)+"' " 
    join_query="tblCovidTreatment as tct  "         
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicineRxGroup as tmrg ON tmrg.rx_group_id = tct.rx_group_id "         
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicineRx as tmr ON tmr.medicine_rx_id = tmrg.medicine_rx_id "      
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tmr.medicine_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDailySchedule as tds ON tds.daily_schedule_id = tmr.daily_schedule_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblBeforEating as tbe ON tbe.befor_eating_id = tmr.befor_eating_id "    
    
    query=select_query(join_query,columns,where_stetment)                     
    treatment_medicines = db.get_data(query)

    code =200

    result={"treatment_medicines":treatment_medicines}

    return jsonify(result)

class PatientDailyMedicineApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        covid_treatment_id = args['id']
        msg="unauthorized request"
        code =401
        patient_daily_medicines=None
        db=Db()

        
        columns="tpdm.medicine_id,tpdm.medicine_taken,TO_CHAR(tpdm.report_date, 'YYYY-MM-DD'),tm.brand_medicine_name,tm.strength,tm.medicine_dosage_form,b.cnt"
        where_stetment="tpdm.status = '1'" 
        join_query="(select max(report_date) as maxid,COUNT(medicine_id) as cnt from tblPatientDailyMedicine where covid_treatment_id = '"+str(covid_treatment_id)+"' group by medicine_id) as b  "        
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatientDailyMedicine as tpdm on  tpdm.report_date = b.maxid "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tpdm.medicine_id "
        
        
        query=select_query(join_query,columns,where_stetment)                     
        patient_daily_medicines = db.get_data(query)
        # print(patient_daily_medicines)TO_CHAR(SYSDATE, 'YYYY-MM-DD')

        code =200

        return {'patient_daily_medicines': patient_daily_medicines}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        patient_daily_medicine=None
        patient_daily_medicine_id=0
        
        db=Db()

        if args['method']=='post':
            covid_treatment_id = data['covid_treatment_id'] 
            medicine_id = data['medicine_id']  
            medicine_taken = data['medicine_taken']
            # cur_date=time.time()
            report_date = data['report_date']

            columns="patient_daily_medicine_id"
            where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"' AND medicine_id = '"+str(medicine_id)+"' AND report_date = '"+str(report_date)+"' "   
            query=select_query("tblPatientDailyMedicine",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:
                column_names=['covid_treatment_id',
                                'medicine_id',
                                'medicine_taken',
                                'report_date',
                                'status']
                values=[str(covid_treatment_id),
                        str(medicine_id),
                        str(medicine_taken),
                        str(report_date),
                        '1']
                query=insert_query("tblPatientDailyMedicine",column_names,values,"patient_daily_medicine_id")
                # print(query)
                patient_daily_medicine_id = db.insert_data(query)
            else:
                patient_daily_medicine_id = search[0]

                column_names=['medicine_taken']
                values=[str(medicine_taken)]
                
                where_stetment="patient_daily_medicine_id = '"+str(patient_daily_medicine_id)+"'"
                query=update_query("tblPatientDailyMedicine",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

        elif args['method']=='delete':                
            patient_daily_medicine_id = data['patient_daily_medicine_id']

            query="DELETE FROM tblPatientDailyMedicine WHERE patient_daily_medicine_id = '"+str(patient_daily_medicine_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        
        columns="tpdm.medicine_id,tpdm.medicine_taken,TO_CHAR(tpdm.report_date, 'YYYY-MM-DD'),tm.brand_medicine_name,tm.strength,tm.medicine_dosage_form "
        where_stetment="tpdm.patient_daily_medicine_id = '"+str(patient_daily_medicine_id)+"' "                    
        
        join_query="tblPatientDailyMedicine as tpdm "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tpdm.medicine_id "
        query=select_query(join_query,columns,where_stetment)                     
        patient_daily_medicine = db.get_data_by_key(query)
        code =200               
                    

        return {'data': patient_daily_medicine}, code

api.add_resource(PatientDailyMedicineApi, '/patient_daily_medicine_api')

@app.route("/get_patient_daily_medicine_data", methods=['GET'])
def get_patient_daily_medicine_data():
  
    patient_id = request.args.get('id')
    days = request.args.get('days')
    db = Db()

    # from_date = time.time()-float(days)*86400
    from_date = datetime.now().date() - timedelta(days=int(days)) 
          

    columns="tpdm.medicine_id,tpdm.medicine_taken,TO_CHAR(tpdm.report_date, 'YYYY-MM-DD'),tm.brand_medicine_name,tm.strength,tm.medicine_dosage_form"
    where_stetment="tpdm.report_date >= '"+str(from_date)+"' AND tct.patient_id = '"+str(patient_id)+"' ORDER by tpdm.report_date ASC " 
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatientDailyMedicine as tpdm ON tpdm.covid_treatment_id = tct.covid_treatment_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tpdm.medicine_id "
    query=select_query(join_query,columns,where_stetment)                     
    daily_medicine_datas = db.get_data(query)
    
    code =200

    result={"daily_medicine_datas":daily_medicine_datas}
    

    return jsonify(result)


@app.route("/get_food_by_treatment_id", methods=['GET'])
def get_food_by_treatment_id():

    covid_treatment_id = request.args.get('id')
    db = Db()

    columns="tfr.food,tfr.rules"
    where_stetment="tct.covid_treatment_id = '"+str(covid_treatment_id)+"' " 
    join_query="tblCovidTreatment as tct  "         
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblFoodRxGroup as tfrg ON tfrg.rx_group_id = tct.rx_group_id "         
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblFoodRx as tfr ON tfr.food_rx_id = tfrg.food_rx_id "    
    
    query=select_query(join_query,columns,where_stetment)                     
    treatment_foods = db.get_data(query)

    code =200

    result={"treatment_foods":treatment_foods}

    return jsonify(result)

class PatientDailyFoodApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        covid_treatment_id = args['id']
        msg="unauthorized request"
        code =401
        patient_daily_foods=None
        db=Db()

        
        columns="tpdf.food,tpdf.food_taken,TO_CHAR(tpdf.report_date, 'YYYY-MM-DD'),b.cnt"
        where_stetment="tpdf.status = '1'" 
        join_query="(select max(report_date) as maxid,COUNT(food) as cnt from tblPatientDailyFood where covid_treatment_id = '"+str(covid_treatment_id)+"' group by food) as b  "        
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatientDailyFood as tpdf on  tpdf.report_date = b.maxid "        
        
        query=select_query(join_query,columns,where_stetment)                     
        patient_daily_foods = db.get_data(query)

        code =200

        return {'patient_daily_foods': patient_daily_foods}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        patient_daily_food=None
        patient_daily_food_id=0
        
        db=Db()

        if args['method']=='post':
            covid_treatment_id = data['covid_treatment_id'] 
            food = data['food']  
            food_taken = data['food_taken']
            # cur_date=time.time()
            report_date = data['report_date']

            columns="patient_daily_food_id"
            where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"' AND food = '"+str(food)+"' AND report_date = '"+str(report_date)+"' "   
            query=select_query("tblPatientDailyFood",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:
                column_names=['covid_treatment_id',
                                'food',
                                'food_taken',
                                'report_date',
                                'status']
                values=[str(covid_treatment_id),
                        food,
                        str(food_taken),
                        str(report_date),
                        '1']
                query=insert_query("tblPatientDailyFood",column_names,values,"patient_daily_food_id")
                # print(query)
                patient_daily_food_id = db.insert_data(query)
            else:
                patient_daily_food_id = search[0]

                column_names=['food_taken']
                values=[str(food_taken)]
                
                where_stetment="patient_daily_food_id = '"+str(patient_daily_food_id)+"'"
                query=update_query("tblPatientDailyFood",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

        elif args['method']=='delete':                
            patient_daily_food_id = data['patient_daily_food_id']

            query="DELETE FROM tblPatientDailyFood WHERE patient_daily_food_id = '"+str(patient_daily_food_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        
        columns="tpdf.food,tpdf.food_taken,TO_CHAR(tpdf.report_date, 'YYYY-MM-DD') "
        where_stetment="tpdf.patient_daily_food_id = '"+str(patient_daily_food_id)+"' "                    
        
        join_query="tblPatientDailyFood as tpdf "
        query=select_query(join_query,columns,where_stetment)                     
        patient_daily_food = db.get_data_by_key(query)
        code =200               
                    

        return {'data': patient_daily_food}, code

api.add_resource(PatientDailyFoodApi, '/patient_daily_food_api')

@app.route("/get_patient_daily_food_data", methods=['GET'])
def get_patient_daily_food_data():
  
    patient_id = request.args.get('id')
    days = request.args.get('days')
    db = Db()

    # from_date = time.time()-float(days)*86400
    from_date = datetime.now().date() - timedelta(days=int(days)) 
          

    columns="tpdf.food,tpdf.food_taken,TO_CHAR(tpdf.report_date, 'YYYY-MM-DD') "
    where_stetment="tpdf.report_date >= '"+str(from_date)+"' AND tct.patient_id = '"+str(patient_id)+"' ORDER by tpdf.report_date ASC " 
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatientDailyFood as tpdf ON tpdf.covid_treatment_id = tct.covid_treatment_id "
    query=select_query(join_query,columns,where_stetment)                     
    daily_food_datas = db.get_data(query)
    
    code =200

    result={"daily_food_datas":daily_food_datas}
    

    return jsonify(result)


@app.route("/get_exercise_by_treatment_id", methods=['GET'])
def get_exercise_by_treatment_id():

    covid_treatment_id = request.args.get('id')
    db = Db()

    columns="tfr.exercise,tfr.rules"
    where_stetment="tct.covid_treatment_id = '"+str(covid_treatment_id)+"' " 
    join_query="tblCovidTreatment as tct  "         
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblExerciseRxGroup as tfrg ON tfrg.rx_group_id = tct.rx_group_id "         
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblExerciseRx as tfr ON tfr.exercise_rx_id = tfrg.exercise_rx_id "    
    
    query=select_query(join_query,columns,where_stetment)                     
    treatment_exercises = db.get_data(query)

    code =200

    result={"treatment_exercises":treatment_exercises}

    return jsonify(result)

class PatientDailyExerciseApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('id', required=True)         
        args = parser.parse_args()
        covid_treatment_id = args['id']
        msg="unauthorized request"
        code =401
        patient_daily_exercises=None
        db=Db()

        
        columns="tpdf.exercise,tpdf.exercise_taken,TO_CHAR(tpdf.report_date, 'YYYY-MM-DD'),b.cnt"
        where_stetment="tpdf.status = '1'" 
        join_query="(select max(report_date) as maxid,COUNT(exercise) as cnt from tblPatientDailyExercise where covid_treatment_id = '"+str(covid_treatment_id)+"' group by exercise) as b  "        
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatientDailyExercise as tpdf on  tpdf.report_date = b.maxid "        
        
        query=select_query(join_query,columns,where_stetment)                     
        patient_daily_exercises = db.get_data(query)

        code =200

        return {'patient_daily_exercises': patient_daily_exercises}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        patient_daily_exercise=None
        patient_daily_exercise_id=0
        
        db=Db()

        if args['method']=='post':
            covid_treatment_id = data['covid_treatment_id'] 
            exercise = data['exercise']  
            exercise_taken = data['exercise_taken']
            # cur_date=time.time()
            report_date = data['report_date']

            columns="patient_daily_exercise_id"
            where_stetment="covid_treatment_id = '"+str(covid_treatment_id)+"' AND exercise = '"+str(exercise)+"' AND report_date = '"+str(report_date)+"' "   
            query=select_query("tblPatientDailyExercise",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:
                column_names=['covid_treatment_id',
                                'exercise',
                                'exercise_taken',
                                'report_date',
                                'status']
                values=[str(covid_treatment_id),
                        exercise,
                        str(exercise_taken),
                        str(report_date),
                        '1']
                query=insert_query("tblPatientDailyExercise",column_names,values,"patient_daily_exercise_id")
                # print(query)
                patient_daily_exercise_id = db.insert_data(query)
            else:
                patient_daily_exercise_id = search[0]

                column_names=['exercise_taken']
                values=[str(exercise_taken)]
                
                where_stetment="patient_daily_exercise_id = '"+str(patient_daily_exercise_id)+"'"
                query=update_query("tblPatientDailyExercise",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

        elif args['method']=='delete':                
            patient_daily_exercise_id = data['patient_daily_exercise_id']

            query="DELETE FROM tblPatientDailyExercise WHERE patient_daily_exercise_id = '"+str(patient_daily_exercise_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        
        columns="tpdf.exercise,tpdf.exercise_taken,TO_CHAR(tpdf.report_date, 'YYYY-MM-DD') "
        where_stetment="tpdf.patient_daily_exercise_id = '"+str(patient_daily_exercise_id)+"' "                    
        
        join_query="tblPatientDailyExercise as tpdf "
        query=select_query(join_query,columns,where_stetment)                     
        patient_daily_exercise = db.get_data_by_key(query)
        code =200               
                    

        return {'data': patient_daily_exercise}, code

api.add_resource(PatientDailyExerciseApi, '/patient_daily_exercise_api')

@app.route("/get_patient_daily_exercise_data", methods=['GET'])
def get_patient_daily_exercise_data():
  
    patient_id = request.args.get('id')
    days = request.args.get('days')
    db = Db()

    # from_date = time.time()-float(days)*86400
    from_date = datetime.now().date() - timedelta(days=int(days)) 
          

    columns="tpdf.exercise,tpdf.exercise_taken,TO_CHAR(tpdf.report_date, 'YYYY-MM-DD') "
    where_stetment="tpdf.report_date >= '"+str(from_date)+"' AND tct.patient_id = '"+str(patient_id)+"' ORDER by tpdf.report_date ASC " 
    join_query="tblCovidTreatment as tct "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatientDailyExercise as tpdf ON tpdf.covid_treatment_id = tct.covid_treatment_id "
    query=select_query(join_query,columns,where_stetment)                     
    daily_exercise_datas = db.get_data(query)
    
    code =200

    result={"daily_exercise_datas":daily_exercise_datas}
    

    return jsonify(result)


class FoodRxApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        food_rxs=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblFoodRx",columns,where_stetment)                    
        food_rxs = db.get_data(query)

        code =200

        return {'food_rxs': food_rxs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        food_rx=None
        food_rx_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                food = rmqt(data['food']) 
                rules = rmqt(data['rules'])

                columns="food_rx_id"
                where_stetment="food = '"+food+"' AND rules = '"+rules+"' "   
                query=select_query("tblFoodRx",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['food',
                                    'rules',
                                    'create_date',
                                    'status']
                    values=[food,
                            rules,
                            str(time.time()),
                            '1']
                    query=insert_query("tblFoodRx",column_names,values,"food_rx_id")
                    # print(query)
                    food_rx_id = db.insert_data(query)
                else:
                    food_rx_id = search[0]

            elif args['method']=='update':                
                food_rx_id = data['food_rx_id']

                disease_id = data['disease_id']
                measure = data['measure']
                present = data['present']
                medicine = data['medicine']

                column_names=['food',
                                'rules']
                values=[food,
                        rules]
                
                where_stetment="food_rx_id = '"+str(food_rx_id)+"'"
                query=update_query("tblFoodRx",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                food_rx_id = data['food_rx_id']

                query="DELETE FROM tblFoodRx WHERE food_rx_id = '"+str(food_rx_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="food_rx_id = '"+str(food_rx_id)+"'"  
            query=select_query("tblFoodRx",columns,where_stetment)                    
            food_rx = db.get_data_by_key(query)

            columns="food_rx_id,rx_group_id "
            where_stetment="food_rx_id = '"+str(food_rx_id)+"' "
            query=select_query("tblFoodRxGroup",columns,where_stetment)                    
            food_rx_groups = db.get_data(query)
            code =200               
                    

        return {'data': food_rx,'food_rx_groups':food_rx_groups}, code

api.add_resource(FoodRxApi, '/food_rx_api')


class MedicineRxApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        medicine_rxs=None
        db=Db()


        columns=" tco.*,array_agg(DISTINCT tu.user_id),array_agg(DISTINCT tu.profile_pic),SUM(case when tc.class_id is null then 0 else 1 end),SUM(case when tcr.rating1 is null then 0 else 1 end),SUM(case when tcr.rating2 is null then 0 else 1 end),SUM(case when tcr.rating3 is null then 0 else 1 end),SUM(case when tcr.rating4 is null then 0 else 1 end),SUM(case when tcr.rating5 is null then 0 else 1 end) "    
        where_stetment="tmr.status = '1' and ts.user_id = '"+str(user_id)+"'  group by tco.course_id  ORDER BY tco.create_date DESC LIMIT 3  OFFSET "+offset    
        join_query="tblMedicineRx as tmr "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tmr.medicine_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDailySchedule as tds ON tds.daily_schedule_id = tmr.daily_schedule_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblBeforEating as tbe ON tbe.befor_eating_id = tmr.befor_eating_id "
        query=select_query(join_query,columns,where_stetment)                    
        medicine_rxs = db.get_data(query)

        code =200

        return {'medicine_rxs': medicine_rxs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        medicine_rx=None
        medicine_rx_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                medicine_id = data['medicine_id'] 
                daily_schedule_id = data['daily_schedule_id'] 
                befor_eating_id = data['befor_eating_id'] 
                days_number = data['days_number'] 
                days_unit = data['days_unit']

                columns="medicine_rx_id"
                where_stetment="medicine_id = '"+str(medicine_id)+"' AND daily_schedule_id = '"+str(daily_schedule_id)+"' AND befor_eating_id = '"+str(befor_eating_id)+"' AND days_number = '"+str(days_number)+"' AND days_unit = '"+str(days_unit)+"' "   
                query=select_query("tblMedicineRx",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['medicine_id',
                                    'daily_schedule_id',
                                    'befor_eating_id',
                                    'days_number',
                                    'days_unit',
                                    'create_date',
                                    'status']
                    values=[str(medicine_id),
                            str(daily_schedule_id),
                            str(befor_eating_id),
                            str(days_number),
                            days_unit,
                            str(time.time()),
                            '1']
                    query=insert_query("tblMedicineRx",column_names,values,"medicine_rx_id")
                    # print(query)
                    medicine_rx_id = db.insert_data(query)
                else:
                    medicine_rx_id = search[0]
            

            elif args['method']=='delete':                
                medicine_rx_id = data['medicine_rx_id']

                query="DELETE FROM tblMedicineRx WHERE medicine_rx_id = '"+str(medicine_rx_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            

            columns=" tmr.*,tm.medicine_dosage_form,tm.brand_medicine_name,tm.strength,tds.daily_schedule,tbe.befor_eating"    
            where_stetment="tmr.status = '1' and tmr.medicine_rx_id = '"+str(medicine_rx_id)+"' "    
            join_query="tblMedicineRx as tmr "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblMedicine as tm ON tm.medicine_id = tmr.medicine_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDailySchedule as tds ON tds.daily_schedule_id = tmr.daily_schedule_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblBeforEating as tbe ON tbe.befor_eating_id = tmr.befor_eating_id "
            query=select_query(join_query,columns,where_stetment)                    
            medicine_rx = db.get_data_by_key(query)

            columns="medicine_rx_id,rx_group_id "
            where_stetment="medicine_rx_id = '"+str(medicine_rx_id)+"' "
            query=select_query("tblMedicineRxGroup",columns,where_stetment)                    
            medicine_rx_groups = db.get_data(query)
            code =200               
                    

        return {'data': medicine_rx,'medicine_rx_groups':medicine_rx_groups}, code

api.add_resource(MedicineRxApi, '/medicine_rx_api')


class ExerciseRxApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        exercise_rxs=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblExerciseRx",columns,where_stetment)                    
        exercise_rxs = db.get_data(query)

        code =200

        return {'exercise_rxs': exercise_rxs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        exercise_rx=None
        exercise_rx_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                exercise = rmqt(data['exercise']) 
                rules = rmqt(data['rules'])

                columns="exercise_rx_id"
                where_stetment="exercise = '"+exercise+"' AND rules = '"+rules+"' "   
                query=select_query("tblExerciseRx",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['exercise',
                                    'rules',
                                    'create_date',
                                    'status']
                    values=[exercise,
                            rules,
                            str(time.time()),
                            '1']
                    query=insert_query("tblExerciseRx",column_names,values,"exercise_rx_id")
                    # print(query)
                    exercise_rx_id = db.insert_data(query)
                else:
                    exercise_rx_id = search[0]

            
            elif args['method']=='delete':                
                exercise_rx_id = data['exercise_rx_id']

                query="DELETE FROM tblExerciseRx WHERE exercise_rx_id = '"+str(exercise_rx_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="exercise_rx_id = '"+str(exercise_rx_id)+"'"  
            query=select_query("tblExerciseRx",columns,where_stetment)                    
            exercise_rx = db.get_data_by_key(query)

            columns="exercise_rx_id,rx_group_id "
            where_stetment="exercise_rx_id = '"+str(exercise_rx_id)+"' "
            query=select_query("tblExerciseRxGroup",columns,where_stetment)                    
            exercise_rx_groups = db.get_data(query)
            code =200               
                    

        return {'data': exercise_rx,'exercise_rx_groups':exercise_rx_groups}, code

api.add_resource(ExerciseRxApi, '/exercise_rx_api')


class ExtendRxApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        extend_rxs=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblExtendRx",columns,where_stetment)                    
        extend_rxs = db.get_data(query)

        code =200

        return {'extend_rxs': extend_rxs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        extend_rx=None
        extend_rx_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                extend_guide = rmqt(data['extend_guide'])

                columns="extend_rx_id"
                where_stetment="extend_guide = '"+extend_guide+"' "   
                query=select_query("tblExtendRx",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['extend_guide',
                                    'create_date',
                                    'status']
                    values=[extend_guide,
                            str(time.time()),
                            '1']
                    query=insert_query("tblExtendRx",column_names,values,"extend_rx_id")
                    # print(query)
                    extend_rx_id = db.insert_data(query)
                else:
                    extend_rx_id = search[0]
            

            elif args['method']=='delete':                
                extend_rx_id = data['extend_rx_id']

                query="DELETE FROM tblExtendRx WHERE extend_rx_id = '"+str(extend_rx_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="extend_rx_id = '"+str(extend_rx_id)+"'"  
            query=select_query("tblExtendRx",columns,where_stetment)                    
            extend_rx = db.get_data_by_key(query)

            columns="extend_rx_id,rx_group_id "
            where_stetment="extend_rx_id = '"+str(extend_rx_id)+"' "
            query=select_query("tblExtendRxGroup",columns,where_stetment)                    
            extend_rx_groups = db.get_data(query)
            code =200               
                    

        return {'data': extend_rx,'extend_rx_groups':extend_rx_groups}, code

api.add_resource(ExtendRxApi, '/extend_rx_api')


class MedicalTestRxApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        medical_test_rxs=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblMedicalTestRx",columns,where_stetment)                    
        medical_test_rxs = db.get_data(query)

        code =200

        return {'medical_test_rxs': medical_test_rxs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        medical_test_rx=None
        medical_test_rx_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                medical_test = rmqt(data['medical_test'])

                columns="medical_test_rx_id"
                where_stetment="medical_test = '"+medical_test+"' "   
                query=select_query("tblMedicalTestRx",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['medical_test',
                                    'create_date',
                                    'status']
                    values=[medical_test,
                            str(time.time()),
                            '1']
                    query=insert_query("tblMedicalTestRx",column_names,values,"medical_test_rx_id")
                    # print(query)
                    medical_test_rx_id = db.insert_data(query)
                else:
                    medical_test_rx_id = search[0]
            

            elif args['method']=='delete':                
                medical_test_rx_id = data['medical_test_rx_id']

                query="DELETE FROM tblMedicalTestRx WHERE medical_test_rx_id = '"+str(medical_test_rx_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="medical_test_rx_id = '"+str(medical_test_rx_id)+"'"  
            query=select_query("tblMedicalTestRx",columns,where_stetment)                    
            medical_test_rx = db.get_data_by_key(query)

            columns="medical_test_rx_id,rx_group_id "
            where_stetment="medical_test_rx_id = '"+str(medical_test_rx_id)+"' "
            query=select_query("tblMedicalTestRxGroup",columns,where_stetment)                    
            medical_test_rx_groups = db.get_data(query)
            code =200               
                    

        return {'data': medical_test_rx,'medical_test_rx_groups':medical_test_rx_groups}, code

api.add_resource(MedicalTestRxApi, '/medical_test_rx_api')



class RemindedRxApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        reminded_rxs=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblRemindedRx",columns,where_stetment)                    
        reminded_rxs = db.get_data(query)

        code =200

        return {'reminded_rxs': reminded_rxs}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        reminded_rx=None
        reminded_rx_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                reminded_guide = rmqt(data['reminded_guide']) 
                reminded_time = data['reminded_time'] 
                period = data['period']

                columns="reminded_rx_id"
                where_stetment="reminded_guide = '"+reminded_guide+"' AND reminded_time = '"+str(reminded_time)+"' AND period = '"+str(period)+"'  "   
                query=select_query("tblRemindedRx",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['reminded_guide',
                                    'reminded_time',
                                    'period',
                                    'create_date',
                                    'status']
                    values=[reminded_guide,
                            str(reminded_time),
                            str(period),
                            str(time.time()),
                            '1']
                    query=insert_query("tblRemindedRx",column_names,values,"reminded_rx_id")
                    # print(query)
                    reminded_rx_id = db.insert_data(query)
                else:
                    reminded_rx_id = search[0]

            
            elif args['method']=='delete':                
                reminded_rx_id = data['reminded_rx_id']

                query="DELETE FROM tblRemindedRx WHERE reminded_rx_id = '"+str(reminded_rx_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="reminded_rx_id = '"+str(reminded_rx_id)+"'"  
            query=select_query("tblRemindedRx",columns,where_stetment)                    
            reminded_rx = db.get_data_by_key(query)

            columns="reminded_rx_id,rx_group_id "
            where_stetment="reminded_rx_id = '"+str(reminded_rx_id)+"' "
            query=select_query("tblRemindedRxGroup",columns,where_stetment)                    
            reminded_rx_groups = db.get_data(query)
            code =200               
                    

        return {'data': reminded_rx,'reminded_rx_groups':reminded_rx_groups}, code

api.add_resource(RemindedRxApi, '/reminded_rx_api')

@app.route("/medicine_dosage_forms", methods=['GET', 'POST'])
def medicine_dosage_forms():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('medicine_dosage_forms.html', title='Medicine dosage forms')

class MedicineDosageFormApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        medicine_dosage_forms=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblMedicineDosageForms",columns,where_stetment)                    
        medicine_dosage_forms = db.get_data(query)

        code =200

        return {'medicine_dosage_forms': medicine_dosage_forms}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        medicine_dosage_form=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                dosage_form = rmqt(data['dosage_form'])
                detail = rmqt(data['detail'])
                short_form = rmqt(data['short_form'])

                columns="medicine_dosage_forms_id"
                where_stetment="dosage_form = '"+dosage_form+"' "   
                query=select_query("tblMedicineDosageForms",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['dosage_form',
                                    'detail',
                                    'short_form',
                                    'status']
                    values=[dosage_form,
                            detail,
                            short_form,
                            '1']
                    query=insert_query("tblMedicineDosageForms",column_names,values,"medicine_dosage_forms_id")
                    # print(query)
                    medicine_dosage_forms_id = db.insert_data(query)

            elif args['method']=='update':                
                medicine_dosage_forms_id = data['medicine_dosage_forms_id']

                dosage_form = rmqt(data['dosage_form'])
                detail = rmqt(data['detail'])
                short_form = rmqt(data['short_form'])

                column_names=['dosage_form',
                                'detail',
                                'short_form',
                                'status']
                values=[dosage_form,
                        detail,
                        short_form,
                        '1']
                
                where_stetment="medicine_dosage_forms_id = '"+str(medicine_dosage_forms_id)+"'"
                query=update_query("tblMedicineDosageForms",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                medicine_dosage_forms_id = data['medicine_dosage_forms_id']

                query="DELETE FROM tblMedicineDosageForms WHERE medicine_dosage_forms_id = '"+str(medicine_dosage_forms_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="medicine_dosage_forms_id = '"+str(medicine_dosage_forms_id)+"'"  
            query=select_query("tblMedicineDosageForms",columns,where_stetment)                    
            medicine_dosage_form = db.get_data_by_key(query)
            code =200               
                    

        return {'data': medicine_dosage_form}, code

api.add_resource(MedicineDosageFormApi, '/medicine_dosage_form_api')

@app.route("/daily_schedule", methods=['GET', 'POST'])
def daily_schedule():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('daily_schedule.html', title='Daily Schedule')

class DailyScheduleApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        daily_schedules=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblDailySchedule",columns,where_stetment)                    
        daily_schedules = db.get_data(query)

        code =200

        return {'daily_schedules': daily_schedules}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        daily_schedule=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                daily_schedule = rmqt(data['daily_schedule'])

                columns="daily_schedule_id"
                where_stetment="daily_schedule = '"+daily_schedule+"' "   
                query=select_query("tblDailySchedule",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['daily_schedule',
                                    'status']
                    values=[daily_schedule,
                            '1']
                    query=insert_query("tblDailySchedule",column_names,values,"daily_schedule_id")
                    # print(query)
                    daily_schedule_id = db.insert_data(query)

            elif args['method']=='update':                
                daily_schedule_id = data['daily_schedule_id']

                daily_schedule = rmqt(data['daily_schedule'])

                column_names=['daily_schedule',
                                'status']
                values=[daily_schedule,
                        '1']
                
                where_stetment="daily_schedule_id = '"+str(daily_schedule_id)+"'"
                query=update_query("tblDailySchedule",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                daily_schedule_id = data['daily_schedule_id']

                query="DELETE FROM tblDailySchedule WHERE daily_schedule_id = '"+str(daily_schedule_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="daily_schedule_id = '"+str(daily_schedule_id)+"'"  
            query=select_query("tblDailySchedule",columns,where_stetment)                    
            daily_schedule = db.get_data_by_key(query)
            code =200               
                    

        return {'data': daily_schedule}, code

api.add_resource(DailyScheduleApi, '/daily_schedule_api')

@app.route("/befor_eating", methods=['GET', 'POST'])
def befor_eating():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('befor_eating.html', title='befor_eating')

class BeforEatingApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        befor_eatings=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblBeforEating",columns,where_stetment)                    
        befor_eatings = db.get_data(query)

        code =200

        return {'befor_eatings': befor_eatings}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        befor_eating=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                befor_eating = rmqt(data['befor_eating'])

                columns="befor_eating_id"
                where_stetment="befor_eating = '"+befor_eating+"' "   
                query=select_query("tblBeforEating",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['befor_eating',
                                    'status']
                    values=[befor_eating,
                            '1']
                    query=insert_query("tblBeforEating",column_names,values,"befor_eating_id")
                    # print(query)
                    befor_eating_id = db.insert_data(query)

            elif args['method']=='update':                
                befor_eating_id = data['befor_eating_id']

                befor_eating = rmqt(data['befor_eating'])

                column_names=['befor_eating',
                                'status']
                values=[befor_eating,
                        '1']
                
                where_stetment="befor_eating_id = '"+str(befor_eating_id)+"'"
                query=update_query("tblBeforEating",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                befor_eating_id = data['befor_eating_id']

                query="DELETE FROM tblBeforEating WHERE befor_eating_id = '"+str(befor_eating_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="befor_eating_id = '"+str(befor_eating_id)+"'"  
            query=select_query("tblBeforEating",columns,where_stetment)                    
            befor_eating = db.get_data_by_key(query)
            code =200               
                    

        return {'data': befor_eating}, code

api.add_resource(BeforEatingApi, '/befor_eating_api')

@app.route("/medicine", methods=['GET', 'POST'])
def medicine():

    if authentication()==False:
        return redirect(url_for('login'))

      
    
    return render_template('medicine.html', title='Medicine')

class MedicineApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()      
        parser.add_argument('offset', required=True)      
        args = parser.parse_args()
        offset = args['offset']
        code =401
        medicines=None
        db=Db() 

        columns="*"
        where_stetment="status = '1' ORDER BY brand_medicine_name ASC LIMIT 100  OFFSET "+offset   
        query=select_query("tblMedicine",columns,where_stetment)                    
        medicines = db.get_data(query)

        code =200

        return {'medicines': medicines}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        medicine=None
        medicine_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                generic_medicine_name = rmqt(data['generic_medicine_name'])
                brand_medicine_name = rmqt(data['brand_medicine_name'])
                brand_name = rmqt(data['brand_name'])
                medicine_dosage_form = data['medicine_dosage_form']
                strength = data['strength']

                columns="medicine_id"
                where_stetment="generic_medicine_name = '"+generic_medicine_name+"' AND brand_medicine_name = '"+brand_medicine_name+"' AND strength = '"+strength+"'  AND medicine_dosage_form = '"+medicine_dosage_form+"' "  
                query=select_query("tblMedicine",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['generic_medicine_name',
                                    'brand_medicine_name',
                                    'medicine_dosage_form',
                                    'strength',
                                    'brand_name',
                                    'status']
                    values=[generic_medicine_name,
                            brand_medicine_name,
                            medicine_dosage_form,
                            strength,
                            brand_name,
                            '1']
                    query=insert_query("tblMedicine",column_names,values,"medicine_id")
                    # print(query)
                    medicine_id = db.insert_data(query)

            elif args['method']=='update':                
                medicine_id = data['medicine_id']

                generic_medicine_name = rmqt(data['generic_medicine_name'])
                brand_medicine_name = rmqt(data['brand_medicine_name'])
                brand_name = rmqt(data['brand_name'])
                medicine_dosage_form = data['medicine_dosage_form']
                strength = data['strength']

                column_names=['generic_medicine_name',
                                'brand_medicine_name',
                                'medicine_dosage_form',
                                'strength',
                                'brand_name',
                                'status']
                values=[generic_medicine_name,
                        brand_medicine_name,
                        medicine_dosage_form,
                        strength,
                        brand_name,
                        '1']
                
                where_stetment="medicine_id = '"+str(medicine_id)+"'"
                query=update_query("tblMedicine",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                medicine_id = data['medicine_id']

                query="DELETE FROM tblMedicine WHERE medicine_id = '"+str(medicine_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="medicine_id = '"+str(medicine_id)+"'"  
            query=select_query("tblMedicine",columns,where_stetment)                    
            medicine = db.get_data_by_key(query)
            code =200               
                    

        return {'data': medicine}, code

api.add_resource(MedicineApi, '/medicine_api')


def get_doctor_id(user_id,db):
    columns="doctor_id"
    where_stetment="status = '1' and user_id = "+str(user_id)  
    query=select_query("tblDoctor",columns,where_stetment)                    
    doctor = db.get_data_by_key(query)
    if doctor !=None:
        return doctor[0]
    else:
        return 0


@app.route("/add_doctor", methods=['GET', 'POST'])
def add_doctor():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('add_doctor.html', title='add_doctor')


class AddDoctorApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        parser.add_argument('phone', required=True)      
        args = parser.parse_args()
        phone_number = args['phone']
        code =401
        find_user=None
        if authentication() == True:
            db=Db()        

            columns="user_id,name,gender,profile_pic,district,town,village"
            where_stetment="phone_number = '"+str(phone_number) +"'" 
            query=select_query("tblUser",columns,where_stetment)                    
            find_user = db.get_data_by_key(query)

            code =200

        return {'find_user': find_user}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        doctor=None
        doctor_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='post':
                
                find_user_id = data['find_user_id']
                dmsi = rmqt(data['dmsi'])
                degree = rmqt(data['degree'])
                doctor_designation = rmqt(data['doctor_designation'])
                specialist = rmqt(data['specialist'])
                doctor_workplace = rmqt(data['doctor_workplace'])
                fee_first_time = data['fee_first_time']
                fee_next_time = data['fee_next_time']
                doctor_shedule = data['doctor_shedule']
                one_day_max_patient = data['one_day_max_patient']

                columns="doctor_id"
                where_stetment="user_id = '"+str(find_user_id)+"'"  
                query=select_query("tblDoctor",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['user_id',
                                    'dmsi',
                                    'degree',
                                    'doctor_designation',
                                    'specialist',
                                    'doctor_workplace',
                                    'fee_first_time',
                                    'fee_next_time',
                                    'doctor_shedule',
                                    'one_day_max_patient',
                                    'create_date',
                                    'status']
                    values=[str(find_user_id),
                            dmsi,
                            degree,
                            doctor_designation,
                            specialist,
                            doctor_workplace,
                            str(fee_first_time),
                            str(fee_next_time),
                            doctor_shedule,
                            one_day_max_patient,
                            str(time.time()),
                            '1']
                    query=insert_query("tblDoctor",column_names,values,"doctor_id")
                    # print(query)
                    doctor_id = db.insert_data(query)
                    

            elif args['method']=='update':                
                doctor_id = data['doctor_id']
                dmsi = rmqt(data['dmsi'])
                degree = rmqt(data['degree'])
                doctor_designation = rmqt(data['doctor_designation'])
                specialist = rmqt(data['specialist'])
                doctor_workplace = rmqt(data['doctor_workplace'])
                fee_first_time = data['fee_first_time']
                doctor_shedule = data['doctor_shedule']
                one_day_max_patient = data['one_day_max_patient']

                column_names=['dmsi',
                                'degree',
                                'doctor_designation',
                                'specialist',
                                'doctor_workplace',
                                'fee_first_time',
                                'doctor_shedule',
                                'one_day_max_patient']
                values=[dmsi,
                        degree,
                        doctor_designation,
                        specialist,
                        doctor_workplace,
                        str(fee_first_time),
                        doctor_shedule,
                        one_day_max_patient]

                where_stetment="doctor_id = '"+str(doctor_id)+"'"
                query=update_query("tblDoctor",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query) 

            elif args['method']=='doctor_cancel':
                if is_admin() == True:

                    doctor_id = data['doctor_id']

                    column_names=['status']
                    values=['0']

                    where_stetment="doctor_id = '"+str(doctor_id)+"'"
                    query=update_query("tblDoctor",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)
              
            
            
            columns=" tu.name, tu.profile_pic,td.* "    
            where_stetment="td.doctor_id = "+str(doctor_id)  
            join_query="tblDoctor as td "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
            query=select_query(join_query,columns,where_stetment)                    
            doctor = db.get_data_by_key(query)
            code =200               
                    

        return {'data': doctor}, code

api.add_resource(AddDoctorApi, '/add_doctor_api')


@app.route("/doctor_account_balance", methods=['GET', 'POST'])
def doctor_account_balance():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('doctor_account_balance.html', title='doctor_account_balance')


class DoctorAccountBalanceApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        parser.add_argument('phone', required=True)      
        args = parser.parse_args()
        phone_number = args['phone']
        code =401
        find_user=None
        if authentication() == True:
            db=Db()        

            columns="user_id,name,gender,profile_pic,district,town,village"
            where_stetment="phone_number = '"+str(phone_number) +"'" 
            query=select_query("tblUser",columns,where_stetment)                    
            find_user = db.get_data_by_key(query)

            code =200

        return {'find_user': find_user}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        doctor_account_balance=None
        doctor_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='add_account':
                
                user_id = get_user_id();
                bank_name = rmqt(data['bank_name'])
                bank_account_info = rmqt(data['bank_account_info'])
                bank_account = rmqt(data['bank_account'])

                columns="user_bank_account_id"
                where_stetment="user_id = '"+str(user_id)+"'"  
                query=select_query("tblUserBankAccount",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:                    

                    column_names=['user_id',
                                    'bank_name',
                                    'bank_account_info',
                                    'bank_account',
                                    'create_date',
                                    'status']
                    values=[str(find_user_id),
                            bank_name,
                            bank_account_info,
                            bank_account,
                            str(time.time()),
                            '1']
                    query=insert_query("tblUserBankAccount",column_names,values,"user_bank_account_id")
                    # print(query)
                    user_bank_account_id = db.insert_data(query)

            elif args['method']=='update_account':                
                user_bank_account_id = data['user_bank_account_id']
                bank_name = rmqt(data['bank_name'])
                bank_account_info = rmqt(data['bank_account_info'])
                bank_account = rmqt(data['bank_account'])

                column_names=['bank_name',
                                'bank_account_info',
                                'bank_account']
                values=[bank_name,
                        bank_account_info,
                        bank_account]

                where_stetment="user_bank_account_id = '"+str(user_bank_account_id)+"'"
                query=update_query("tblUserBankAccount",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
            
            
            columns=" tuba.* "    
            where_stetment="tuba.user_bank_account_id = "+str(user_bank_account_id)  
            join_query="tblUserBankAccount as tuba "
            query=select_query(join_query,columns,where_stetment)                    
            doctor_account_balance = db.get_data_by_key(query)
            code =200               
                    

        return {'data': doctor_account_balance}, code

api.add_resource(DoctorAccountBalanceApi, '/doctor_account_balance_api')


@app.route("/doctors", methods=['GET', 'POST'])
def doctors():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('doctors.html', title='doctors')

@app.route("/get_doctors", methods=['GET'])
def get_doctors():

    offset = request.args.get('offset')
    db = Db()    

    columns=" tu.name, tu.profile_pic,td.* "    
    where_stetment="td.status = '1' ORDER BY td.doctor_id DESC LIMIT 10  OFFSET "+offset
    join_query="tblDoctor as td "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    doctors = db.get_data(query)
    code =200

    result={"doctors":doctors}
    

    return jsonify(result)
 
@app.route("/get_doctor_by_id", methods=['GET'])
def get_doctor_by_id():

    doctor_id = request.args.get('id')
    db = Db()
    user_id = get_user_id() 

    doctor=None

    columns=" tu.name, tu.profile_pic,td.* "    
    where_stetment="td.status = '1' AND td.doctor_id = '"+str(doctor_id)+"' "
    join_query="tblDoctor as td "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    doctor = db.get_data_by_key(query)
    code =200

    result={"doctor":doctor}
    

    return jsonify(result)


@app.route("/patient_appointment", methods=['GET', 'POST'])
def patient_appointment():
    
    if authentication()==False:
        return redirect(url_for('login'))

    patient_id = request.args.get('id')
    

    return render_template('patient_appointment.html', title='patient_appointment',patient_id=patient_id)


@app.route("/patient_details", methods=['GET', 'POST'])
def patient_details():
    
    if authentication()==False:
        return redirect(url_for('login'))

    patient_id = request.args.get('id')
    

    return render_template('patient_details.html', title='patient_details',patient_id=patient_id)

@app.route("/get_patient_by_id", methods=['GET'])
def get_patient_by_id():

    patient_id = request.args.get('id')
    db = Db()
    user_id = get_user_id() 

    patient=None

    if is_doctor()==True:
        columns="*"
        where_stetment="status = '1' AND patient_id = '"+str(patient_id)+"' "  
        query=select_query("tblPatient",columns,where_stetment)                    
        patient = db.get_data_by_key(query)
    else:
        columns=" tp.* "    
        where_stetment="tpc.status = '1' AND tpc.user_id ='"+str(user_id)+"'  AND tpc.patient_id ='"+str(patient_id)+"' "
        join_query="tblPatientConnection as tpc "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tpc.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
                         
        patient = db.get_data_by_key(query)
    code =200

    result={"patient":patient}
    

    return jsonify(result)


@app.route("/doctor_appointment", methods=['GET', 'POST'])
def doctor_appointment():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('doctor_appointment.html', title='doctor_appointment')


class DoctorAppointmentApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        parser.add_argument('doctor_visited', required=True)        
        parser.add_argument('offset', required=True)      
        args = parser.parse_args()
        doctor_visited = args['doctor_visited']
        offset = args['offset']
        code =401
        doctor_appointments=None
        if authentication() == True:
            db=Db()
            user_id = get_user_id();        

            columns=" tu.name,tu.profile_pic, td.specialist, td.doctor_shedule,tda.* "    
            where_stetment="tda.status = '1' AND tpc.user_id = '"+str(user_id)+"' AND tda.doctor_visited = '"+str(doctor_visited)+"' ORDER BY tda.create_date  ASC LIMIT 10  OFFSET "+offset   
            join_query="tblPatientConnection as tpc "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctorAppointment as tda ON tda.patient_id = tpc.patient_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
            query=select_query(join_query,columns,where_stetment)                             
            doctor_appointments = db.get_data(query)

            code =200

        return {'doctor_appointments': doctor_appointments}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        doctor_appointment=None
        doctor_appointment_id=0

        db=Db()

        if args['method']=='post':

            user_id = get_user_id()
            
            doctor_id = data['doctor_id']
            doctor_fee = data['doctor_fee']
            patient_id = data['patient_id']
            symptom_group_id = data['symptom_group_id']
            online = data['online']

            last_date =time.time()
            last_date =last_date - last_date%86400
            next_date = last_date + 86400

            columns=" td.one_day_max_patient,COUNT(td.doctor_id)  "    
            where_stetment="tda.doctor_id = '"+str(doctor_id)+"' AND ( ( tda.create_date > '"+str(last_date)+"' AND tda.create_date < '"+str(next_date)+"' ) OR tda.doctor_visited ='0' ) group by td.doctor_id "
            join_query="tblDoctorAppointment as tda "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
            query=select_query(join_query,columns,where_stetment)                  
            doctor_appointment = db.get_data_by_key(query)

            if doctor_appointment != None and doctor_appointment[0]<=doctor_appointment[1]:
                return {'flg': 0,'data':None,'msg':'ডাক্তারের আজকের কোটা পূরণ হয়েগেছে।'}, 200

            columns="doctor_appointment_id"
            where_stetment="status = '1' AND patient_id = '"+str(patient_id)+"' AND doctor_visited = '0' " 
            query=select_query("tblDoctorAppointment",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:
                ct_date=time.time()-2592000

                columns=" MAX(td.fee_next_time)  "    
                where_stetment="tct.status = '1' AND tct.patient_id = '"+str(patient_id)+"' AND tct.doctor_id = '"+str(doctor_id)+"' AND tct.create_date >= '"+str(ct_date)+"'  group by td.doctor_id "
                join_query="tblCovidTreatment as tct "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblDoctor as td ON td.doctor_id = tct.doctor_id "
                query=select_query(join_query,columns,where_stetment)                  
                doctor_treatment = db.get_data_by_key(query)
                if doctor_treatment!=None:
                    doctor_fee=doctor_treatment[0]

                column_names=['doctor_id',
                                'patient_id',
                                'symptom_group_id',
                                'doctor_fee',
                                'appointment_time',
                                'doctor_visited',
                                'paid',
                                'connecting',
                                'room_name',
                                'online',
                                'user_id',
                                'create_date',
                                'status']
                values=[str(doctor_id),
                        str(patient_id),
                        str(symptom_group_id),
                        str(doctor_fee),
                        '0',
                        '0',
                        '0',
                        '0',
                        '',
                        str(online),
                        str(user_id),
                        str(time.time()),
                        '1']
                query=insert_query("tblDoctorAppointment",column_names,values,"doctor_appointment_id")
                # print(query)
                doctor_appointment_id = db.insert_data(query)
                

                columns=" tu.name,tu.profile_pic, td.specialist, td.doctor_shedule,tda.* "    
                where_stetment="tda.status = '1' AND tda.doctor_appointment_id = '"+str(doctor_appointment_id)+"'  "
                join_query="tblDoctorAppointment as tda "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
                query=select_query(join_query,columns,where_stetment)                    
                                 
                doctor_appointment = db.get_data_by_key(query)

                columns="patient_name,phone_number"
                where_stetment="patient_id = '"+str(patient_id)+"' " 
                query=select_query("tblPatient",columns,where_stetment)                    
                patient = db.get_data_by_key(query)

                msg="প্রিয় "+patient[0]+" , ডাক্তার "+doctor_appointment[0]+" কে সাক্ষাতের অনুরোধ পাঠানো হয়েছে  অনুগ্রহপূর্বক ডাক্তার ফি পরিশোধ করুন।"
                subject="ডাক্তার অ্যাপয়েন্টমেন্ট "
                send_notification(user_id,subject,msg)
                                
                send_mobile_msg(patient[1],msg)

                return {'flg': 1,'data':doctor_appointment,'msg':msg}, 200
            else:
                return {'flg': 0,'data':None,'msg':'আপনার ইতোমধ্যে একটি অ্যাপয়েন্টমেন্ট নেওয়া আছে।'}, 200

        elif args['method']=='update':                
            doctor_appointment_id = data['doctor_appointment_id']
            doctor_id = data['doctor_id']
            doctor_fee = data['doctor_fee']
            patient_id = data['patient_id']
            symptom_group_id = data['symptom_group_id']
            online = data['online']

            column_names=['doctor_id',
                            'patient_id',
                            'symptom_group_id',
                            'doctor_fee',
                            'online']
            values=[str(doctor_id),
                    str(patient_id),
                    str(symptom_group_id),
                    str(doctor_fee),
                    str(online)]

            where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
            query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

            # return {'flg': 1,'msg':'Successfully'}, 200 

        elif args['method']=='pay':                
            doctor_appointment_id = data['doctor_appointment_id']

            user_id = get_user_id()

            
            columns=" tda.doctor_id,tda.doctor_fee,tu.name,tda.patient_id "    
            where_stetment="tda.status = '1' AND tda.doctor_appointment_id = '"+str(doctor_appointment_id)+"'  "   
            join_query="tblDoctorAppointment as tda "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
            query=select_query(join_query,columns,where_stetment)                             
            doctor_appointment = db.get_data_by_key(query)
            # print(doctor_appointment)
            if doctor_appointment!=None:
                daily_care_charge = 25
                vat_tax = 0
                total_fee = doctor_appointment[1]+daily_care_charge

                columns="received,pay"
                where_stetment="status = '1' and user_id = "+str(user_id)  
                query=select_query("tblAccountBalance",columns,where_stetment)              
                wallet = db.get_data_by_key(query)
                # print(wallet)
                # print(total_fee)

                if wallet!=None and (wallet[0]-wallet[1])>=total_fee:

                    columns="pay_doctor_fee_id"
                    where_stetment="doctor_appointment_id = "+str(doctor_appointment_id)  
                    query=select_query("tblPayDoctorFee",columns,where_stetment)                    
                    pay_doctor_fee = db.get_data_by_key(query)
                    # print(pay_doctor_fee)
                    if pay_doctor_fee==None:
                        column_names=['user_id',
                                        'doctor_appointment_id',
                                        'daily_care_charge',
                                        'vat_tax',
                                        'pay_date',
                                        'status']
                        values=[str(user_id),
                                str(doctor_appointment_id),
                                str(daily_care_charge),
                                str(vat_tax),
                                str(time.time()),
                                '1']
                        
                        query=insert_query("tblPayDoctorFee",column_names,values,"pay_doctor_fee_id")
                        # print(query)
                        pay_doctor_fee_id = db.insert_data(query)

                        pay_wallet(user_id,total_fee)
                        # received_wallet(doctor_appointment[2],doctor_appointment[1])

                        column_names=['paid']
                        values=['1']

                        where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
                        query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
                        # print(query)
                    
                        res = db.update_data(query)
                        # print(res)

                        columns="patient_name,phone_number"
                        where_stetment="patient_id = '"+str(doctor_appointment[3])+"' " 
                        query=select_query("tblPatient",columns,where_stetment)                    
                        patient = db.get_data_by_key(query)

                        msg="প্রিয় "+patient[0]+" , ডাক্তার "+doctor_appointment[2]+" কে দেখাতে "+doctor_appointment[1]+" টাকা ফি প্রদানের জন্য আপনাকে অসংখ্য ধন্যবাদ।"
                        subject="ডাক্তার ফি পরিশোধ "
                        send_notification(user_id,subject,msg)
                                        
                        send_mobile_msg(patient[1],msg)

                        return {'flg': 1,'data':None}, 200 
                else:
                    
                    columns="employee_id"
                    where_stetment="status = '1' AND grade = '3' AND user_id = '"+str(user_id)+"' "  
                    query=select_query("tblEmployee",columns,where_stetment)                    
                    search = db.get_data_by_key(query)
                    if search!=None:
                        return {'flg': 2,'msg':'পর্যাপ্ত ব্যালেন্স নাই, রোগীর কাছ থেকে ডাক্তার ফি সংগ্রহ করুন।','url':'/doctor_fee_collection'}, 200
                    else:
                        columns="transaction_url"
                        where_stetment="status = '1' AND done = '0' AND user_id = '"+str(user_id)+"' "  
                        query=select_query("tblPaymentRequest",columns,where_stetment)                    
                        search = db.get_data_by_key(query)
                        if search!=None:
                            return {'flg': 2,'msg':'পর্যাপ্ত ব্যালেন্স নাই,ব্যালেন্স আপলোড করুন।','url':search[0]}, 200
                        else:
                            # Creat payment getway lingk
                            url = 'https://dailycarebd.com/v1/ecom-payment/initiate'
                            transaction_id = "DF"+str(user_id)+str(int(time.time()))
                            obj = {'amount': total_fee,
                                    'transaction_id': transaction_id,
                                    'success_url': 'https://dailycarebd.com/payment_success?id='+transaction_id,
                                    'fail_url': 'https://dailycarebd.com/failed',
                                    'customer_name': 'customer_name',
                                    'purpose': 'payment for doctor fee'
                            }

                            #use the 'headers' parameter to set the HTTP headers:
                            response = requests.post(url, data = obj, headers = {"client-id": "client-id","client-secret": "client-secret"})
                            # print(response.code)
                            if response.code == 200:
                                result = response.json()
                                print(result['data'])
                                print(result['data']['link'])
                                url = result['data']['link']
                                column_names=['user_id',
                                                'transaction_id',
                                                'transaction_url',
                                                'create_date',
                                                'done',
                                                'status']
                                values=[str(user_id),
                                        transaction_id,
                                        url,
                                        str(time.time()),
                                        '0',
                                        '1']
                                
                                query=insert_query("tblPaymentRequest",column_names,values,"payment_request_id")
                                # print(query)
                                payment_request_id = db.insert_data(query)

                                return {'flg': 2,'msg':'পর্যাপ্ত ব্যালেন্স নাই,ব্যালেন্স আপলোড করুন।','url':url}, 200

            return {'flg': 0,'data':None}, 200 

        elif args['method']=='connecting':

            doctor_appointment_id = data['doctor_appointment_id']
            # room_name = str(uuid.uuid4())

            column_names=['connecting','appointment_time']
            values=['1',str(time.time())]

            where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
            query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

            patient_id =  data['patient_id']

            columns=" tu.auth_id  "    
            where_stetment="tpc.patient_id = '"+str(patient_id)+"' "
            join_query="tblPatientConnection as tpc "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = tpc.user_id "
            query=select_query(join_query,columns,where_stetment)        
            search = db.get_data_by_key(query)
            # print("sss",search)
            if search != None:
                # [START send_to_token]
               
                # See documentation on defining a message payload.
                # message = messaging.Message(
                #     data={
                #         'title': '850',
                #         'body': '2:45',
                #         'icon': 'icon',
                #         'meetingId': '2:45',
                #     },
                #     token=auth_id,
                # )
                # (title=None, body=None, icon=None, color=None, sound=None, tag=None, click_action=None, body_loc_key=None, body_loc_args=None, title_loc_key=None, title_loc_args=None, channel_id=None, image=None, ticker=None, sticky=None, event_timestamp=None, local_only=None, priority=None, vibrate_timings_millis=None, default_vibrate_timings=None, default_sound=None, light_settings=None, default_light_settings=None, visibility=None, notification_count=None)
                
                # help(messaging.AndroidNotification())
                # print(search[0])

                try:                    

                    message = messaging.Message(
                        android=messaging.AndroidConfig(
                            ttl=timedelta(seconds=3600),
                            priority='normal',
                            notification=messaging.AndroidNotification(
                                title='Doctor Calling',
                                body='Click here for attend call.',
                                tag="doctor Name",
                                icon='icon',
                            ),
                        ),
                        token=search[0],
                    )

                    # Send a message to the device corresponding to the provided
                    # registration token.
                    response = messaging.send(message)
                    # Response is a message ID string.
                    print('Successfully sent message:', response)
                    # [END send_to_token]
                    
                except Exception as e:
                    pass


            return {'connecting': 1}, 200  

        elif args['method']=='cancel':

            doctor_appointment_id = data['doctor_appointment_id']
            # room_name = str(uuid.uuid4())

            column_names=['connecting','appointment_time','room_name']
            values=['0','0','']

            where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
            query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

            return {'cancel': 1}, 200

        elif args['method']=='answered':

            doctor_appointment_id = data['doctor_appointment_id']
            room_name = str(uuid.uuid4())

            columns="doctor_appointment_id"
            where_stetment="connecting = '1' AND doctor_appointment_id = '"+str(doctor_appointment_id)+"' AND room_name = '' " 
            query=select_query("tblDoctorAppointment",columns,where_stetment)                    
            search = db.get_data_by_key(query)

            if search!=None:

                column_names=['room_name']
                values=[room_name]

                where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
                query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
                code =200


            return {'room_name': room_name}, code


        elif args['method']=='visite':

            doctor_appointment_id = data['doctor_appointment_id']

            column_names=['doctor_visited']
            values=['1']

            where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
            query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

            return {'flg': 1,'msg':'Successfully'}, 200


        elif args['method']=='update_symptom_group':

            doctor_appointment_id = data['doctor_appointment_id']
            symptom_group_id = data['symptom_group_id']

            column_names=['symptom_group_id']
            values=[str(symptom_group_id)]

            where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
            query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)

        elif args['method']=='change_doctor':

            doctor_appointment_id = data['doctor_appointment_id']
            doctor_id = data['doctor_id']
            doctor_fee = data['doctor_fee']

            columns="paid,connecting"
            where_stetment="paid = '1' and doctor_appointment_id = "+str(doctor_appointment_id)  
            query=select_query("tblDoctorAppointment",columns,where_stetment)                    
            doctor_appointment = db.get_data_by_key(query)

            if doctor_appointment!=None and doctor_appointment[0]==1 and doctor_appointment[1]==0:
                column_names=['status']
                values=['0']

                where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
                query=update_query("tblPayDoctorFee",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            if doctor_appointment!=None and doctor_appointment[1]==0:

                column_names=['doctor_id',
                            'doctor_fee',
                            'paid']
                values=[str(doctor_id),
                            str(doctor_fee),
                            '0']

                where_stetment="doctor_appointment_id = '"+str(doctor_appointment_id)+"'"
                query=update_query("tblDoctorAppointment",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
      
        elif args['method']=='delete':                
            doctor_appointment_id = data['doctor_appointment_id']

            columns="paid"
            where_stetment="paid = '0' and doctor_appointment_id = "+str(doctor_appointment_id)  
            query=select_query("tblDoctorAppointment",columns,where_stetment)                    
            doctor_appointment = db.get_data_by_key(query)

            if doctor_appointment!=None:

                query="DELETE FROM tblDoctorAppointment WHERE doctor_appointment_id = '"+str(doctor_appointment_id)+"'" 
                msg = db.update_data(query)
                return {'data': [],'flg':1}, 200
            else:
                return {'data': [],'flg':0}, 200
          
        
        # columns="*"
        # where_stetment="status = '1' and doctor_appointment_id = "+str(doctor_appointment_id)  
        # query=select_query("tblDoctorAppointment",columns,where_stetment)                    
        # doctor_appointment = db.get_data_by_key(query)

        columns=" tu.name,tu.profile_pic, td.specialist, td.doctor_shedule,tda.* "    
        where_stetment="tda.status = '1' AND tda.doctor_appointment_id = '"+str(doctor_appointment_id)+"'  "
        join_query="tblDoctorAppointment as tda "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
        query=select_query(join_query,columns,where_stetment)                    
                         
        doctor_appointment = db.get_data_by_key(query)
        code =200               
                    

        return {'flg': 1,'data':doctor_appointment,'msg':'Successfully'}, code

api.add_resource(DoctorAppointmentApi, '/doctor_appointment_api')


@app.route("/payment_success", methods=['GET', 'POST'])
def payment_success():
    
    if authentication()==False:
        return redirect(url_for('login'))

    user_id = get_user_id()
    db=Db()
    msg = "Invalid request"
    amount=''
    transaction_id = request.args.get('id')
    columns="payment_request_id,done"
    where_stetment="status = '1' AND transaction_id = '"+transaction_id+"' AND user_id = '"+str(user_id)+"' "  
    query=select_query("tblPaymentRequest",columns,where_stetment)                    
    search = db.get_data_by_key(query)
    if search!=None:
        if search[1]==0:
            url='https://www.dailycarebd.com/v1/ecom-payment/details?transaction_id='+transaction_id
            requests.get(url, headers = {"client-id": "client-id","client-secret": "client-secret"})
            # print(response.code)
            if response.code == 200:
                result = response.json()
                amount = result['data']['amount']
                payment_status = result['data']['payment_status']
                if payment_status == 'completed':
                    column_names=['done']
                    values=['1']

                    where_stetment="payment_request_id = '"+str(search[0])+"'"
                    query=update_query("tblPaymentRequest",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)

                    received_wallet(user_id,amount)
                msg = payment_status
        else:
            msg = "Your payment already updated."

    else:
        msg = "Invalid request"

    return render_template('payment_success.html', title='payment_success',msg=msg,amount=amount)

@app.route("/payment_failed", methods=['GET', 'POST'])
def payment_failed():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('payment_failed.html', title='payment_failed')

@app.route("/get_doctor_appointment_by_patient", methods=['GET'])
def get_doctor_appointment_by_patient():

    patient_id = request.args.get('id')
    doctor_visited = request.args.get('visited')    
    offset = request.args.get('offset')
    db = Db()    

    columns=" tu.name,tu.profile_pic, td.specialist, td.doctor_shedule,tda.* "    
    where_stetment="tda.status = '1' AND tda.patient_id = '"+str(patient_id)+"' AND tda.doctor_visited = '"+str(doctor_visited)+"'  ORDER BY tda.create_date  ASC LIMIT 10  OFFSET "+offset
    join_query="tblDoctorAppointment as tda "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    doctor_appointments = db.get_data(query)

    code =200

    result={"doctor_appointments":doctor_appointments}
    

    return jsonify(result)


@app.route("/patient_appointments", methods=['GET', 'POST'])
def patient_appointments():
    
    if authentication()==False:
        return redirect(url_for('login'))

    
    return render_template('patient_appointments.html', title='patient_appointments')

@app.route("/get_doctor_appointment_by_user", methods=['GET'])
def get_doctor_appointment_by_user():

    user_id = get_user_id()
    db = Db()    

    columns=" tu.name,td.specialist,tu.profile_pic,td.doctor_shedule,tp.patient_name,tp.profile_pic,tp.gender,tp.village,tda.patient_id,tda.doctor_fee,tda.appointment_time,tda.paid,tda.doctor_appointment_id "    
    where_stetment="tda.status = '1' AND tda.user_id = '"+str(user_id)+"' AND tda.doctor_visited = '0'  ORDER BY tda.create_date  ASC "
    join_query="tblDoctorAppointment as tda "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tp ON tp.patient_id = tda.patient_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblDoctor as td ON td.doctor_id = tda.doctor_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblUser as tu ON tu.user_id = td.user_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    doctor_appointments = db.get_data(query)
    code =200

    result={"doctor_appointments":doctor_appointments}
    

    return jsonify(result)


@app.route("/get_doctor_appointment_for_collection", methods=['GET'])
def get_doctor_appointment_for_collection():

    patient_id = request.args.get('id')
    db = Db()

    user_id = get_user_id()

    columns=" tp.patient_name,tp.profile_pic, tda.doctor_fee,tda.doctor_appointment_id "    
    where_stetment="tda.status = '1' AND tda.doctor_visited = '0' AND tda.patient_id = '"+str(patient_id)+"' AND tpc.user_id = '"+str(user_id)+"'  "
    join_query="tblDoctorAppointment as tda "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatientConnection as tpc ON tda.patient_id = tpc.patient_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tp ON tp.patient_id = tpc.patient_id "

    query=select_query(join_query,columns,where_stetment)                    
                     
    doctor_appointment = db.get_data_by_key(query)
    code =200

    result={"doctor_appointment":doctor_appointment}
    

    return jsonify(result)


@app.route("/get_doctor_appointment_by_doctor", methods=['GET'])
def get_doctor_appointment_by_doctor():

    user_id = get_user_id()    
    doctor_visited = request.args.get('visited')
    db = Db() 
    doctor_id = get_doctor_id(user_id,db)   

    columns=" tcp.patient_name,tcp.gender,tcp.age, tcp.profile_pic, tcp.hight, tcp.weight, tcp.blood_group,tda.doctor_appointment_id,tda.patient_id,tda.symptom_group_id,tda.doctor_fee,tda.connecting,tda.room_name "    
    where_stetment="tda.paid = '1' AND tda.doctor_id = '"+str(doctor_id)+"' AND tda.doctor_visited = '"+str(doctor_visited)+"' ORDER by  tda.connecting DESC "
    join_query="tblDoctorAppointment as tda "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tcp ON tcp.patient_id = tda.patient_id "
    query=select_query(join_query,columns,where_stetment)                    
                     
    doctor_appointments = db.get_data(query)
    code =200

    result={"doctor_appointments":doctor_appointments}
    

    return jsonify(result)


@app.route("/medical_test", methods=['GET', 'POST'])
def medical_test():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('medical_test.html', title='medical_test')

class MedicalTestApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        medical_tests=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblMedicalTest",columns,where_stetment)                    
        medical_tests = db.get_data(query)

        code =200

        return {'medical_tests': medical_tests}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        medical_test=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                medical_test = rmqt(data['medical_test'])
                about_test = rmqt(data['about_test'])

                columns="medical_test_id"
                where_stetment="medical_test = '"+medical_test+"' "   
                query=select_query("tblMedicalTest",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['medical_test',
                                    'about_test',
                                    'status']
                    values=[medical_test,
                            about_test,
                            '1']
                    query=insert_query("tblMedicalTest",column_names,values,"medical_test_id")
                    # print(query)
                    medical_test_id = db.insert_data(query)

            elif args['method']=='update':                
                medical_test_id = data['medical_test_id']

                medical_test = rmqt(data['medical_test'])
                about_test = rmqt(data['about_test'])

                column_names=['medical_test',
                                'about_test',
                                'status']
                values=[medical_test,
                        about_test,
                        '1']
                
                where_stetment="medical_test_id = '"+str(medical_test_id)+"'"
                query=update_query("tblMedicalTest",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                medical_test_id = data['medical_test_id']

                query="DELETE FROM tblMedicalTest WHERE medical_test_id = '"+str(medical_test_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="medical_test_id = '"+str(medical_test_id)+"'"  
            query=select_query("tblMedicalTest",columns,where_stetment)                    
            medical_test = db.get_data_by_key(query)
            code =200               
                    

        return {'data': medical_test}, code

api.add_resource(MedicalTestApi, '/medical_test_api')


@app.route("/primary_test", methods=['GET', 'POST'])
def primary_test():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('primary_test.html', title='primary_test')

class PrimaryTestApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        primary_tests=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblPrimaryTest",columns,where_stetment)                    
        primary_tests = db.get_data(query)

        code =200

        return {'primary_tests': primary_tests}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        primary_test_tbl=None
        primary_test_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                primary_test = rmqt(data['primary_test'])
                unit = rmqt(data['unit'])
                about_test = rmqt(data['about_test'])

                columns="primary_test_id"
                where_stetment="primary_test = '"+primary_test+"' "   
                query=select_query("tblPrimaryTest",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['primary_test',
                                    'unit',
                                    'about_test',
                                    'status']
                    values=[primary_test,
                            unit,
                            about_test,
                            '1']
                    query=insert_query("tblPrimaryTest",column_names,values,"primary_test_id")
                    # print(query)
                    primary_test_id = db.insert_data(query)

            elif args['method']=='update':                
                primary_test_id = data['primary_test_id']

                primary_test = rmqt(data['primary_test'])
                about_test = rmqt(data['about_test'])

                column_names=['primary_test',
                                'unit',
                                'about_test',
                                'status']
                values=[primary_test,
                        unit,
                        about_test,
                        '1']
                
                where_stetment="primary_test_id = '"+str(primary_test_id)+"'"
                query=update_query("tblPrimaryTest",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                primary_test_id = data['primary_test_id']

                query="DELETE FROM tblPrimaryTest WHERE primary_test_id = '"+str(primary_test_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="primary_test_id = '"+str(primary_test_id)+"'"  
            query=select_query("tblPrimaryTest",columns,where_stetment)                    
            primary_test_tbl = db.get_data_by_key(query)
            code =200               
                    

        return {'data': primary_test_tbl}, code

api.add_resource(PrimaryTestApi, '/primary_test_api')


@app.route("/food", methods=['GET', 'POST'])
def food():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('food.html', title='food')

class FoodApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        foods=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblFood",columns,where_stetment)                    
        foods = db.get_data(query)

        code =200

        return {'foods': foods}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        food=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                food = rmqt(data['food'])

                columns="food_id"
                where_stetment="food = '"+food+"' "   
                query=select_query("tblFood",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['food',
                                    'status']
                    values=[food,
                            '1']
                    query=insert_query("tblFood",column_names,values,"food_id")
                    # print(query)
                    food_id = db.insert_data(query)

            elif args['method']=='update':                
                food_id = data['food_id']

                food = rmqt(data['food'])

                column_names=['food',
                                'status']
                values=[food,
                        '1']
                
                where_stetment="food_id = '"+str(food_id)+"'"
                query=update_query("tblFood",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                food_id = data['food_id']

                query="DELETE FROM tblFood WHERE food_id = '"+str(food_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="food_id = '"+str(food_id)+"'"  
            query=select_query("tblFood",columns,where_stetment)                    
            food = db.get_data_by_key(query)
            code =200               
                    

        return {'data': food}, code

api.add_resource(FoodApi, '/food_api')


@app.route("/food_rule", methods=['GET', 'POST'])
def food_rule():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('food_rule.html', title='food rules')

class FoodRuleApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        food_rules=None
        db=Db()

        columns=" tf.food,tfr.* "    
        where_stetment="tfr.status = '1' "   
        join_query="tblFoodRule as tfr "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblFood as tf ON tf.food_id = tfr.food_id "
        query=select_query(join_query,columns,where_stetment)                    
        food_rules = db.get_data(query)

        code =200

        return {'food_rules': food_rules}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        food_rule=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                food_id = data['food_id']
                food_rule = rmqt(data['food_rule'])

                columns="food_rule_id"
                where_stetment="food_rule = '"+food_rule+"' AND food_id =  '"+str(food_id)+"' "   
                query=select_query("tblFoodRule",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['food_id',
                                    'food_rule',
                                    'status']
                    values=[str(food_id),
                            food_rule,
                            '1']
                    query=insert_query("tblFoodRule",column_names,values,"food_rule_id")
                    # print(query)
                    food_rule_id = db.insert_data(query)

            elif args['method']=='update':

                food_id = data['food_id']                
                food_rule_id = data['food_rule_id']

                food_rule = rmqt(data['food_rule'])

                column_names=['food_id',
                                'food_rule',
                                'status']
                values=[str(food_id),
                        food_rule,
                        '1']
                
                where_stetment="food_rule_id = '"+str(food_rule_id)+"'"
                query=update_query("tblFoodRule",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                food_rule_id = data['food_rule_id']

                query="DELETE FROM tblFoodRule WHERE food_rule_id = '"+str(food_rule_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            
            columns=" tf.food,tfr.* "    
            where_stetment="tfr.food_rule_id = '"+str(food_rule_id)+"'"   
            join_query="tblFoodRule as tfr "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblFood as tf ON tf.food_id = tfr.food_id "
            query=select_query(join_query,columns,where_stetment)                    
            food_rule = db.get_data_by_key(query)
            code =200               
                    

        return {'data': food_rule}, code

api.add_resource(FoodRuleApi, '/food_rule_api')


@app.route("/exercise", methods=['GET', 'POST'])
def exercise():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('exercise.html', title='exercise')

class ExerciseApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        exercises=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblExercise",columns,where_stetment)                    
        exercises = db.get_data(query)

        code =200

        return {'exercises': exercises}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        exercise=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                exercise = rmqt(data['exercise'])

                columns="exercise_id"
                where_stetment="exercise = '"+exercise+"' "   
                query=select_query("tblExercise",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['exercise',
                                    'status']
                    values=[exercise,
                            '1']
                    query=insert_query("tblExercise",column_names,values,"exercise_id")
                    # print(query)
                    exercise_id = db.insert_data(query)

            elif args['method']=='update':                
                exercise_id = data['exercise_id']

                exercise = rmqt(data['exercise'])

                column_names=['exercise',
                                'status']
                values=[exercise,
                        '1']
                
                where_stetment="exercise_id = '"+str(exercise_id)+"'"
                query=update_query("tblExercise",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                exercise_id = data['exercise_id']

                query="DELETE FROM tblExercise WHERE exercise_id = '"+str(exercise_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="exercise_id = '"+str(exercise_id)+"'"  
            query=select_query("tblExercise",columns,where_stetment)                    
            exercise = db.get_data_by_key(query)
            code =200               
                    

        return {'data': exercise}, code

api.add_resource(ExerciseApi, '/exercise_api')


@app.route("/exercise_rule", methods=['GET', 'POST'])
def exercise_rule():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('exercise_rule.html', title='exercise_rule')

class ExerciseRuleApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        exercise_rules=None
        db=Db()

        columns=" te.exercise,ter.* "    
        where_stetment="ter.status = '1' "   
        join_query="tblExerciseRule as ter "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblExercise as te ON te.exercise_id = ter.exercise_id "
        query=select_query(join_query,columns,where_stetment)                    
        exercise_rules = db.get_data(query)

        code =200

        return {'exercise_rules': exercise_rules}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        exercise_rule=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                exercise_id = data['exercise_id']
                exercise_rule = rmqt(data['exercise_rule'])

                columns="exercise_rule_id"
                where_stetment="exercise_rule = '"+exercise_rule+"' "   
                query=select_query("tblExerciseRule",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['exercise_id',
                                    'exercise_rule',
                                    'status']
                    values=[str(exercise_id),
                             exercise_rule,
                            '1']
                    query=insert_query("tblExerciseRule",column_names,values,"exercise_rule_id")
                    # print(query)
                    exercise_rule_id = db.insert_data(query)

            elif args['method']=='update':                
                exercise_rule_id = data['exercise_rule_id']

                exercise_id = data['exercise_id']
                exercise_rule = rmqt(data['exercise_rule'])

                column_names=['exercise_id',
                                'exercise_rule']
                values=[str(exercise_id),
                         exercise_rule]
                
                where_stetment="exercise_rule_id = '"+str(exercise_rule_id)+"'"
                query=update_query("tblExerciseRule",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                exercise_rule_id = data['exercise_rule_id']

                query="DELETE FROM tblExerciseRule WHERE exercise_rule_id = '"+str(exercise_rule_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
           
            columns=" te.exercise,ter.* "    
            where_stetment="ter.exercise_rule_id = '"+str(exercise_rule_id)+"'"    
            join_query="tblExerciseRule as ter "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblExercise as te ON te.exercise_id = ter.exercise_id "
            query=select_query(join_query,columns,where_stetment)                    
            exercise_rule = db.get_data_by_key(query)

            code =200               
                    

        return {'data': exercise_rule}, code

api.add_resource(ExerciseRuleApi, '/exercise_rule_api')


@app.route("/extend", methods=['GET', 'POST'])
def extend():

    if authentication()==False:
        return redirect(url_for('login'))

        
    
    return render_template('extend.html', title='extend')

class ExtendApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        extends=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblExtend",columns,where_stetment)                    
        extends = db.get_data(query)

        code =200

        return {'extends': extends}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        extend=None
        subject_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                extend = rmqt(data['extend'])

                columns="extend_id"
                where_stetment="extend = '"+extend+"' "   
                query=select_query("tblExtend",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['extend',
                                    'status']
                    values=[extend,
                            '1']
                    query=insert_query("tblExtend",column_names,values,"extend_id")
                    # print(query)
                    extend_id = db.insert_data(query)

            elif args['method']=='update':                
                extend_id = data['extend_id']

                extend = rmqt(data['extend'])

                column_names=['extend',
                                'status']
                values=[extend,
                        '1']
                
                where_stetment="extend_id = '"+str(extend_id)+"'"
                query=update_query("tblExtend",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':                
                extend_id = data['extend_id']

                query="DELETE FROM tblExtend WHERE extend_id = '"+str(extend_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
              
            
            columns="*"
            where_stetment="extend_id = '"+str(extend_id)+"'"  
            query=select_query("tblExtend",columns,where_stetment)                    
            extend = db.get_data_by_key(query)
            code =200               
                    

        return {'data': extend}, code

api.add_resource(ExtendApi, '/extend_api')


@app.route("/daily_care_center", methods=['GET', 'POST'])
def daily_care_center():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('daily_care_center.html', title='daily_care_center')

class DailyCareCenterApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()      
        args = parser.parse_args()
        code =401
        daily_care_centers=None
        if authentication() == True:
            db=Db()        

            columns="*"
            where_stetment="status = '1'"  
            query=select_query("tblDailyCareCenter",columns,where_stetment)                    
            daily_care_centers = db.get_data(query)

            code =200

        return {'daily_care_centers': daily_care_centers}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        daily_care_center=None
        daily_care_center_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='post':
                
                daily_care_center = rmqt(data['daily_care_center'])
                district = rmqt(data['district'])
                thana = rmqt(data['thana'])
                place = rmqt(data['place'])

                columns="daily_care_center_id"
                where_stetment="daily_care_center = '"+str(daily_care_center)+"'"  
                query=select_query("tblDailyCareCenter",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['daily_care_center',
                                    'district',
                                    'thana',
                                    'place',
                                    'create_date',
                                    'status']
                    values=[daily_care_center,
                            district,
                            thana,
                            place,
                            str(time.time()),
                            '1']
                    query=insert_query("tblDailyCareCenter",column_names,values,"daily_care_center_id")
                    # print(query)
                    daily_care_center_id = db.insert_data(query)
                    

            elif args['method']=='update':                
                daily_care_center_id = data['daily_care_center_id']
                daily_care_center = rmqt(data['daily_care_center'])
                district = rmqt(data['district'])
                thana = rmqt(data['thana'])
                place = rmqt(data['place'])

                column_names=['daily_care_center',
                                'district',
                                'thana',
                                'place']
                values=[daily_care_center,
                        district,
                        thana,
                        place]

                where_stetment="daily_care_center_id = '"+str(daily_care_center_id)+"'"
                query=update_query("tblDailyCareCenter",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)

            elif args['method']=='delete':

                daily_care_center_id = data['daily_care_center_id']

                columns="daily_care_center_id"
                where_stetment="daily_care_center_id = '"+str(daily_care_center_id)+"' "  
                query=select_query("tblEmployeePosting",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search == None:                    
                    query="DELETE FROM tblDailyCareCenter WHERE daily_care_center_id = '"+str(daily_care_center_id)+"'" 
                    msg = db.update_data(query)
                    return {'data': msg}, 200
            
            
            columns="*"
            where_stetment="daily_care_center_id = '"+str(daily_care_center_id)+"'"  
            query=select_query("tblDailyCareCenter",columns,where_stetment)                    
            daily_care_center = db.get_data_by_key(query)
            code =200               
                    

        return {'data': daily_care_center}, code

api.add_resource(DailyCareCenterApi, '/daily_care_center_api')


@app.route("/employee", methods=['GET', 'POST'])
def employee():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('employee.html', title='employee')

class EmployeeApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()      
        args = parser.parse_args()
        code =401
        employees=None
        if authentication() == True:
            db=Db()

            columns=" tu.name, tu.profile_pic, te.*"
            where_stetment="te.status = '1'  "   
            join_query="tblEmployee as te "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = te.user_id "
            query=select_query(join_query,columns,where_stetment)                     
            employees = db.get_data(query)

            code =200

        return {'employees': employees}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        employee=None
        employee_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='post':
                
                employee_user_id = data['employee_user_id']
                designation = data['designation']
                grade = data['grade']
                cv_pdf = data['cv_pdf']

                columns="employee_id"
                where_stetment="user_id = '"+str(employee_user_id)+"'"  
                query=select_query("tblEmployee",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['user_id',
                                    'designation',
                                    'grade',
                                    'cv_pdf',
                                    'create_date',
                                    'status']
                    values=[str(employee_user_id),
                            designation,
                            str(grade),
                            cv_pdf,
                            str(time.time()),
                            '1']
                    query=insert_query("tblEmployee",column_names,values,"employee_id")
                    print(query)
                    employee_id = db.insert_data(query)
                    

            elif args['method']=='update':                
                employee_id = data['employee_id']
                designation = data['designation']
                grade = data['grade']
                cv_pdf = data['cv_pdf']

                column_names=['designation',
                                'grade',
                                'cv_pdf']
                values=[designation,
                        str(grade),
                        cv_pdf]

                where_stetment="employee_id = '"+str(employee_id)+"'"
                query=update_query("tblEmployee",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
            
            
            
            columns=" tu.name, tu.profile_pic, te.*"
            where_stetment="te.employee_id = '"+str(employee_id)+"'  "   
            join_query="tblEmployee as te "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = te.user_id "
            query=select_query(join_query,columns,where_stetment)                    
            employee = db.get_data_by_key(query)
            code =200               
                    

        return {'data': employee}, code

api.add_resource(EmployeeApi, '/employee_api')


@app.route("/employee_posting", methods=['GET', 'POST'])
def employee_posting():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('employee_posting.html', title='employee_posting')

class EmployeePostingApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()      
        args = parser.parse_args()
        code =401
        employee_postings=None
        if authentication() == True:
            db=Db()        

            columns=" tu.name, tu.profile_pic,tdcc.daily_care_center, tep.*"
            where_stetment="tep.status = '1'  "   
            join_query="tblEmployeePosting as tep "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDailyCareCenter as tdcc ON tdcc.daily_care_center_id = tep.daily_care_center_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblEmployee as te ON te.employee_id = tep.employee_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = te.user_id "
            query=select_query(join_query,columns,where_stetment)
            employee_postings = db.get_data(query)

            code =200

        return {'employee_postings': employee_postings}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        employee_posting=None
        employee_posting_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='post':
                
                employee_id = data['employee_id']
                daily_care_center_id = data['daily_care_center_id']
                designation = data['designation']
                posting_date = data['posting_date']

                columns="employee_posting_id"
                where_stetment="employee_id = '"+str(employee_id)+"' AND status = '1' "  
                query=select_query("tblEmployeePosting",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['employee_id',
                                    'daily_care_center_id',
                                    'designation',
                                    'posting_date',
                                    'resignation_date',
                                    'create_date',
                                    'status']
                    values=[str(employee_id),
                            str(daily_care_center_id),
                            designation,
                            str(posting_date),
                            '',
                            str(time.time()),
                            '1']
                    query=insert_query("tblEmployeePosting",column_names,values,"employee_posting_id")
                    # print(query)
                    employee_posting_id = db.insert_data(query)
            
            elif args['method']=='update':                
                employee_posting_id = data['employee_posting_id']
                daily_care_center_id = data['daily_care_center_id']
                designation = data['designation']
                posting_date = data['posting_date']

                column_names=['daily_care_center_id',
                                'designation',
                                'posting_date']
                values=[str(daily_care_center_id),
                        designation,
                        str(posting_date)]

                where_stetment="employee_posting_id = '"+str(employee_posting_id)+"'"
                query=update_query("tblEmployeePosting",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
                    

            elif args['method']=='resignation':                
                employee_posting_id = data['employee_posting_id']
                resignation_date = data['resignation_date']

                column_names=['resignation_date',
                                'status']
                values=[str(resignation_date),
                        '0']

                where_stetment="employee_posting_id = '"+str(employee_posting_id)+"'"
                query=update_query("tblEmployeePosting",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
            
          
            columns=" tu.name, tu.profile_pic,tdcc.daily_care_center, tep.*"
            where_stetment="tep.status = '1' AND tep.employee_posting_id = '"+str(employee_posting_id)+"' "   
            join_query="tblEmployeePosting as tep "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDailyCareCenter as tdcc ON tdcc.daily_care_center_id = tep.daily_care_center_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblEmployee as te ON te.employee_id = tep.employee_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = te.user_id "
            query=select_query(join_query,columns,where_stetment)
            employee_posting = db.get_data_by_key(query)
            code =200               
                    

        return {'data': employee_posting}, code

api.add_resource(EmployeePostingApi, '/employee_posting_api')

def get_employee_id():

    user_id = get_user_id()
    db=Db() 
            
    columns=" te.employee_id,tep.daily_care_center_id"
    where_stetment="tu.user_id = '"+str(user_id)+"'  "   
    join_query="tblUser as tu "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblEmployee as te ON te.user_id = tu.user_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblEmployeePosting as tep ON tep.employee_id = te.employee_id "
    query=select_query(join_query,columns,where_stetment)
    employee = db.get_data_by_key(query)

    return employee


@app.route("/doctor_fee_collection", methods=['GET', 'POST'])
def doctor_fee_collection():
    
    if authentication()==False:
        return redirect(url_for('login'))

    employee = get_employee_id()
    if employee==None:
        return redirect(url_for('index'))

    return render_template('doctor_fee_collection.html', title='doctor_fee_collection')

class DoctorFeeCollectionApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()      
        args = parser.parse_args()
        code =401
        doctor_fee_collections=None
        # user_id = get_user_id()
        # account_balance_insert(user_id)
        if authentication() == True:
            db=Db()        
            employee = get_employee_id()
            
            columns=" tp.patient_name, tp.profile_pic,tdcc.daily_care_center, tdfc.*"
            where_stetment="tdfc.status = '1' AND tdfc.employee_id = '"+str(employee[0])+"' "   
            join_query="tblDoctorFeeCollection as tdfc "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDailyCareCenter as tdcc ON tdcc.daily_care_center_id = tdfc.daily_care_center_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctorAppointment as tda ON tda.doctor_appointment_id = tdfc.doctor_appointment_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblPatient as tp ON tp.patient_id = tda.patient_id "
            query=select_query(join_query,columns,where_stetment)
            doctor_fee_collections = db.get_data(query)

            code =200

        return {'doctor_fee_collections': doctor_fee_collections}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        doctor_fee_collection=None
        doctor_fee_collection_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='post':

                employee = get_employee_id()
                if employee==None:
                    return {'data': msg}, code                 
                
                doctor_appointment_id = data['doctor_appointment_id']
                daily_care_charge = data['daily_care_charge']
                amount = float(data['amount'])

                date = time.time()-10*60

                columns="doctor_fee_collection_id"
                where_stetment=" status = '1' AND employee_id = '"+str(employee[0])+"' AND doctor_appointment_id = '"+str(doctor_appointment_id)+"' "  
                query=select_query("tblDoctorFeeCollection",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['employee_id',
                                    'daily_care_center_id',
                                    'doctor_appointment_id',
                                    'daily_care_charge',
                                    'amount',
                                    'create_date',
                                    'status']
                    values=[str(employee[0]),
                            str(employee[1]),
                            str(doctor_appointment_id),
                            str(daily_care_charge),
                            str(amount),
                            str(time.time()),
                            '1']
                    query=insert_query("tblDoctorFeeCollection",column_names,values,"doctor_fee_collection_id")
                    # print(query)
                    doctor_fee_collection_id = db.insert_data(query)
                    user_id = get_user_id()
                    received_wallet(user_id,amount)                    

            elif args['method']=='update':

                employee = get_employee_id()
                if employee==None:
                    return {'data': msg}, code

                doctor_fee_collection_id = data['doctor_fee_collection_id']
                daily_care_center_id = data['daily_care_center_id']
                doctor_appointment_id = data['doctor_appointment_id']
                daily_care_charge = data['daily_care_charge']
                amount = data['amount']

                columns="amount"
                where_stetment="employee_id = '"+str(employee[0])+"' AND doctor_fee_collection_id = '"+str(doctor_fee_collection_id)+"' "  
                query=select_query("tblDoctorFeeCollection",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search !=None:

                    column_names=['daily_care_center_id',
                                    'doctor_appointment_id',
                                    'daily_care_charge',
                                    'amount']
                    values=[str(employee[1]),
                            str(doctor_appointment_id),
                            str(daily_care_charge),
                            str(amount)]

                    where_stetment="doctor_fee_collection_id = '"+str(doctor_fee_collection_id)+"'"
                    query=update_query("tblDoctorFeeCollection",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)

                    amount = amount - search[0]
                    user_id = get_user_id()
                    received_wallet(user_id,amount)


            elif args['method']=='delete':

                employee = get_employee_id()
                if employee==None:
                    return {'data': msg}, code

                doctor_fee_collection_id = data['doctor_fee_collection_id']

                columns="amount"
                where_stetment="doctor_fee_collection_id = '"+str(doctor_fee_collection_id)+"' AND employee_id = '"+str(employee[0])+"' "  
                query=select_query("tblDoctorFeeCollection",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search != None:

                    column_names=['status']
                    values=['0']

                    where_stetment="doctor_fee_collection_id = '"+str(doctor_fee_collection_id)+"'"
                    query=update_query("tblDoctorFeeCollection",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)

                    # query="DELETE FROM tblDoctorFeeCollection WHERE doctor_fee_collection_id = '"+str(doctor_fee_collection_id)+"'" 
                    # msg = db.update_data(query)

                    amount = 0 - search[0]
                    user_id = get_user_id()
                    received_wallet(user_id,amount)
                    return {'data': msg}, 200
            
            
            columns=" tp.patient_name, tp.profile_pic,tdcc.daily_care_center, tdfc.*"
            where_stetment="tdfc.status = '1' AND tdfc.doctor_fee_collection_id = '"+str(doctor_fee_collection_id)+"' "   
            join_query="tblDoctorFeeCollection as tdfc "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDailyCareCenter as tdcc ON tdcc.daily_care_center_id = tdfc.daily_care_center_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblDoctorAppointment as tda ON tda.doctor_appointment_id = tdfc.doctor_appointment_id "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblPatient as tp ON tp.patient_id = tda.patient_id "
            query=select_query(join_query,columns,where_stetment)
            doctor_fee_collection = db.get_data_by_key(query)
            code =200               
                    

        return {'data': doctor_fee_collection}, code

api.add_resource(DoctorFeeCollectionApi, '/doctor_fee_collection_api')


@app.route("/earning", methods=['GET', 'POST'])
def earning():
    if authentication()==False:
        return redirect(url_for('login'))

    user_id = get_user_id()
    db=Db()
    teacher_id = get_teacher_id(user_id,db)
    if teacher_id==0:
        return redirect(url_for('index'))

    columns="SUM(fee)"
    where_stetment="teacher_id = '"+str(teacher_id)+"' AND status = '1' "  
    query=select_query("tblTeacherFee",columns,where_stetment)                    
    teacher_fee = db.get_data_by_key(query)
    return render_template('earning.html', title='earning',teacher_fee=teacher_fee)

class TeacherPaymentApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('offset', required=True)        
        args = parser.parse_args()
        offset = args['offset']
        msg="unauthorized request"
        code =401
        teacher_fees=None
        user_id = get_user_id()
        if authentication() == True:
            db=Db()
            teacher_id = get_teacher_id(user_id,db)
            if teacher_id==0:
                return {'teacher_fees': teacher_fees}, code
           
            columns=" tco.course_titel, ttf.pay_money_id, ttf.fee,ttf.create_date"
            where_stetment="tco.status = '1' AND tco.teacher_id = '"+str(teacher_id)+"' ORDER BY ttf.create_date ASC LIMIT 10  OFFSET "+offset   
            join_query="tblCourse as tco "
            join_query=join_query+"LEFT JOIN "
            join_query=join_query+"tblTeacherFee as ttf ON ttf.course_id = tco.course_id "
            query=select_query(join_query,columns,where_stetment) 
            # print(query)                   
            teacher_fees = db.get_data(query)                
            code=200
            return {'teacher_fees': teacher_fees}, code
            code =200

        return {'teacher_fees': teacher_fees}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        received_money=None
        received_money_id=0
        user_id = get_user_id()
        if authentication() == True:

            db=Db()

            if args['method']=='cancel_request':

                class_request_id = data['class_request_id']
                student_id = get_student_id(user_id,db)

                columns="class_request_id"
                where_stetment="class_request_id = '"+str(class_request_id)+"' AND student_id = '"+str(student_id)+"'  AND paid = '0'"  
                query=select_query("tblClassRequest",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search != None:                    
                    query="DELETE FROM tblClassRequest WHERE class_request_id = '"+str(class_request_id)+"'" 
                    msg = db.update_data(query)
                    return {'data': msg}, 200
            elif args['method']=='class_pay':

                course_id = data['course_id']
                student_id = get_student_id(user_id,db)

                if course_id == "" :
                    return {'data': received_money}, code

                columns=" tu.current_balance,tco.number_of_class, tco.deduction_percentage"
                where_stetment="tu.user_id = '"+str(user_id)+"'"  
                join_query="tblUser as tu "
                join_query=join_query+"LEFT JOIN "
                join_query=join_query+"tblCourse as tco ON tco.course_id = '"+str(course_id)+"' "
                query=select_query(join_query,columns,where_stetment) 
                # print(query)                   
                balance = db.get_data_by_key(query)

                columns="tcr.class_id,tc.class_fee,tcr.class_request_id"
                where_stetment="tcr.status = '1' AND tcr.paid = '0'  AND tcr.course_id = '"+str(course_id)+"' AND tcr.student_id = '"+str(student_id)+"'"  
                  
                join_query="tblClassRequest as tcr "
                join_query=join_query+"LEFT JOIN "
                join_query=join_query+"tblClass as tc ON tc.class_id = tcr.class_id "
                query=select_query(join_query,columns,where_stetment)
                unpaid_classes = db.get_data(query)

                pay_transaction_id = str(uuid.uuid4())
                total_fee=0
                column_names=['student_id',
                                'class_id',
                                'pay_transaction_id',
                                'class_step',
                                'create_date',
                                'status']
                update_column_names=['paid']
                querys=[]
                update_querys=[]
                for unpaid_classe in unpaid_classes:
                    total_fee = total_fee+unpaid_classe[1]
                    values=[str(student_id),
                            str(unpaid_classe[0]),
                            pay_transaction_id,
                            '1',
                            str(time.time()),
                            '1']
                    query=insert_query("tblStudentAccessClass",column_names,values,"student_access_class_id")
                    querys.append(query)

                    where_stetment="class_request_id = '"+str(unpaid_classe[2])+"'"
                    query=update_query("tblClassRequest",['paid'],['1'],where_stetment)
                    update_querys.append(query)

                deduction=0
                number_of_class = len(unpaid_classes)
                if number_of_class>=balance[1]:
                    deduction = (total_fee*balance[2])/100

                total_fee = total_fee -deduction

                if total_fee<=balance[0]:

                    le_charge =int(total_fee/5)

                    column_names=['user_id',
                                    'course_id',
                                    'number_of_class',
                                    'total_bill',
                                    'deduction',
                                    'le_charge',
                                    'vat',
                                    'pay_transaction_id',
                                    'pay_date',
                                    'status']
                    values=[str(user_id),
                            str(course_id),
                            str(number_of_class),
                            str(total_fee),
                            str(deduction),
                            str(le_charge),
                            '0',
                            pay_transaction_id,
                            str(time.time()),
                            '1']
                    query=insert_query("tblPayMoney",column_names,values,"pay_money_id")
                    # print(query)
                    pay_money_id = db.insert_data(query)

                    # Update user balance
                    column_names=['current_balance']
                    blnc=balance[0]-total_fee
                    values=[str(blnc)]
                    
                    where_stetment="user_id = '"+str(user_id)+"'"
                    query=update_query("tblUser",column_names,values,where_stetment)
                    res = db.update_data(query)

                    # Insert access classes
                    res = db.multi_queries(querys)
                    # Update class request
                    res = db.multi_queries(update_querys)

                    # Teacher balance insert
                    columns="teacher_id"
                    where_stetment="status = '1' AND course_id = '"+str(course_id)+"'"  
                    query=select_query("tblCourse",columns,where_stetment)                    
                    teacher = db.get_data_by_key(query)
                    
                    column_names=['teacher_id',
                                    'course_id',
                                    'pay_money_id',
                                    'fee',
                                    'create_date',
                                    'status']
                    values=[str(teacher[0]),
                            str(course_id),
                            str(pay_money_id),
                            str(total_fee-le_charge),
                            str(time.time()),
                            '1']
                    query=insert_query("tblTeacherFee",column_names,values,"teacher_fee_id")
                    # print(query)
                    teacher_fee_id = db.insert_data(query)

                    # le charge update
                    
                    column_names=['course_id',
                                    'pay_money_id',
                                    'fee',
                                    'create_date',
                                    'status']
                    values=[str(course_id),
                            str(pay_money_id),
                            str(le_charge),
                            str(time.time()),
                            '1']
                    query=insert_query("tblCompanyFee",column_names,values,"company_fee_id")
                    # print(query)
                    company_fee_id = db.insert_data(query)

                    columns=" tcr.class_id,tc.class_number,tc.class_titel,tc.class_fee, tco.course_titel, tco.number_of_class, tco.deduction_percentage,tcr.course_id"
                    where_stetment="tcr.status = '1' AND tcr.paid = '0'  AND tcr.cancel = '0' AND tcr.student_id = '"+str(student_id)+"' ORDER BY tcr.course_id " 
                    join_query="tblClassRequest as tcr "
                    join_query=join_query+"LEFT JOIN "
                    join_query=join_query+"tblClass as tc ON tc.class_id = tcr.class_id "
                    join_query=join_query+"LEFT JOIN "
                    join_query=join_query+"tblCourse as tco ON tco.course_id = tcr.course_id "
                    query=select_query(join_query,columns,where_stetment) 
                    # print(query)                   
                    unpaid_classes = db.get_data(query)
                    code=200
                    return {'data': unpaid_classes}, code



            elif args['method']=='delete':

                received_money_id = data['received_money_id']

                columns="received_money_id"
                where_stetment="received_money_id = '"+str(received_money_id)+"' AND user_id = '"+str(user_id)+"'  AND received = '0'"  
                query=select_query("tblReceivedMoney",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search != None:                    
                    query="DELETE FROM tblReceivedMoney WHERE received_money_id = '"+str(received_money_id)+"'" 
                    msg = db.update_data(query)
                    return {'data': msg}, 200

            elif args['method']=='post':

                account_name = data['account_name']
                to_account_number = data['to_account_number']
                from_account_number = data['from_account_number']
                reference = data['reference']
                amount = data['amount']
                if account_name == "" or to_account_number == "" or from_account_number == "" or reference=="" or amount == "":
                    return {'data': received_money}, code

                columns="received_money_id"
                where_stetment="status = '1' and received = '0' and user_id = '"+str(user_id)+"' and reference = '"+reference+"' and from_account_number = '"+from_account_number+"'"    
                query=select_query("tblReceivedMoney",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search == None:

                    column_names=['user_id',
                                    'account_name',
                                    'to_account_number',
                                    'from_account_number',
                                    'reference',
                                    'amount',
                                    'money_transfer_id',
                                    'received',
                                    'received_date',
                                    'status']
                    values=[str(user_id),
                            account_name,
                            to_account_number,
                            from_account_number,
                            reference,
                            str(amount),
                            '',
                            '0',
                            str(time.time()),
                            '1']
                    query=insert_query("tblReceivedMoney",column_names,values,"received_money_id")
                    # print(query)
                    received_money_id = db.insert_data(query)

            elif args['method']=='update':
                if is_admin():
                    received_money_id = data['received_money_id']
                    money_transfer_id = data['money_transfer_id']

                    columns=" user_id, amount "
                    where_stetment="received_money_id = '"+str(received_money_id)+"' AND received = '0'"           
                    query=select_query("tblReceivedMoney",columns,where_stetment)                    
                    received_money = db.get_data_by_key(query)
                    if received_money != None:
                        column_names=['money_transfer_id',
                                        'received',
                                        'status']
                        values=[money_transfer_id,
                                '1',
                                '1']
                        
                        where_stetment="received_money_id = '"+str(received_money_id)+"'"
                        query=update_query("tblReceivedMoney",column_names,values,where_stetment)
                        # print(query)
                        
                        res = db.update_data(query)

                        columns=" current_balance "
                        where_stetment="user_id = '"+str(received_money[0])+"'"           
                        query=select_query("tblUser",columns,where_stetment)                    
                        balance = db.get_data_by_key(query)
                        if balance != None:
                            column_names=['current_balance']
                            blnc=balance[0]+received_money[1]
                            values=[str(blnc)]
                            
                            where_stetment="user_id = '"+str(received_money[0])+"'"
                            query=update_query("tblUser",column_names,values,where_stetment)
                            # print(query)
                            
                            res = db.update_data(query)
                else:
                    return {'data': received_money}, code

                        
                    
                
            columns=" * "
            where_stetment="received_money_id = '"+str(received_money_id)+"'"           
            query=select_query("tblReceivedMoney",columns,where_stetment)                    
            received_money = db.get_data_by_key(query)
            code =200               
                    

        return {'data': received_money}, code

api.add_resource(TeacherPaymentApi, '/teacher_payment_api')

@app.route("/payment", methods=['GET', 'POST'])
def payment():
    if authentication()==False:
        return redirect(url_for('login'))

    
    return render_template('payment.html', title='payment')

class StudentPaymentApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('unpaid', required=True)
        parser.add_argument('offset', required=True)        
        args = parser.parse_args()
        unpaid = args['unpaid']
        offset = args['offset']
        msg="unauthorized request"
        code =401
        classes=None
        user_id = get_user_id()
        if authentication() == True:
            db=Db()
            student_id = get_student_id(user_id,db)
            print(student_id)
            if student_id==0:
                return {'classes': classes}, code

            if unpaid == '1':
                columns=" tcr.class_request_id,tcr.class_id,tc.class_number,tc.class_titel,tc.class_fee, tco.course_titel, tco.number_of_class, tco.deduction_percentage,tcr.course_id"
                where_stetment="tcr.status = '1' AND tcr.paid = '0'  AND tcr.cancel = '0' AND tcr.student_id = '"+str(student_id)+"' ORDER BY tcr.course_id " 
                join_query="tblClassRequest as tcr "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblClass as tc ON tc.class_id = tcr.class_id "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblCourse as tco ON tco.course_id = tcr.course_id "
                query=select_query(join_query,columns,where_stetment) 
                # print(query)                   
                unpaid_classes = db.get_data(query)
                # print(unpaid_classes)
                code=200
                return {'unpaid_classes': unpaid_classes}, code
            else:
                columns=" tpm.*, tco.course_titel"
                where_stetment="tpm.status = '1' AND tpm.user_id = '"+str(user_id)+"' ORDER BY tpm.course_id,tpm.pay_date ASC LIMIT 10  OFFSET "+offset   
                join_query="tblPayMoney as tpm "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblCourse as tco ON tco.course_id = tpm.course_id "
                query=select_query(join_query,columns,where_stetment) 
                # print(query)                   
                paid_classes = db.get_data(query)                
                code=200
                return {'paid_classes': paid_classes}, code


            # columns="*"
            # where_stetment="status = '1' and course_id = '"+str(course_id)+"' ORDER BY class_number ASC LIMIT 10  OFFSET "+offset  
            # query=select_query("tblClass",columns,where_stetment)                    
            # classes = db.get_data(query)

            code =200

        return {'classes': classes}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        received_money=None
        received_money_id=0
        user_id = get_user_id()
        if authentication() == True:

            db=Db()

            if args['method']=='cancel_request':

                class_request_id = data['class_request_id']
                student_id = get_student_id(user_id,db)
                # print(student_id)

                columns="class_request_id"
                where_stetment="class_request_id = '"+str(class_request_id)+"' AND student_id = '"+str(student_id)+"'  AND paid = '0'"  
                query=select_query("tblClassRequest",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                # print(search)

                if search != None:                    
                    query="DELETE FROM tblClassRequest WHERE class_request_id = '"+str(class_request_id)+"'" 
                    msg = db.update_data(query)
                    return {'data': msg}, 200
            elif args['method']=='class_pay':

                course_id = data['course_id']
                student_id = get_student_id(user_id,db)

                if course_id == "" :
                    return {'data': received_money}, code

                columns=" tu.current_balance,tco.number_of_class, tco.deduction_percentage"
                where_stetment="tu.user_id = '"+str(user_id)+"'"  
                join_query="tblUser as tu "
                join_query=join_query+"LEFT JOIN "
                join_query=join_query+"tblCourse as tco ON tco.course_id = '"+str(course_id)+"' "
                query=select_query(join_query,columns,where_stetment) 
                # print(query)                   
                balance = db.get_data_by_key(query)

                columns="tcr.class_id,tc.class_fee,tcr.class_request_id"
                where_stetment="tcr.status = '1' AND tcr.paid = '0'  AND tcr.course_id = '"+str(course_id)+"' AND tcr.student_id = '"+str(student_id)+"'"  
                  
                join_query="tblClassRequest as tcr "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblClass as tc ON tc.class_id = tcr.class_id "
                query=select_query(join_query,columns,where_stetment)
                unpaid_classes = db.get_data(query)

                pay_transaction_id = str(uuid.uuid4())
                total_fee=0
                column_names=['student_id',
                                'class_id',
                                'pay_transaction_id',
                                'class_step',
                                'create_date',
                                'status']
                update_column_names=['paid']
                querys=[]
                update_querys=[]
                for unpaid_classe in unpaid_classes:
                    total_fee = total_fee+unpaid_classe[1]
                    values=[str(student_id),
                            str(unpaid_classe[0]),
                            pay_transaction_id,
                            '1',
                            str(time.time()),
                            '1']
                    query=insert_query("tblStudentAccessClass",column_names,values,"student_access_class_id")
                    querys.append(query)

                    where_stetment="class_request_id = '"+str(unpaid_classe[2])+"'"
                    query=update_query("tblClassRequest",['paid'],['1'],where_stetment)
                    update_querys.append(query)

                deduction=0
                number_of_class = len(unpaid_classes)
                if number_of_class>=balance[1]:
                    deduction = (total_fee*balance[2])/100

                total_fee = total_fee -deduction

                if total_fee<=balance[0]:

                    le_charge =int(total_fee/5)

                    column_names=['user_id',
                                    'course_id',
                                    'number_of_class',
                                    'total_bill',
                                    'deduction',
                                    'le_charge',
                                    'vat',
                                    'pay_transaction_id',
                                    'pay_date',
                                    'status']
                    values=[str(user_id),
                            str(course_id),
                            str(number_of_class),
                            str(total_fee),
                            str(deduction),
                            str(le_charge),
                            '0',
                            pay_transaction_id,
                            str(time.time()),
                            '1']
                    query=insert_query("tblPayMoney",column_names,values,"pay_money_id")
                    # print(query)
                    pay_money_id = db.insert_data(query)

                    msg=" লি একাডেমির কোর্স ক্রয়ের ক্রয়মূল্য-"+str(total_fee)+" BDT প্রদানের  জন্য ধন্যবাদ । বিস্তারিত ভিজিট করুনঃ http://learningac.com/"
                    subject="কোর্স ফী প্রদান "
                    send_notification(user_id,subject,msg)
                    send_mobile_msg_by_user_id(user_id,msg,db)

                    # # Update user balance
                    # column_names=['current_balance']
                    # blnc=balance[0]-total_fee
                    # values=[str(blnc)]
                    
                    # where_stetment="user_id = '"+str(user_id)+"'"
                    # query=update_query("tblUser",column_names,values,where_stetment)
                    # res = db.update_data(query)

                    # Insert access classes
                    res = db.multi_queries(querys)
                    # Update class request
                    res = db.multi_queries(update_querys)

                    # Teacher balance insert
                    columns="teacher_id"
                    where_stetment="status = '1' AND course_id = '"+str(course_id)+"'"  
                    query=select_query("tblCourse",columns,where_stetment)                    
                    teacher = db.get_data_by_key(query)
                    
                    column_names=['teacher_id',
                                    'course_id',
                                    'pay_money_id',
                                    'fee',
                                    'create_date',
                                    'status']
                    values=[str(teacher[0]),
                            str(course_id),
                            str(pay_money_id),
                            str(total_fee-le_charge),
                            str(time.time()),
                            '1']
                    query=insert_query("tblTeacherFee",column_names,values,"teacher_fee_id")
                    # print(query)
                    teacher_fee_id = db.insert_data(query)


                    columns="user_id"
                    where_stetment="teacher_id = '"+str(teacher[0])+"' "  
                    query=select_query("tblTeacher",columns,where_stetment)                    
                    teacher_id = db.get_data_by_key(query)

                    msg=" আপনার লি একাডেমির কোর্স ফি "+str(total_fee-le_charge)+" BDT একাউন্টে যুক্ত হয়েছে।বিস্তারিত জানতে ভিজিট করুনঃ http://learningac.com/"
                    subject="কোর্স ফী গ্রহণ "
                    send_notification(teacher_id[0],subject,msg)
                    send_mobile_msg_by_user_id(teacher_id[0],msg,db)

                    # le charge update
                    
                    column_names=['course_id',
                                    'pay_money_id',
                                    'fee',
                                    'create_date',
                                    'status']
                    values=[str(course_id),
                            str(pay_money_id),
                            str(le_charge),
                            str(time.time()),
                            '1']
                    query=insert_query("tblCompanyFee",column_names,values,"company_fee_id")
                    # print(query)
                    company_fee_id = db.insert_data(query)

                    columns=" tcr.class_id,tc.class_number,tc.class_titel,tc.class_fee, tco.course_titel, tco.number_of_class, tco.deduction_percentage,tcr.course_id"
                    where_stetment="tcr.status = '1' AND tcr.paid = '0'  AND tcr.cancel = '0' AND tcr.student_id = '"+str(student_id)+"' ORDER BY tcr.course_id " 
                    join_query="tblClassRequest as tcr "
                    join_query=join_query+"LEFT JOIN "
                    join_query=join_query+"tblClass as tc ON tc.class_id = tcr.class_id "
                    join_query=join_query+"LEFT JOIN "
                    join_query=join_query+"tblCourse as tco ON tco.course_id = tcr.course_id "
                    query=select_query(join_query,columns,where_stetment) 
                    # print(query)                   
                    unpaid_classes = db.get_data(query)
                    code=200
                    return {'data': unpaid_classes}, code



            elif args['method']=='delete':

                received_money_id = data['received_money_id']

                columns="received_money_id"
                where_stetment="received_money_id = '"+str(received_money_id)+"' AND user_id = '"+str(user_id)+"'  AND received = '0'"  
                query=select_query("tblReceivedMoney",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search != None:                    
                    query="DELETE FROM tblReceivedMoney WHERE received_money_id = '"+str(received_money_id)+"'" 
                    msg = db.update_data(query)
                    return {'data': msg}, 200

            elif args['method']=='post':

                account_name = data['account_name']
                to_account_number = data['to_account_number']
                from_account_number = data['from_account_number']
                reference = data['reference']
                amount = data['amount']
                if account_name == "" or to_account_number == "" or from_account_number == "" or reference=="" or amount == "":
                    return {'data': received_money}, code

                columns="received_money_id"
                where_stetment="status = '1' and received = '0' and user_id = '"+str(user_id)+"' and reference = '"+reference+"' and from_account_number = '"+from_account_number+"'"    
                query=select_query("tblReceivedMoney",columns,where_stetment)                    
                search = db.get_data_by_key(query)

                if search == None:

                    column_names=['user_id',
                                    'account_name',
                                    'to_account_number',
                                    'from_account_number',
                                    'reference',
                                    'amount',
                                    'money_transfer_id',
                                    'received',
                                    'received_date',
                                    'status']
                    values=[str(user_id),
                            account_name,
                            to_account_number,
                            from_account_number,
                            reference,
                            str(amount),
                            '',
                            '0',
                            str(time.time()),
                            '1']
                    query=insert_query("tblReceivedMoney",column_names,values,"received_money_id")
                    # print(query)
                    received_money_id = db.insert_data(query)

            elif args['method']=='update':
                if is_admin():
                    received_money_id = data['received_money_id']
                    money_transfer_id = data['money_transfer_id']

                    columns=" user_id, amount "
                    where_stetment="received_money_id = '"+str(received_money_id)+"' AND received = '0'"           
                    query=select_query("tblReceivedMoney",columns,where_stetment)                    
                    received_money = db.get_data_by_key(query)
                    if received_money != None:
                        column_names=['money_transfer_id',
                                        'received',
                                        'status']
                        values=[money_transfer_id,
                                '1',
                                '1']
                        
                        where_stetment="received_money_id = '"+str(received_money_id)+"'"
                        query=update_query("tblReceivedMoney",column_names,values,where_stetment)
                        # print(query)
                        
                        res = db.update_data(query)

                        columns=" current_balance "
                        where_stetment="user_id = '"+str(received_money[0])+"'"           
                        query=select_query("tblUser",columns,where_stetment)                    
                        balance = db.get_data_by_key(query)
                        if balance != None:
                            column_names=['current_balance']
                            blnc=balance[0]+received_money[1]
                            values=[str(blnc)]
                            
                            where_stetment="user_id = '"+str(received_money[0])+"'"
                            query=update_query("tblUser",column_names,values,where_stetment)
                            # print(query)
                            
                            res = db.update_data(query)
                else:
                    return {'data': received_money}, code

                        
                    
                
            columns=" * "
            where_stetment="received_money_id = '"+str(received_money_id)+"'"           
            query=select_query("tblReceivedMoney",columns,where_stetment)                    
            received_money = db.get_data_by_key(query)
            code =200               
                    

        return {'data': received_money}, code

api.add_resource(StudentPaymentApi, '/student_payment_api')

@app.route("/notification", methods=['GET', 'POST'])
def notification():
    if authentication()==False:
        return redirect(url_for('login'))
   
    return render_template('notification.html', title='নোটিফিকেশন')

def send_notification(user_id,subject,notification):
    db=Db()
    column_names=['user_id',
                'subject',
                'notification',
                'create_date',
                'read',
                'status']
    values=[str(user_id),
            subject,
            notification,
            str(time.time()),
            '0',
            '1']
    query=insert_query("tblNotification",column_names,values,"notification_id")
    # print(query)
    notification_id = db.insert_data(query)

    return notification_id

@app.route("/get_unread_notification", methods=['GET'])
def get_unread_notification():
    
    user_id = get_user_id()
    db = Db()

    columns=" COUNT(notification_id) "
    where_stetment="user_id = '"+str(user_id)+"' AND read = '0' "           
    query=select_query("tblNotification",columns,where_stetment)                    
    notification_count = db.get_data_by_key(query)


    result={"notification_count":notification_count}

    return jsonify(result)

class NotificationApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('offset', required=True)
        
        args = parser.parse_args()

        offset = args['offset']
        msg="unauthorized request"
        code =401
        volunteers=None
        volunteer=None
        user_id = get_user_id()
        if authentication() == True:
            db=Db()
            
            columns=" * "  
            where_stetment="user_id = '"+str(user_id)+"' ORDER BY create_date DESC LIMIT 50  OFFSET "+offset
           
            query=select_query('tblNotification',columns,where_stetment)                    
            notifications = db.get_data(query)
            code =200
            msg="successfully"

        return {'message': msg, 'notifications': notifications}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        notification=None
        notification_id=0
        user_id = get_user_id()
        if authentication() == True:

            db=Db()
            
            if args['method']=='read':
                notification_id = data['notification_id']

                column_names=['read']
                values=['1']

                where_stetment="notification_id = '"+str(notification_id)+"'"
                query=update_query("tblNotification",column_names,values,where_stetment)
            
                res = db.update_data(query)

            elif args['method']=='delete':
                notification_id = data['notification_id']

                columns="*"                            
                where_stetment="notification_id = '"+str(notification_id)+"' AND user_id = '"+str(user_id)+"'"

                query=select_query('tblNotification',columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search!=None:                
                    query="DELETE FROM tblNotification WHERE notification_id = '"+str(notification_id)+"'" 
                    msg = db.update_data(query)
                    return {'message': msg}, 200
                
            
            columns="*"
                            
            where_stetment="notification_id = '"+str(notification_id)+"'"

            query=select_query('tblNotification',columns,where_stetment)                    
            notification = db.get_data_by_key(query)
            code =200               
                    

        return {'message': msg, 'data': notification}, code

api.add_resource(NotificationApi, '/notification_api')


@app.route("/help_question", methods=['GET', 'POST'])
def help_question():
    if authentication()==False:
        return redirect(url_for('login'))
        
    return render_template('help_question.html', title='নোটিফিকেশন')

class HelpQuestionApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('offset', required=True)
        parser.add_argument('help_type', required=True)
        
        args = parser.parse_args()

        offset = args['offset']
        help_type = args['help_type']
        msg="unauthorized request"
        code =401
        volunteers=None
        volunteer=None
        user_id = get_user_id()
        if authentication() == True:
            db=Db()

            if is_admin() == True:

                columns=" thq.*,tu.name,tu.profile_pic"
                if help_type=="":
                    where_stetment="thq.status = '1' ORDER BY thq.answered DESC LIMIT 10  OFFSET "+offset 
                else:
                    where_stetment="thq.status = '1' AND thq.help_type = '"+help_type+"' ORDER BY thq.answered DESC LIMIT 10  OFFSET "+offset 
                join_query="tblHelpQuestion as thq "
                join_query=join_query+"INNER JOIN "
                join_query=join_query+"tblUser as tu ON tu.user_id = thq.user_id "
                query=select_query(join_query,columns,where_stetment)                   
                help_questions = db.get_data(query)
            else:
                columns=" * "  
                where_stetment="user_id = '"+str(user_id)+"' ORDER BY create_date DESC "
               
                query=select_query('tblHelpQuestion',columns,where_stetment)                    
                help_questions = db.get_data(query)
                print(help_questions)
            code =200
            msg="successfully"

        return {'help_questions': help_questions}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        help_question=None
        help_question_id=0
        user_id = get_user_id()
        if authentication() == True:

            db=Db()
            
            if args['method']=='post':
                help_type = data['help_type']
                message = rmqt(data['message'])

                columns="help_question_id"
                where_stetment="user_id = '"+str(user_id)+"' AND help_type = '"+help_type+"'  AND message = '"+message+"' "  
                query=select_query("tblHelpQuestion",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['user_id',
                                    'help_type',
                                    'message',
                                    'answered',
                                    'create_date',
                                    'status']
                    values=[str(user_id),
                            help_type,
                            message,
                            '0',
                            str(time.time()),
                            '1']
                    query=insert_query("tblHelpQuestion",column_names,values,"help_question_id")
                    # print(query)
                    help_question_id = db.insert_data(query)
                    msg = 'successfully'
            elif args['method']=='answer':
                if is_admin() == True:
                    help_question_id = data['help_question_id']

                    column_names=['answered']
                    values=['1']
                
                    where_stetment="help_question_id = '"+str(help_question_id)+"'"
                    query=update_query("tblHelpQuestion",column_names,values,where_stetment)
                    # print(query)
                    
                    res = db.update_data(query)
                else:
                    return {'data': help_question}, code
                
            
            columns="*"
                            
            where_stetment="help_question_id = '"+str(help_question_id)+"'"

            query=select_query('tblHelpQuestion',columns,where_stetment)                    
            help_question = db.get_data_by_key(query)
            code =200               
                    

        return {'data': help_question}, code

api.add_resource(HelpQuestionApi, '/help_question_api')

@app.route("/survey_patients", methods=['GET', 'POST'])
def survey_patients():
    
    if authentication()==False:
        return redirect(url_for('login'))
    

    return render_template('survey_patients.html', title='survey_patients')


class SurveyPatientApi(Resource):
    def get(self):
        parser = reqparse.RequestParser() 
        parser.add_argument('offset', required=True)        
        args = parser.parse_args()
        offset = args['offset']
        msg="unauthorized request"
        code =401
        survey_patients=None
        user_id = get_user_id()
        db=Db()
        
        columns="tsp.survey_patient_id, tp.*  "    
        where_stetment="tsp.status = '1' and tpc.user_id = '"+str(user_id)+"' ORDER BY tsp.create_date DESC LIMIT 10  OFFSET "+offset   
        join_query="tblPatientConnection as tpc "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSurveyPatient as tsp ON tsp.patient_id = tpc.patient_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tsp.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        survey_patients = db.get_data(query)

        code =200

        return {'survey_patients': survey_patients}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        covid_patient=None
        survey_patient_id=0
        

        db=Db()
        user_id = get_user_id()
        if user_id<=0:
            return {'data': []}, code

        if args['method']=='post':
            
            patient_id = data['patient_id']

            columns="patient_id"
            where_stetment="patient_id = '"+str(patient_id)+"' AND user_id = '"+str(user_id)+"' "   
            query=select_query("tblPatientConnection",columns,where_stetment)                    
            search = db.get_data_by_key(query)

            if search == None:
                return {'data': []}, code

            columns="survey_patient_id"
            where_stetment="patient_id = '"+str(patient_id)+"' "   
            query=select_query("tblSurveyPatient",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['patient_id',
                                'create_date',
                                'status']
                values=[str(patient_id),
                        str(time.time()),
                        '1']
                query=insert_query("tblSurveyPatient",column_names,values,"survey_patient_id")
                # print(query)
                survey_patient_id = db.insert_data(query)

                column_names=['survey_patient_id',
                                'patient_id',
                                'family_lead',
                                'create_date',
                                'status']
                values=[str(survey_patient_id),
                        str(patient_id),
                        '1',
                        str(time.time()),
                        '1']
                query=insert_query("tblFamilyPatient",column_names,values,"family_patient_id")
                # print(query)
                family_patient_id = db.insert_data(query)

            else:
                return {'msg':["You already added this parson name."],'data': []}, 200
                
        elif args['method']=='delete':                
            survey_patient_id = data['survey_patient_id']

            columns="COUNT(survey_patient_id),MAX(family_patient_id)"
            where_stetment="survey_patient_id = '"+str(survey_patient_id)+"' "   
            query=select_query("tblFamilyPatient",columns,where_stetment)                    
            search = db.get_data_by_key(query)

            if search == None or search[0]<=1:
                query="DELETE FROM tblSurveyPatient WHERE survey_patient_id = '"+str(survey_patient_id)+"'" 
                msg = db.update_data(query)

                if search!=None:
                    query="DELETE FROM tblFamilyPatient WHERE family_patient_id = '"+str(search[1])+"'" 
                    msg = db.update_data(query)
                return {'data': []}, 200
            else:
                return {'data': None}, 200
          
        
        columns="tsp.survey_patient_id, tp.*  "    
        where_stetment="tsp.status = '1' and tsp.survey_patient_id = '"+str(survey_patient_id)+"' "  
        join_query="tblSurveyPatient as tsp "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tsp.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        survey_patient = db.get_data_by_key(query)
        code =200               
                    

        return {'data': survey_patient}, code

api.add_resource(SurveyPatientApi, '/survey_patient_api')


@app.route("/get_survey_patients", methods=['GET'])
def get_survey_patients():

    offset = request.args.get('offset')
    db = Db()
    user_id = get_user_id()    
    from_date = datetime.now().date()

    columns="tsp.survey_patient_id, tp.*,ttr.survey_treatment_report_id  "    
    where_stetment="tsp.status = '1' and tpc.user_id = '"+str(user_id)+"' and ttr.survey_treatment_report_id  IS NULL ORDER BY tsp.create_date DESC LIMIT 10  OFFSET "+offset   
    join_query="tblPatientConnection as tpc "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblSurveyPatient as tsp ON tsp.patient_id = tpc.patient_id "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tp ON tp.patient_id = tsp.patient_id "
    join_query=join_query+"LEFT JOIN "
    join_query=join_query+"tblSurveyTreatmentReport as ttr ON ttr.patient_id = tsp.patient_id AND ttr.report_date = '"+str(from_date)+"' "
    query=select_query(join_query,columns,where_stetment)                    
    survey_patients = db.get_data(query)
    code =200

    result={"survey_patients":survey_patients}
    

    return jsonify(result)


@app.route("/get_survey_patient", methods=['GET'])
def get_survey_patient():

    survey_patient_id = request.args.get('id')
    db = Db()    

    columns="tsp.survey_patient_id, tp.*  "    
    where_stetment="tsp.status = '1' and tsp.survey_patient_id = '"+str(survey_patient_id)+"' "  
    join_query="tblSurveyPatient as tsp "
    join_query=join_query+"INNER JOIN "
    join_query=join_query+"tblPatient as tp ON tp.patient_id = tsp.patient_id "
    query=select_query(join_query,columns,where_stetment)                    
    survey_patient = db.get_data_by_key(query)
    code =200

    result={"survey_patient":survey_patient}
    

    return jsonify(result)

@app.route("/family_patients", methods=['GET', 'POST'])
def family_patients():
    
    if authentication()==False:
        return redirect(url_for('login'))

    sp = request.args.get('id')

    return render_template('family_patients.html', title='family_patients',sp=sp)


class FamilyPatientApi(Resource):
    def get(self):
        parser = reqparse.RequestParser() 
        parser.add_argument('id', required=True)        
        args = parser.parse_args()
        survey_patient_id = args['id']
        msg="unauthorized request"
        code =401
        family_patients=None
        user_id = get_user_id()
        db=Db()
        
        columns="tfp.family_patient_id, tp.*  "    
        where_stetment="tfp.survey_patient_id = '"+str(survey_patient_id)+"' and tpc.user_id = '"+str(user_id)+"' "  
        join_query="tblPatientConnection as tpc "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblFamilyPatient as tfp ON tfp.patient_id = tpc.patient_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tfp.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        family_patients = db.get_data(query)

        code =200

        return {'family_patients': family_patients}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        covid_patient=None
        family_patient_id=0
        

        db=Db()
        user_id = get_user_id()
        if user_id<=0:
            return {'data': []}, code

        if args['method']=='post':
            
            patient_id = data['patient_id']
            survey_patient_id = data['survey_patient_id']

            columns="patient_id"
            where_stetment="patient_id = '"+str(patient_id)+"' AND user_id = '"+str(user_id)+"' "   
            query=select_query("tblPatientConnection",columns,where_stetment)                    
            search = db.get_data_by_key(query)

            if search == None:
                return {'data': []}, code

            columns="family_patient_id"
            where_stetment="patient_id = '"+str(patient_id)+"' "   
            query=select_query("tblFamilyPatient",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['survey_patient_id',
                                'patient_id',
                                'family_lead',
                                'create_date',
                                'status']
                values=[str(survey_patient_id),
                        str(patient_id),
                        '0',
                        str(time.time()),
                        '1']
                query=insert_query("tblFamilyPatient",column_names,values,"family_patient_id")
                # print(query)
                family_patient_id = db.insert_data(query)

            else:
                return {'msg':["You already added this parson name."],'data': []}, 200

        elif args['method']=='set_family_lead':

            family_patient_id = data['family_patient_id']

            columns="survey_patient_id,patient_id"
            where_stetment="family_patient_id = '"+str(family_patient_id)+"' "   
            query=select_query("tblFamilyPatient",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search != None:

                columns="patient_id"
                where_stetment="survey_patient_id = '"+str(search[0])+"'"   
                query=select_query("tblSurveyPatient",columns,where_stetment)                    
                search1 = db.get_data_by_key(query)

                column_names=['patient_id']
                values=[str(search[1])]
                
                where_stetment="survey_patient_id = '"+str(search[0])+"'"
                query=update_query("tblSurveyPatient",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query)
                


                column_names=['family_lead']
                values=['1']
                
                where_stetment="patient_id = '"+str(search[1])+"'"
                query=update_query("tblFamilyPatient",column_names,values,where_stetment)
            
                res = db.update_data(query)

                column_names=['family_lead']
                values=['0']
                
                where_stetment="patient_id = '"+str(search1[0])+"'"
                query=update_query("tblFamilyPatient",column_names,values,where_stetment)
            
                res = db.update_data(query)

        
        elif args['method']=='delete':                
            family_patient_id = data['family_patient_id']

            columns="tfp.family_patient_id,tfp.family_lead"    
            where_stetment="tfp.family_patient_id = '"+str(family_patient_id)+"' and tpc.user_id = '"+str(user_id)+"' "   
            join_query="tblPatientConnection as tpc "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblFamilyPatient as tfp ON tfp.patient_id = tpc.patient_id "
            query=select_query(join_query,columns,where_stetment)                    
            family_patient = db.get_data_by_key(query)

            if family_patient != None and family_patient[1]==0:
                query="DELETE FROM tblFamilyPatient WHERE family_patient_id = '"+str(family_patient_id)+"'" 
                msg = db.update_data(query)
                return {'data': []}, 200
            else:
                return {'data': None}, 200
          
        
        columns="tfp.family_patient_id, tp.*  "    
        where_stetment="tfp.status = '1' and tfp.family_patient_id = '"+str(family_patient_id)+"' "  
        join_query="tblFamilyPatient as tfp "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tfp.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        family_patient = db.get_data_by_key(query)
        code =200               
                    

        return {'data': family_patient}, code

api.add_resource(FamilyPatientApi, '/family_patient_api')

@app.route("/survey_symptom", methods=['GET', 'POST'])
def survey_symptom():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('survey_symptom.html', title='Survey Symptom')

class SurveySymptomApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        survey_symptoms=None
        db=Db() 

        columns="tss.survey_symptom_id,ts.symptom,ts.body_area,ts.symptom_id"
        where_stetment="tss.status = '1' " 
        join_query="tblSurveySymptom as tss "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tss.symptom_id "
        query=select_query(join_query,columns,where_stetment)                     
        survey_symptoms = db.get_data(query)

        code =200

        return {'survey_symptoms': survey_symptoms}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        survey_symptom=None
        survey_symptom_id=0
        

        db=Db()

        if args['method']=='post':

            symptom_id = data['symptom_id']

            columns="survey_symptom_id"
            where_stetment="symptom_id = '"+str(symptom_id)+"' "   
            query=select_query("tblSurveySymptom",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['symptom_id',
                                'create_date',
                                'status']
                values=[str(symptom_id),
                        str(time.time()),
                        '1']
                query=insert_query("tblSurveySymptom",column_names,values,"survey_symptom_id")
                # print(query)
                survey_symptom_id = db.insert_data(query)
                        

        elif args['method']=='delete':                
            survey_symptom_id = data['survey_symptom_id']

            query="DELETE FROM tblSurveySymptom WHERE survey_symptom_id = '"+str(survey_symptom_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        
        columns="tss.survey_symptom_id,ts.symptom,ts.body_area"
        where_stetment="tss.status = '1' AND tss.survey_symptom_id = '"+str(survey_symptom_id)+"' " 
        join_query="tblSurveySymptom as tss "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSymptom as ts ON ts.symptom_id = tss.symptom_id "
        query=select_query(join_query,columns,where_stetment)                     
        survey_symptom = db.get_data_by_key(query)
        code =200               
                    

        return {'data': survey_symptom}, code

api.add_resource(SurveySymptomApi, '/survey_symptom_api')


@app.route("/survey_treatment", methods=['GET', 'POST'])
def survey_treatment():
    if authentication()==False:
        return redirect(url_for('login'))

    if is_admin()==False:
        return redirect(url_for('index'))
    
    
    return render_template('survey_treatment.html', title='survey_treatment')

class SurveyTreatmentApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()        
        args = parser.parse_args()
        msg="unauthorized request"
        code =401
        survey_treatments=None
        db=Db() 

        columns="*"
        where_stetment="status = '1'"  
        query=select_query("tblSurveyTreatment",columns,where_stetment)                    
        survey_treatments = db.get_data(query)

        code =200

        return {'survey_treatments': survey_treatments}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        survey_treatment=None
        survey_treatment_id=0
        

        db=Db()

        if args['method']=='post':
            survey_treatment = rmqt(data['survey_treatment'])
            rules = data['rules']

            columns="survey_treatment_id"
            where_stetment="survey_treatment = '"+survey_treatment+"' "   
            query=select_query("tblSurveyTreatment",columns,where_stetment)                    
            search = db.get_data_by_key(query)
            if search == None:

                column_names=['survey_treatment',
                                'rules',
                                'create_date',
                                'status']
                values=[survey_treatment,
                        rules,
                        str(time.time()),
                        '1']
                query=insert_query("tblSurveyTreatment",column_names,values,"survey_treatment_id")
                # print(query)
                survey_treatment_id = db.insert_data(query)
            else:
                survey_treatment_id = search[0]

        elif args['method']=='update':                
            survey_treatment_id = data['survey_treatment_id']

            survey_treatment = rmqt(data['survey_treatment'])
            rules = data['rules']

            column_names=['survey_treatment',
                            'rules']
            values=[survey_treatment,
                    rules]
            
            where_stetment="survey_treatment_id = '"+str(survey_treatment_id)+"'"
            query=update_query("tblSurveyTreatment",column_names,values,where_stetment)
            # print(query)
        
            res = db.update_data(query)
            

        elif args['method']=='delete':                
            survey_treatment_id = data['survey_treatment_id']

            query="DELETE FROM tblSurveyTreatment WHERE survey_treatment_id = '"+str(survey_treatment_id)+"'" 
            msg = db.update_data(query)
            return {'data': []}, 200
          
        
        columns="*"
        where_stetment="survey_treatment_id = '"+str(survey_treatment_id)+"'"  
        query=select_query("tblSurveyTreatment",columns,where_stetment)                    
        survey_treatment = db.get_data_by_key(query)
        code =200               
                    

        return {'data': survey_treatment}, code

api.add_resource(SurveyTreatmentApi, '/survey_treatment_api')


@app.route("/survey_patient_reports", methods=['GET', 'POST'])
def survey_patient_reports():
    if authentication()==False:
        return redirect(url_for('login'))
        
    
    return render_template('survey_patient_reports.html', title='survey_patient_reports')

class SurveyReportApi(Resource):
    def get(self):
        parser = reqparse.RequestParser() 
        parser.add_argument('offset', required=True)        
        args = parser.parse_args()
        offset = args['offset']
        msg="unauthorized request"
        code =401
        survey_reports=None
        user_id = get_user_id()
        db=Db()
        from_date = datetime.now().date() - timedelta(days=7)

        columns="tp.patient_id,tp.patient_name,tp.profile_pic, TO_CHAR(tstr.report_date, 'YYYY-MM-DD'),ARRAY_AGG(tstr.survey_treatment_id || ' ' || tstr.taken),ARRAY_AGG(tssr.symptom_id || ' ' || tssr.symptom_level)  "    
        where_stetment="tpc.user_id = '"+str(user_id)+"' AND tstr.report_date >= '"+str(from_date)+"' group by tp.patient_id,tstr.report_date ORDER BY tp.patient_id ASC LIMIT 35 OFFSET "+offset  
        join_query="tblPatientConnection as tpc "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSurveyTreatmentReport as tstr ON tstr.patient_id = tpc.patient_id "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblSurveySymptomReport as tssr ON tssr.patient_id = tstr.patient_id AND tssr.report_date = tstr.report_date "
        join_query=join_query+"INNER JOIN "
        join_query=join_query+"tblPatient as tp ON tp.patient_id = tpc.patient_id "
        query=select_query(join_query,columns,where_stetment)                    
        survey_reports = db.get_data(query)

        code =200

        return {'survey_reports': survey_reports}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        
        db=Db()

        if args['method']=='post':

            treatment_datas = data['treatment_datas']

            for treatment_data in treatment_datas:

                patient_id = treatment_data['patient_id'] 
                survey_treatment_id = treatment_data['survey_treatment_id']
                taken = treatment_data['taken']
                report_date = datetime.now().date() 

                column_names=['patient_id',
                                'survey_treatment_id',
                                'taken',
                                'report_date',
                                'status']
                values=[str(patient_id),
                        str(survey_treatment_id),
                        str(taken),
                        str(report_date),
                        '1']
                query=insert_query("tblSurveyTreatmentReport",column_names,values,"survey_treatment_report_id")
                # print(query)
                survey_treatment_report_id = db.insert_data(query)
                print(survey_treatment_report_id)

            symptom_datas = data['symptom_datas']
            
            for symptom_data in symptom_datas:

                patient_id = symptom_data['patient_id'] 
                symptom_id = symptom_data['symptom_id']  
                symptom_level = symptom_data['symptom_level']   
                report_date = datetime.now().date() 

                column_names=['patient_id',
                                'symptom_id',
                                'symptom_level',
                                'report_date',
                                'status']
                values=[str(patient_id),
                        str(symptom_id),
                        str(symptom_level),
                        str(report_date),
                        '1']
                query=insert_query("tblSurveySymptomReport",column_names,values,"survey_symptom_report_id")
                # print(query)
                survey_symptom_report_id = db.insert_data(query)
                print(survey_symptom_report_id)         
        

            code =200               
                    

        return {'data': []}, code

api.add_resource(SurveyReportApi, '/survey_report_api')


@app.route("/view_survey_reports", methods=['GET', 'POST'])
def view_survey_reports():
    if authentication()==False:
        return redirect(url_for('login'))
        
    
    return render_template('view_survey_reports.html', title='view_survey_reports')


@app.route("/settings", methods=['GET', 'POST'])
def settings():

    if authentication()==False:
        return redirect(url_for('login'))

    if session['login_user'][2]<2:
        return redirect(url_for('index'))
    

    return render_template('settings.html', title='সেটিংস')

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def allowed_pdf_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_PDFEXTENSIONS

def allowed_ppt_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_PPTEXTENSIONS

def getImageList(persons):

    personLst=[]
    for person in persons:
        face_list=os.listdir("static/assets/img/")
        
        if 0<len(face_list):
            filename="static/assets/img/"+face_list[0]
            personLst.append((person[0],person[1],filename))
    return personLst


@app.route("/profile", methods=['GET', 'POST'])
def profile():
    
    if authentication()==False:
        return redirect(url_for('login'))

    user_id = get_user_id();
    columns="name,gender,profile_pic,district,town,village"
    where_stetment="status = '1' AND user_id = '"+str(user_id)+"'"
    query=select_query("tblUser",columns,where_stetment)
    # print(query)
    db=Db()
    user_info = db.get_data_by_key(query)
    

    return render_template('profile.html', title='প্রোফাইল',user_info=user_info)

@app.route("/update_profile", methods=['GET', 'POST'])
def update_profile():
    
    if authentication()==False:
        return redirect(url_for('login'))
    db=Db()
    user_id = get_user_id()
    columns="name,gender,profile_pic,district,town,village,user_id"
    where_stetment="status = '1' AND user_id = '"+str(user_id)+"'"
    query=select_query("tblUser",columns,where_stetment)
    # print(query)
   
    user_info = db.get_data_by_key(query)
    districts = db.get_all_district()
    towns=[]
    if len(user_info[3])>0:        
        towns = db.get_thanas_by_district_id(user_info[3])
        # print(towns)

    return render_template('update_profile.html', title='প্রোফাইল পরিবর্তন',user_info=user_info,districts=districts,towns=towns)

class ProfileUpdateApi(Resource):
    
        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        
        db=Db()
        
        if args['method']=='post':
            user_id = data['user_id']
            first_name = rmqt(data['first_name'])
            gender = data['gender']
            district = rmqt(data['district'])
            town = rmqt(data['town'])
            village = rmqt(data['village'])
            profile_pic = data['profile_pic']
            # print(profile_pic)

            column_names=['name','gender','district','town','village']

            values=[first_name,
                gender,
                district,
                town,
                village]
            if profile_pic!='':
                column_names.append('profile_pic')
                values.append(profile_pic)

            where_stetment="user_id = '"+str(user_id)+"'"
            query=update_query("tblUser",column_names,values,where_stetment)
            # print(query)
            
            res = db.update_data(query)
            return {'res': res}, 200
                    

        return {'res': msg}, code

api.add_resource(ProfileUpdateApi, '/profile_update_api')

@app.route("/profile_view", methods=['GET', 'POST'])
def profile_view():
    
    if authentication()==False:
        return redirect(url_for('login'))

    user_id = request.args.get('id')
    columns="name,gender,profile_pic,district,town,village"
    where_stetment="status = '1' AND user_id = '"+str(user_id)+"'"
    query=select_query("tblUser",columns,where_stetment)
    # print(query)
    db=Db()
    user_info = db.get_data_by_key(query)
    

    return render_template('profile_view.html', title='প্রোফাইল',user_info=user_info)

@app.route("/admins", methods=['GET', 'POST'])
def admins():

    if authentication()==False:
        return redirect(url_for('login'))

    if session['login_user'][2]<2:
        return redirect(url_for('index'))

    isAdmin=False
    search_user=[]
    user_id = get_user_id()
    if request.method == 'POST':

        if request.form['action']=="set_associate":

            if len(session['admin'])>0:
                
                column_names=['status']
                values=['1']

                where_stetment="admin_id = '"+str(session['admin'][0])+"'"
                query=update_query("tblAdmin",column_names,values,where_stetment)
                # print(query)
                
                res = db.update_data(query)
            else:
                user_id =request.form['search_user_id']
                db=Db()
                

                column_names=['user_id',
                            'admin_type',
                            'access',
                            'create_date',
                            'security_key',
                            'status']
                values=[str(user_id),
                            'associate admin',
                            '0',
                            str(time.time()),
                            'security_key',
                            '1']

                key = session['key']
                cipher_suite = Fernet(key)
                security_key =str(len(values[0])+len(values[1])+len(values[2])+len(values[3])+len(values[5]))
                ciphered_key = cipher_suite.encrypt(security_key.encode('ASCII'))   #required to be bytes
               
                values[4] = ciphered_key.decode('ASCII')

                query=insert_query("tblAdmin",column_names,values,"admin_id")
                # print(query)
                admin_id = db.insert_data(query)

                # flash('Thanks for add.')
        elif request.form['action']=="remove_admin":

            if session['admin'][2]!="root admin":             
                
                column_names=['status']
                values=['0']

                where_stetment="admin_id = '"+str(session['admin'][0])+"'"
                query=update_query("tblAdmin",column_names,values,where_stetment)
                # print(query)
                
                res = db.update_data(query)
            # else:
            #     flash("Root Admin can not remove.")
        else:
            user_id = request.form['action']
            if user_id=="submit":
                phone_number = request.form['search_phone']
                where_stetment="phone_number = '"+phone_number+"'"
            else:
                where_stetment="user_id = '"+user_id+"'"

            session['key']=""
            session['admin']=[]
            

            db=Db()
            columns="*"
            
            query=select_query("tblUser",columns,where_stetment)                    
            search_user = db.get_data_by_key(query)
            if search_user == None:
                search_user=[]
                # flash('Do not find.')
            else:
                session['key']=search_user[len(search_user)-1]

                columns="admin_id,user_id,admin_type,status"
                where_stetment="user_id = '"+str(search_user[0])+"'"
                query=select_query("tblAdmin",columns,where_stetment)                    
                res = db.get_data_by_key(query)
                if res == None:
                    isAdmin =False
                else:
                    isAdmin = res[3]
                    session['admin']=res

        
    db=Db()
    columns="ta.*"
    where_stetment="ta.status = '1'"
    query=select_query("tblAdmin as ta INNER JOIN tblUser as tu ON ta.user_id = tu.user_id",columns,where_stetment)                    
    admin_users = db.get_data(query)
    
    
    
    return render_template('admins.html', title='admins',search_user=search_user,admin_users=admin_users,isAdmin=isAdmin)


class AdminApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()       
        args = parser.parse_args()
        code =401
        admins=None
        if is_admin() == True:
            db=Db()        

            columns=" tu.name, tu.profile_pic,ta.admin_id,ta.admin_type,ta.access,ta.create_date "    
            where_stetment="ta.status = '1'" 
            join_query="tblAdmin as ta "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = ta.user_id "
            query=select_query(join_query,columns,where_stetment)                    
            admins = db.get_data(query)


            code =200


        return {'admins': admins}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        msg="unauthorized request"
        code =401
        admin=None
        admin_id=0
        if is_admin() == True:

            db=Db()

            if args['method']=='post':
                
                find_user_id = data['find_user_id']
                admin_type = data['admin_type']

                columns="admin_id"
                where_stetment="user_id = '"+str(find_user_id)+"'"  
                query=select_query("tblAdmin",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['user_id',
                                'admin_type',
                                'access',
                                'create_date',
                                'security_key',
                                'status']
                    values=[str(find_user_id),
                            admin_type,
                            '0',
                            str(time.time()),
                            'security_key',
                            '1']

                    key = session['key']
                    cipher_suite = Fernet(key)
                    security_key =str(len(values[0])+len(values[1])+len(values[2])+len(values[3])+len(values[5]))
                    ciphered_key = cipher_suite.encrypt(security_key.encode('ASCII'))   #required to be bytes
                   
                    values[4] = ciphered_key.decode('ASCII')

                    query=insert_query("tblAdmin",column_names,values,"admin_id")
                    # print(query)
                    admin_id = db.insert_data(query)
                
                else:
                    column_names=['status']
                    values=['1']

                    where_stetment="admin_id = '"+str(search[0])+"'"
                    query=update_query("tblAdmin",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)

            elif args['method']=='update':                
                admin_id = data['admin_id']                
                admin_type = data['admin_type']

                column_names=['admin_type','status']
                values=[admin_type,'1']

                where_stetment="admin_id = '"+str(admin_id)+"'"
                query=update_query("tblAdmin",column_names,values,where_stetment)
                # print(query)
            
                res = db.update_data(query) 

            elif args['method']=='admin_cancel':

                admin_id = data['admin_id']

                columns="admin_type"
                where_stetment="admin_id = '"+str(admin_id)+"'"  
                query=select_query("tblAdmin",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search != None and search[0]!="root admin":

                    column_names=['status']
                    values=['0']

                    where_stetment="admin_id = '"+str(admin_id)+"'"
                    query=update_query("tblAdmin",column_names,values,where_stetment)
                    # print(query)
                
                    res = db.update_data(query)
              
            
            
            columns=" tu.name, tu.profile_pic,ta.user_id,ta.admin_type,ta.access,ta.create_date "    
            where_stetment="ta.admin_id = '"+str(admin_id)+"' "
            join_query="tblAdmin as ta "
            join_query=join_query+"INNER JOIN "
            join_query=join_query+"tblUser as tu ON tu.user_id = ta.user_id "
            query=select_query(join_query,columns,where_stetment)                 
            admin = db.get_data_by_key(query)
            code =200               
                    

        return {'data': admin}, code

api.add_resource(AdminApi, '/admin_api')

@app.route("/admin_notification", methods=['GET'])
def admin_notification():
    
    user_id = get_user_id()
    db = Db()
    if is_admin():
        
        columns=" COUNT(received_money_id) "
        where_stetment="status = '1' AND received = '0' "           
        query1=select_query("tblReceivedMoney",columns,where_stetment)

        columns=" COUNT(teacher_application_id) "
        where_stetment="status = '1' AND view = '0' AND view = '0' "           
        query2=select_query("tblTeacherApplication",columns,where_stetment)

        columns=" COUNT(course_verification_id) "
        where_stetment="status = '1' AND course_verification = '0' "           
        query3=select_query("tblCourseVerification",columns,where_stetment)

        query =query1+" UNION ALL "+query2+" UNION ALL "+query3

        notification_count = db.get_data(query)
        print(notification_count)


    result={"notification_count":notification_count}

    return jsonify(result)

def get_key(user_id,db):

    columns=" key "
    where_stetment="user_id = "+ user_id
    query=select_query("tblUser",columns,where_stetment)                    
    key = db.get_data_by_key(query)
    if key != None:
        return key[0]

    else:
        ''

def load_photo(request_files,url):
    photo_url=""
    if url not in request_files:
        flash('No file part')
    else:
        file = request_files[url]
        # if user does not select file, browser also
        # submit a empty part without filename
        if file.filename == '':
            flash('No selected file')
            
        elif file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            uniq_id=str(uuid.uuid4())
            photo_url="static/assets/img/tmp/"+url+uniq_id+".png"
            file.save("app/"+photo_url)
    return photo_url

def load_photos(request_files,url):
    photo_urls=[]
    if url not in request_files:
        flash('No file part')
    else:
        # file = request_files[url]
        files = request_files.getlist(url)
        
        for file in files:
            # if user does not select file, browser also
            # submit a empty part without filename
            if file.filename == '':
                flash('No selected file')
                
            elif file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                uniq_id=str(uuid.uuid4())
                photo_url="static/assets/img/tmp/"+url+uniq_id+".png"
                file.save("app/"+photo_url)
                photo_urls.append(photo_url)
    return photo_urls

def create_payment_url():
    url = 'https://dailycarebd.com/v1/ecom-payment/initiate'
    obj = {'amount': 'amount',
            'transaction_id': 'transaction_id',
            'success_url': 'success_url',
            'fail_url': 'fail_url',
            'customer_name': 'customer_name',
            'purpose': 'purpose'
    }

    #use the 'headers' parameter to set the HTTP headers:
    response = requests.post(url, data = obj, headers = {"client-id": "client-id","client-secret": "client-secret"})
    print(response.code)
    if response.code == 200:
        result = response.json()
        print(result['data'])
        return result['data']['link']

    return ""

@app.route("/GetAllDistrict", methods=['GET', 'POST'])
def GetAllDistrict():

    db = Db()
    if request.method == 'POST':
        if request.form['action']=="submit":
            database = "district.db"
            try:
                conn = sqlite3.connect(database)
                print(sqlite3.version)
                
            except Error as e:
                pass

            cur = conn.cursor()
            cur.execute("SELECT * FROM tblDistrict where status = '1'")
            
            districts = cur.fetchall()
            for district in districts:
                district_id=district[0]
                cur.execute("SELECT * FROM tblThana where status = '1' AND district_id = ? ",(district_id,))
            
                thanas = cur.fetchall()
                for than in thanas:
                    
                    insert=(district[1],than[2])
                    # print("Thana: ",insert)
                    db.insert_thana(insert)

            conn.close()

            # response = requests.get("http://www.amaarhero.com/amaarheroservice.asmx/GetAllDistrict")
            # print(response.status_code)
            # # print(response.json())
            # districts=response.json()
            
            # for dis in districts:                
            #     # print("District: ",dis['Name'])
            #     for than in dis['ThanaList']:
            #         # print(than['Name'])
            #         insert=(dis['Name'],than['Name'])
            #         db.insert_thana(insert)

            
    
    districts = db.get_district_details()

    return render_template('GetAllDistrict.html', title='GetAllDistrict',districts=districts)


@app.route("/get_district", methods=['GET'])
def get_district():
    
    db = Db()
    
    districts = db.get_all_district()

    result={"districts":districts}
    # print(result)

    return jsonify(result)

@app.route("/get_thanas_by_district", methods=['GET'])
def get_thanas_by_district():

    district_id = request.args.get('id')

    db = Db()
    
    # print(flg,intent_id)
    thanas=db.get_thanas_by_district_id(str(district_id))
    # print("intent:",intent)

    result={"thanas":thanas}
    # print(result)

    return jsonify(result)

@app.route("/village", methods=['GET', 'POST'])
def village():
    db=Db()
    key = str(uuid.uuid4())
    users[session['user'][0]] = key
    districts = db.get_all_district()
    return render_template('village.html', title='village',key=key,districts=districts)

@app.route("/get_villages_by_thana", methods=['GET'])
def get_villages_by_thana():

    thana_id = request.args.get('id')

    db = Db()
    
    columns=" village_id,village "
    where_stetment="thana_id = '"+thana_id+"' ORDER BY village asc"
    query=select_query("tblVillage",columns,where_stetment)                    
    villages = db.get_data(query)

    result={"villages":villages}
    # print(result)

    return jsonify(result)

class VillageApi(Resource):
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('thana_id', required=True)
        
        args = parser.parse_args()

        thana_id = args['thana_id']
        msg="unauthorized request"
        code =401
        villages=None
        if authentication() == True:
            db=Db()
            
            columns="village_id,village "
            where_stetment="thana_id = '"+thana_id+"'"
            query=select_query("tblVillage",columns,where_stetment)                    
            villages = db.get_data(query)


            code =200
            msg="successfully"

        return {'message': msg, 'villages': villages}, code

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()
        parser.add_argument('data', required=True)
        
        parser.add_argument('method', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        data = args['data']
        data = json.loads(data)
        code =401
        village=None
        village_id=0
        if authentication() == True:

            db=Db()

            if args['method']=='delete':
                village_id = data['village_id']
                query="DELETE FROM tblVillage WHERE village_id = '"+str(village_id)+"'" 
                msg = db.update_data(query)

            elif args['method']=='post':
                thana_id = data['thana_id']
                village = rmqt(data['village'])

                columns="village_id"
                where_stetment="thana_id = '"+str(thana_id)+"' AND village = '"+str(village)+"'"  
                query=select_query("tblVillage",columns,where_stetment)                    
                search = db.get_data_by_key(query)
                if search == None:

                    column_names=['thana_id',
                                    'village',
                                    'longitude',
                                    'latitude',
                                    'status']
                    values=[str(thana_id),
                            village,
                            '0',
                            '0',
                            '1']
                    query=insert_query("tblVillage",column_names,values,"village_id")
                    # print(query)
                    village_id = db.insert_data(query)

            elif args['method']=='update':
                village_id = data['village_id']
                village = rmqt(data['village'])
                
                column_names=['village',
                                'status']
                values=[village,
                        '1']
                
                where_stetment="village_id = '"+str(village_id)+"'"
                query=update_query("tblVillage",column_names,values,where_stetment)
                # print(query)
                
                res = db.update_data(query)

                    
                
            
            columns=" village_id,village "
            where_stetment="village_id = '"+str(village_id)+"'"           
            query=select_query("tblVillage",columns,where_stetment)                    
            village = db.get_data_by_key(query)
            code =200               
                    

        return {'data': village}, code

api.add_resource(VillageApi, '/village_api')

class ThanaUpdateApi(Resource):
    def get(self):
        data=[]

        return {'message': 'Success', 'data': data}, 200

        
    @limiter.limit("1/second", override_defaults=False)
    def post(self):
        parser = reqparse.RequestParser()

        parser.add_argument('thana_id', required=True)
        parser.add_argument('log', required=True)
        parser.add_argument('lat', required=True)
        parser.add_argument('method', required=True)
        parser.add_argument('key', required=True)

        # Parse the arguments into an object
        args = parser.parse_args()
        print(args)
        msg = ""
        question_id=0
        db=Db()
        if args['method']=='update':

            thana_id=args['thana_id']

            update=(args['log'],args['lat'],1,thana_id)
            db.update_thana_lon_lat(update)
            msg = "Thana update successfully."


        return {'message': msg, 'data': []}, 201

api.add_resource(ThanaUpdateApi, '/update_town')

@app.route('/file-upload', methods=['POST'])
def upload_file():
    
    photo_urls=[]
    if 'file' not in request.files:
        flash('No file part')
    else:
        # file = request_files[url]
        files = request.files.getlist('file')
        
        for file in files:
            # if user does not select file, browser also
            # submit a empty part without filename
            if file.filename == '':
                flash('No selected file')
                
            elif file and allowed_file(file.filename):
                # filename = secure_filename(file.filename)
                uniq_id=str(uuid.uuid4())
                photo_url="static/assets/img/tmp/"+uniq_id+".png"
                file.save("app/"+photo_url)
                photo_urls.append(photo_url)
            elif file and allowed_pdf_file(file.filename):
                # filename = secure_filename(file.filename)
                uniq_id=str(uuid.uuid4())
                photo_url="static/assets/img/tmp/"+uniq_id+".pdf"
                file.save("app/"+photo_url)
                photo_urls.append(photo_url)
            elif file and allowed_ppt_file(file.filename):
                # filename = secure_filename(file.filename)
                uniq_id=str(uuid.uuid4())
                photo_url="static/assets/img/tmp/"+uniq_id+".pptx"
                file.save("app/"+photo_url)
                photo_urls.append(photo_url)

    prescription_img_url = ','.join(photo_urls)
    # print(prescription_img_url)

    return jsonify({'url' : prescription_img_url})


@app.route("/verificourses", methods=['GET', 'POST'])
def verificourses():
    
    return render_template('verificourses.html', title='verificourses')



# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port='80', threaded=True)
    # socketio.run( app, debug = True,host='192.168.8.170' )
    # socketio.run( app, debug = True )
