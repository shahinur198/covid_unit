from os import listdir
import imageio
import numpy as np
import time
import random
import cv2


# cap = cv2.VideoCapture(0)

# Define the codec and create VideoWriter object
fourcc = cv2.VideoWriter_fourcc(*'XVID')
out = cv2.VideoWriter('output.avi',fourcc, 20.0, (1280,720))
# out = cv2.VideoWriter('output.avi', -1, 20.0, (640,480))
root_src_dir='img'
old=cv2.imread('img/2.jpg')
old = cv2.resize(old,(1280,720))
while True:
	n = random.randint(0,1)
	name=random.randint(1,10)
	path="img/"+str(n)+"/"+str(name)+".jpg"
	f = cv2.imread(path)
	f = cv2.resize(f,(1280,720))
	flg=0
	while 1:
		flg=1
		for h in range(720):
			for w in range(1280):
				# print(f[h,w])
				if f[h,w,0]-old[h,w,0]>0:
					old[h,w,0] = old[h,w,0]+1
					flg=0
				elif f[h,w,0]-old[h,w,0]<0:
					old[h,w,0] = old[h,w,0]-1
					flg=0

				if f[h,w,1]-old[h,w,1]>0:
					old[h,w,1] = old[h,w,1]+1
					flg=0
				elif f[h,w,1]-old[h,w,1]<0:
					old[h,w,1] = old[h,w,1]-1
					flg=0

				if f[h,w,2]-old[h,w,2]>0:
					old[h,w,2] = old[h,w,2]+1
					flg=0
				elif f[h,w,2]-old[h,w,2]<0:
					old[h,w,2] = old[h,w,2]-1
					flg=0
			
		out.write(old)

		cv2.imshow('frame',old)
		if cv2.waitKey(1) & 0xFF == ord('q'):
			break
		if flg == 1:
			old=f
			break


# cap.release()
out.release()
cv2.destroyAllWindows()