#!/usr/bin/python
 
import psycopg2

class Db():
    # Constructor...
    def __init__(self):

        database = "dailycaredb"
        try:
            self.conn = psycopg2.connect(database = "covid_care_db", user = "postgres", password = "test123", host = "127.0.0.1", port = "5432")

            # print(sqlite3.version)
            
        except Exception as e:
            print(e)
   
    def close_db(self):
               
        if self.conn is not None:
            
            self.conn.close()
   
    def insert_data(self, query):
        """
        Create a new Table        
        :param :
        :return: id
        """
       
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(query)
            user_id = cur.fetchone()[0]
            self.conn.commit()
            
        else:
            print("insert faild")
            return 0

        return user_id
   
    def multi_queries(self, querys):
        """
        Create a new Table        
        :param :
        :return: id
        """
       
        if self.conn is not None:
            cur = self.conn.cursor()

            for query in querys:                
                cur.execute(query)

            self.conn.commit()
            
        else:
            print("insert faild")
            return 0

        return 1

    def update_data(self, query):
        """

        : Update Table:
        :return:  id
        """
        # cur.execute('UPDATE employees SET name = "Rogers" where id = 2')

        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(query)
            self.conn.commit()
            return 1
        else:
            print("Update faild")
            return 0
    
    def get_data_by_key(self, query):
        
        """       
        :param priority:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute(query)
        rows = cur.fetchall()

        if len(rows)>0:
            pass
            return rows[0]
        else:
            return None

    def get_data(self, query):
        
        """        
        :param query:
        :return: table data
        """
        cur = self.conn.cursor()
        cur.execute(query)

        rows = cur.fetchall()
        

        return rows

#Insert tblDistrict.....

    def insert_district(self, district):
        """
        Create a new personInfo        
        :param personInfo:
        :return:
        """
        try:                              
                                                                               
            sql = " INSERT INTO tblDistrict(district,status) VALUES('"+district[0]+"','1') RETURNING district_id "
            if self.conn is not None:
                cur = self.conn.cursor()
                cur.execute(sql)
                district_id = cur.fetchone()[0]
                # district_id= cur.fetchone()[0]
                self.conn.commit()
                
            else:
                print("insert faild")
                return 0,""

            return district_id
            
        except:
            pass

    def get_all_district(self):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblDistrict where status = '1'")
        
        districts = cur.fetchall()
        # print(rows)


        return districts

    def get_district_id_by_name(self,district):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblDistrict where district = '"+district+"' ")
        
        districts = cur.fetchall()
        # print(districts)
        if len(districts)>0:
            return districts[0][0]
        else:
            return 0
        

    def get_district_id(self,district_id):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblDistrict where status = '1' AND district_id = '"+district_id+"' ")
        
        districts = cur.fetchall()
        # print(rows)


        return districts

    def get_district_details(self):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblDistrict where status = '1'")
        
        districts = cur.fetchall()
        districtlst=[]
        for district in districts:
            thanas=self.get_thanas_by_district_id(str(district[0]))
            new_district=(district,thanas)
            districtlst.append(new_district)
        # print(rows)


        return districtlst



    def update_district(self, district):
        """

        :param personInfo:
        :return:  id
        """
        
        sql = " UPDATE tblDistrict SET district = '"+district[0]+"' , status = '"+district[1]+"' WHERE district_id = '"+district[2]+"'"
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql)
            self.conn.commit()
            
        else:
            print("Update faild")

#Insert tblThana.....

    def check_thana(self,district_id,thana):
        
        """        
        :param labelling:
        :return:
        """
        sq="SELECT * FROM tblThana where status = '1' AND district_id = '"+district_id+"'  AND thana = '"+thana+"' "
        # print(sq)
        cur = self.conn.cursor()
        cur.execute(sq)
        
        thanas = cur.fetchall()
        if len(thanas)>0:
            return thanas[0][0]
        else:
            return 0;

    def insert_thana(self, thana):
        """
        Create a new personInfo        
        :param personInfo:
        :return:
        """
        # try:
        district=(thana[0],1)
        district_id =self.get_district_id_by_name(thana[0])
        print("district_id",district_id)
        if district_id == 0:
            district_id =self.insert_district(district)
        print("district_id",district_id)

        thana_id =self.check_thana(str(district_id),thana[1])

        if thana_id == 0:
            # thana_query=(district_id,thana[1],0,0,1)

            sql = " INSERT INTO tblThana(district_id,thana,longitude,latitude,status) VALUES("
            sql = sql + "'"+str(district_id)+"','"+thana[1]+"','0','0','1') RETURNING thana_id"
            if self.conn is not None:
                cur = self.conn.cursor()
                cur.execute(sql)
                thana_id= cur.fetchone()[0]
                self.conn.commit()
                
            else:
                print("insert faild")
                return 0,""

            return thana_id
            
        # except:
        #     pass

    def get_all_thana(self):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblThana where status = '1'")
        
        thanas = cur.fetchall()
        # print(rows)


        return thanas

    def get_thanas_by_district_id(self,district_id):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        try:
            if len(district_id)>2:
                # print(district_id)
                district_id = self.get_district_id_by_name(district_id)
                # print(district_id)
        except Exception as e:
            pass        
        
        cur.execute("SELECT * FROM tblThana where status = '1' AND district_id = '"+str(district_id)+"' ")
        
        thanas = cur.fetchall()
        # print(rows)


        return thanas

    def get_thana_id(self,thana_id):
        
        """        
        :param labelling:
        :return:
        """
        cur = self.conn.cursor()
        cur.execute("SELECT * FROM tblThana where status = '1' AND thana_id = '"+thana_id+"' ")
        
        thanas = cur.fetchall()
        # print(rows)


        return thanas


    def update_thana(self, thana):
        """

        :param personInfo:
        :return:  id
        """

        sql = " UPDATE tblThana SET district_id = '"+thana[0]+"', thana = '"+thana[1]+"', longitude = '"+thana[1]+"',"
        sql = sql + " latitude = '"+thana[3]+"', status = '"+thana[4]+"' WHERE thana_id = '"+thana[5]+"'"
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql)
            self.conn.commit()
            
        else:
            print("Update faild")


    def update_thana_lon_lat(self, thana):
        """

        :param personInfo:
        :return:  id
        """

        sql = " UPDATE tblThana SET longitude = '"+thana[0]+"', latitude = '"+thana[1]+"', status = '"+thana[2]+"' "
        sql = sql+ "  WHERE thana_id = '"+thana[3]+"' "
        if self.conn is not None:
            cur = self.conn.cursor()
            cur.execute(sql)
            self.conn.commit()
            
        else:
            print("Update faild")

# Create Table
    def create_table(self, create_table_sql):
        """ create a table from the create_table_sql statement
        :param conn: Connection object
        :param create_table_sql: a CREATE TABLE statement
        :return:
        """
        # print()
        try:
            c = self.conn.cursor()
            c.execute(create_table_sql)
            self.conn.commit()
        except Exception as e:
            print(e)   
    
    # Drop Table
    def drop_table(self, table_name):
        """ Drop Table
        """
        # print("create_table")
        try:
            c = self.conn.cursor()
            query="DROP TABLE IF EXISTS "+table_name+";"
            c.execute(query)
            self.conn.commit()

        except Exception as err:
            print(err)     
    
        
    # Create Database.......
    def createDb(self):
        
        user_table = """ CREATE TABLE IF NOT EXISTS tblUser (
                                            user_id serial PRIMARY KEY,
                                            key text NOT NULL,
                                            ciphered_text text NOT NULL,
                                            auth_id text NOT NULL unique,
                                            phone_number text NOT NULL unique,
                                            phone_number_verified bool NOT NULL,
                                            name text NOT NULL,
                                            gender text NOT NULL,
                                            profile_pic text,
                                            district  text,
                                            town text,
                                            village text,                                        
                                            home_longitude REAL NOT NULL,                                            
                                            home_latitude REAL NOT NULL,                                      
                                            ofice_longitude REAL NOT NULL,                                            
                                            ofice_latitude REAL NOT NULL,                                           
                                            fbuid text NOT NULL unique,
                                            create_date REAL, 
                                            status bool NOT NULL
                                        ); """

        admin_table = """ CREATE TABLE IF NOT EXISTS tblAdmin  (
                                            admin_id serial PRIMARY KEY,
                                            user_id integer NOT NULL unique,
                                            admin_type  text NOT NULL,
                                            access integer NOT NULL,
                                            create_date REAL,
                                            security_key  text NOT NULL,
                                            status bool NOT NULL
                                        ); """

        user_bank_account_table = """ CREATE TABLE IF NOT EXISTS tblUserBankAccount  (
                                            user_bank_account_id serial PRIMARY KEY,
                                            user_id integer NOT NULL unique,
                                            bank_name  text NOT NULL, 
                                            bank_account_info text NOT NULL,
                                            bank_account text NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        account_balance_table = """ CREATE TABLE IF NOT EXISTS tblAccountBalance  (
                                            account_balance_id serial PRIMARY KEY,                                            
                                            user_id integer NOT NULL unique,
                                            received  REAL NOT NULL,
                                            pay  REAL NOT NULL,
                                            update_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        payment_request_table = """ CREATE TABLE IF NOT EXISTS tblPaymentRequest  (
                                            payment_request_id serial PRIMARY KEY,                                            
                                            user_id integer NOT NULL,
                                            transaction_id  text NOT NULL unique,
                                            transaction_url  text NOT NULL,
                                            create_date REAL NOT NULL,
                                            done bool NOT NULL,
                                            status bool NOT NULL
                                        ); """

        received_money_table = """ CREATE TABLE IF NOT EXISTS tblReceivedMoney  (
                                            received_money_id serial PRIMARY KEY,                                            
                                            user_id integer NOT NULL,
                                            transaction_id  text NOT NULL unique,
                                            paymentID  text NOT NULL,
                                            createTime  REAL NOT NULL,
                                            updateTime  REAL NOT NULL,
                                            trxID  text NOT NULL,
                                            transactionStatus  text NOT NULL,
                                            amount  REAL NOT NULL,
                                            currency  text NOT NULL,
                                            intent  text NOT NULL,
                                            merchantInvoiceNumber  text NOT NULL,
                                            payment_medium  text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        pay_doctor_fee_table = """ CREATE TABLE IF NOT EXISTS tblPayDoctorFee  (
                                            pay_doctor_fee_id serial PRIMARY KEY,                                            
                                            user_id integer NOT NULL,                                            
                                            doctor_appointment_id integer NOT NULL,
                                            daily_care_charge  REAL NOT NULL,    
                                            vat_tax  REAL NOT NULL,
                                            pay_date REAL NOT NULL,
                                            status bool NOT NULL,
                                            UNIQUE(doctor_appointment_id)
                                        ); """    

        withdrawal_request_table = """ CREATE TABLE IF NOT EXISTS tblWithdrawalRequest  (
                                            withdrawal_request_id serial PRIMARY KEY,                                            
                                            user_id integer NOT NULL,
                                            withdrawal_amount  REAL NOT NULL,
                                            request_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        withdrawal_money_table = """ CREATE TABLE IF NOT EXISTS tblWithdrawalMoney  (
                                            withdrawal_money_id serial PRIMARY KEY,                                            
                                            withdrawal_request_id integer NOT NULL,                                            
                                            user_id integer NOT NULL,
                                            withdrawal_amount  REAL NOT NULL,
                                            processing_fee  REAL NOT NULL, 
                                            withdrawal_detail  text NOT NULL,                                             
                                            bank_transaction_id text NOT NULL, 
                                            withdrawal_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        doctor_table = """ CREATE TABLE IF NOT EXISTS tblDoctor  (
                                            doctor_id serial PRIMARY KEY,
                                            user_id integer NOT NULL unique,
                                            dmsi  text NOT NULL unique,
                                            degree  text NOT NULL,
                                            specialist  text NOT NULL,
                                            doctor_designation  text,
                                            doctor_workplace  text,
                                            fee_first_time integer NOT NULL,
                                            fee_next_time integer NOT NULL,
                                            doctor_shedule  text NOT NULL,
                                            one_day_max_patient integer NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        patient_table = """ CREATE TABLE IF NOT EXISTS tblPatient  (
                                            patient_id serial PRIMARY KEY,
                                            phone_number text NOT NULL,
                                            patient_name text NOT NULL,
                                            age  REAL NOT NULL,
                                            gender text NOT NULL,
                                            hight REAL,
                                            weight  REAL, 
                                            blood_group text,                                         
                                            profile_pic text,
                                            district  text,
                                            town text,
                                            village text,     
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        doctor_message_table = """ CREATE TABLE IF NOT EXISTS tblDoctorMessage  (
                                            doctor_message_id serial PRIMARY KEY,
                                            doctor_id integer NOT NULL,
                                            patient_id  text NOT NULL,
                                            message  text NOT NULL,
                                            view bool NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        patient_connection_table = """ CREATE TABLE IF NOT EXISTS tblPatientConnection  (
                                            patient_connection_id serial PRIMARY KEY,
                                            user_id integer NOT NULL,
                                            patient_id integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """  

        primary_test_table = """ CREATE TABLE IF NOT EXISTS tblPrimaryTest (
                                            primary_test_id serial PRIMARY KEY,
                                            primary_test text NOT NULL,
                                            unit text NOT NULL,
                                            about_test text NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        patient_dptr_table = """ CREATE TABLE IF NOT EXISTS tblPatientDPTR  (
                                            patient_dptr_id serial PRIMARY KEY,
                                            patient_id integer NOT NULL,
                                            primary_test_id integer NOT NULL,
                                            test_value REAL NOT NULL,
                                            report integer NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        patient_covid_test_table = """ CREATE TABLE IF NOT EXISTS tblPatientCovidTest  (
                                            patient_covid_test_id serial PRIMARY KEY,
                                            patient_id integer NOT NULL,
                                            covid_positive_date REAL,
                                            covid_negative_date REAL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        patient_symptom_group_save_table = """ CREATE TABLE IF NOT EXISTS tblPatientSymptomGroupSave  (
                                            patient_symptom_group_save_id serial PRIMARY KEY,
                                            patient_id  integer NOT NULL,
                                            symptom_group_id integer NOT NULL,
                                            create_date REAL NOT NULL
                                        ); """

        doctor_appointment_table = """ CREATE TABLE IF NOT EXISTS tblDoctorAppointment  (
                                            doctor_appointment_id serial PRIMARY KEY,
                                            doctor_id integer NOT NULL,
                                            patient_id  integer NOT NULL,
                                            symptom_group_id integer NOT NULL, 
                                            doctor_fee integer NOT NULL,
                                            appointment_time REAL NOT NULL,
                                            doctor_visited bool NOT NULL,  
                                            paid bool NOT NULL,  
                                            connecting bool NOT NULL, 
                                            room_name text,  
                                            online bool NOT NULL,
                                            user_id  integer NOT NULL,               
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        previous_rx_table = """ CREATE TABLE IF NOT EXISTS tblPreviousRx  (
                                            previous_rx_id serial PRIMARY KEY,
                                            patient_id integer NOT NULL,                                            
                                            rx_pic text,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        patient_test_report_table = """ CREATE TABLE IF NOT EXISTS tblPatientTestReport  (
                                            patient_test_report_id serial PRIMARY KEY,
                                            medical_test_rx_id integer NOT NULL, 
                                            covid_treatment_id integer NOT NULL,                                           
                                            report_urls text NOT NULL,
                                            create_date REAL,
                                            view bool NOT NULL,                                           
                                            doctor_report text,
                                            status bool NOT NULL
                                        ); """

        covid_treatment_table = """ CREATE TABLE IF NOT EXISTS tblCovidTreatment  (
                                            covid_treatment_id serial PRIMARY KEY,
                                            doctor_appointment_id integer NOT NULL,
                                            patient_id integer NOT NULL,  
                                            doctor_id integer NOT NULL,
                                            symptom_group_id integer NOT NULL, 
                                            rx_group_id integer NOT NULL,
                                            start_treatment bool NOT NULL,
                                            stop_treatment bool NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        disease_identify_table = """ CREATE TABLE IF NOT EXISTS tblDiseaseIdentify  (
                                            disease_identify_id serial PRIMARY KEY,
                                            doctor_appointment_id integer NOT NULL,
                                            disease_id integer NOT NULL,
                                            measure integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        treatment_start_table = """ CREATE TABLE IF NOT EXISTS tblTreatmentStart  (
                                            treatment_start_id serial PRIMARY KEY,
                                            covid_treatment_id integer NOT NULL,
                                            start_treatment REAL NOT NULL,
                                            stop_treatment REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        covid_treatment_result_table = """ CREATE TABLE IF NOT EXISTS tblCovidTreatmentResult  (
                                            covid_treatment_result_id serial PRIMARY KEY,
                                            covid_treatment_id integer NOT NULL,
                                            symptom_id integer NOT NULL,
                                            measure integer NOT NULL,  
                                            user_msg text NOT NULL,
                                            new_symptom bool NOT NULL, 
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        patient_daily_medicine_table = """ CREATE TABLE IF NOT EXISTS tblPatientDailyMedicine (
                                            patient_daily_medicine_id serial PRIMARY KEY,
                                            covid_treatment_id integer NOT NULL,
                                            medicine_id integer NOT NULL,
                                            medicine_taken integer NOT NULL,
                                            report_date date,
                                            status bool NOT NULL
                                        ); """

        patient_daily_food_table = """ CREATE TABLE IF NOT EXISTS tblPatientDailyFood (
                                            patient_daily_food_id serial PRIMARY KEY,
                                            covid_treatment_id integer NOT NULL,
                                            food text NOT NULL,
                                            food_taken integer NOT NULL,
                                            report_date date,
                                            status bool NOT NULL
                                        ); """ 

        patient_daily_exercise_table = """ CREATE TABLE IF NOT EXISTS tblPatientDailyExercise (
                                            patient_daily_exercise_id serial PRIMARY KEY,
                                            covid_treatment_id integer NOT NULL,
                                            exercise text NOT NULL,
                                            exercise_taken integer NOT NULL,
                                            report_date date,
                                            status bool NOT NULL
                                        ); """

        public_treatment_table = """ CREATE TABLE IF NOT EXISTS tblPublicTreatment  (
                                            public_treatment_id serial PRIMARY KEY,
                                            doctor_id integer NOT NULL,
                                            symptom_group_id integer NOT NULL, 
                                            rx_group_id integer NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        disease_table = """ CREATE TABLE IF NOT EXISTS tblDisease  (
                                            disease_id serial PRIMARY KEY,
                                            disease  text NOT NULL,
                                            disease_en  text,
                                            body_area  text,
                                            approved bool NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        symptom_table = """ CREATE TABLE IF NOT EXISTS tblSymptom  (
                                            symptom_id serial PRIMARY KEY,
                                            symptom  text NOT NULL,
                                            body_area  text,
                                            approved bool NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        symptom_group_table = """ CREATE TABLE IF NOT EXISTS tblSymptomGroup  (
                                            symptom_group_id serial PRIMARY KEY,
                                            group_name  text NOT NULL, 
                                            gender  text NOT NULL,
                                            from_age REAL NOT NULL,
                                            to_age REAL NOT NULL, 
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        previous_disease_table = """ CREATE TABLE IF NOT EXISTS tblPreviousDisease  (
                                            previous_disease_id serial PRIMARY KEY,
                                            disease_id integer NOT NULL,
                                            present bool NOT NULL,
                                            medicine bool NOT NULL,
                                            measure integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        previous_disease_group_table = """ CREATE TABLE IF NOT EXISTS tblPreviousDiseaseGroup  (
                                            previous_disease_group_id serial PRIMARY KEY,                                            
                                            symptom_group_id integer NOT NULL,                                            
                                            previous_disease_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        covid_symptom_table = """ CREATE TABLE IF NOT EXISTS tblCovidSymptom  (
                                            covid_symptom_id serial PRIMARY KEY,
                                            symptom_id integer NOT NULL,
                                            measure integer NOT NULL,
                                            symptom_days integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        covid_symptom_group_table = """ CREATE TABLE IF NOT EXISTS tblCovidSymptomGroup  (
                                            covid_symptom_group_id serial PRIMARY KEY,                                            
                                            symptom_group_id integer NOT NULL,                                            
                                            covid_symptom_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        test_report_table = """ CREATE TABLE IF NOT EXISTS tblTestReport  (
                                            test_report_id serial PRIMARY KEY,
                                            test_name text NOT NULL,
                                            min_value integer NOT NULL,
                                            max_value integer NOT NULL,
                                            report_result integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        test_report_group_table = """ CREATE TABLE IF NOT EXISTS tblTestReportGroup  (
                                            test_report_group_id serial PRIMARY KEY,                                            
                                            symptom_group_id integer NOT NULL,                                            
                                            test_report_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        rx_group_table = """ CREATE TABLE IF NOT EXISTS tblRxGroup  (
                                            rx_group_id serial PRIMARY KEY,
                                            symptom_group_id integer NOT NULL,  
                                            doctor_id integer NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        food_rx_table = """ CREATE TABLE IF NOT EXISTS tblFoodRx  (
                                            food_rx_id serial PRIMARY KEY,
                                            food text NOT NULL,
                                            rules text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """  

        food_rx_group_table = """ CREATE TABLE IF NOT EXISTS tblFoodRxGroup  (
                                            food_rx_group_id serial PRIMARY KEY,                                            
                                            rx_group_id integer NOT NULL,                                            
                                            food_rx_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        medicine_rx_table = """ CREATE TABLE IF NOT EXISTS tblMedicineRx  (
                                            medicine_rx_id serial PRIMARY KEY, 
                                            medicine_id integer NOT NULL,
                                            daily_schedule_id integer NOT NULL,
                                            befor_eating_id integer NOT NULL,
                                            days_number integer NOT NULL,
                                            days_unit text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """  

        medicine_rx_group_table = """ CREATE TABLE IF NOT EXISTS tblMedicineRxGroup  (
                                            medicine_rx_group_id serial PRIMARY KEY,                                            
                                            rx_group_id integer NOT NULL,                                            
                                            medicine_rx_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """            

        exercise_rx_table = """ CREATE TABLE IF NOT EXISTS tblExerciseRx  (
                                            exercise_rx_id serial PRIMARY KEY, 
                                            exercise text NOT NULL,
                                            rules text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """  

        exercise_rx_group_table = """ CREATE TABLE IF NOT EXISTS tblExerciseRxGroup  (
                                            exercise_rx_group_id serial PRIMARY KEY,                                             
                                            rx_group_id integer NOT NULL,                                          
                                            exercise_rx_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        extend_rx_table = """ CREATE TABLE IF NOT EXISTS tblExtendRx  (
                                            extend_rx_id serial PRIMARY KEY,
                                            extend_guide text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        extend_rx_group_table = """ CREATE TABLE IF NOT EXISTS tblExtendRxGroup  (
                                            extend_rx_group_id serial PRIMARY KEY,                                              
                                            rx_group_id integer NOT NULL,                                            
                                            extend_rx_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        medical_test_rx_table = """ CREATE TABLE IF NOT EXISTS tblMedicalTestRx  (
                                            medical_test_rx_id serial PRIMARY KEY,
                                            medical_test text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        medical_test_rx_group_table = """ CREATE TABLE IF NOT EXISTS tblMedicalTestRxGroup  (
                                            medical_test_rx_group_id serial PRIMARY KEY,                                              
                                            rx_group_id integer NOT NULL,                                            
                                            medical_test_rx_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        reminded_rx_table = """ CREATE TABLE IF NOT EXISTS tblRemindedRx  (
                                            reminded_rx_id serial PRIMARY KEY,
                                            reminded_guide text NOT NULL,
                                            reminded_time REAL NOT NULL,                                            
                                            period integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """  

        reminded_rx_group_table = """ CREATE TABLE IF NOT EXISTS tblRemindedRxGroup  (
                                            reminded_rx_group_id serial PRIMARY KEY,                                            
                                            rx_group_id integer NOT NULL,                                            
                                            reminded_rx_id integer NOT NULL,
                                            status bool NOT NULL
                                        ); """

        covid_hospital_table = """ CREATE TABLE IF NOT EXISTS tblCovidHospital  (
                                            covid_hospital_id serial PRIMARY KEY,
                                            covid_hospital  text NOT NULL,                                             
                                            icu_bed integer NOT NULL,                                       
                                            longitude REAL NOT NULL,                                            
                                            latitude REAL NOT NULL, 
                                            address text NOT NULL, 
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        movement_location_table = """ CREATE TABLE IF NOT EXISTS tblMovementLocation  (
                                            movement_location_id serial PRIMARY KEY,        
                                            longitude REAL NOT NULL,                                            
                                            latitude REAL NOT NULL,
                                            covid integer NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        notification_table = """ CREATE TABLE IF NOT EXISTS tblNotification   (
                                            notification_id serial PRIMARY KEY,
                                            user_id integer NOT NULL,
                                            subject  text NOT NULL,
                                            notification  text NOT NULL,
                                            create_date REAL NOT NULL,
                                            read bool NOT NULL,
                                            status bool NOT NULL
                                        ); """


        medicine_dosage_forms_table = """ CREATE TABLE IF NOT EXISTS tblMedicineDosageForms (
                                            medicine_dosage_forms_id serial PRIMARY KEY,
                                            dosage_form text NOT NULL,
                                            detail text NOT NULL,
                                            short_form text NOT NULL,
                                            status bool NOT NULL
                                        ); """

        medicine_table = """ CREATE TABLE IF NOT EXISTS tblMedicine (
                                            medicine_id serial PRIMARY KEY,
                                            generic_medicine_name text NOT NULL,
                                            brand_medicine_name text NOT NULL,
                                            medicine_dosage_form text NOT NULL,
                                            strength text NOT NULL,
                                            brand_name text NOT NULL,
                                            status bool NOT NULL
                                        ); """

        medicine_details_table = """ CREATE TABLE IF NOT EXISTS tblMedicineDetails (
                                            medicine_details_id serial PRIMARY KEY,
                                            medicine_id integer NOT NULL,
                                            brand_name text NOT NULL,
                                            uses text NOT NULL,
                                            side_effects text NOT NULL,
                                            history text NOT NULL,
                                            image_url text NOT NULL,
                                            status bool NOT NULL
                                        ); """

        daily_schedule_table = """ CREATE TABLE IF NOT EXISTS tblDailySchedule (
                                            daily_schedule_id serial PRIMARY KEY,
                                            daily_schedule text NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        befor_eating_table = """ CREATE TABLE IF NOT EXISTS tblBeforEating (
                                            befor_eating_id serial PRIMARY KEY,
                                            befor_eating text NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        medical_test_table = """ CREATE TABLE IF NOT EXISTS tblMedicalTest (
                                            medical_test_id serial PRIMARY KEY,
                                            medical_test text NOT NULL,
                                            about_test text NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        food_table = """ CREATE TABLE IF NOT EXISTS tblFood (
                                            food_id serial PRIMARY KEY,
                                            food text NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        food_rule_table = """ CREATE TABLE IF NOT EXISTS tblFoodRule (
                                            food_rule_id serial PRIMARY KEY,                                           
                                            food_id integer NOT NULL,
                                            food_rule text NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        exercise_table = """ CREATE TABLE IF NOT EXISTS tblExercise (
                                            exercise_id serial PRIMARY KEY,
                                            exercise text NOT NULL,
                                            status bool NOT NULL
                                        ); """  

        exercise_rule_table = """ CREATE TABLE IF NOT EXISTS tblExerciseRule (
                                            exercise_rule_id serial PRIMARY KEY,                                           
                                            exercise_id integer NOT NULL,
                                            exercise_rule text NOT NULL,
                                            status bool NOT NULL
                                        ); """

        extend_table = """ CREATE TABLE IF NOT EXISTS tblExtend (
                                            extend_id serial PRIMARY KEY,
                                            extend text NOT NULL,
                                            status bool NOT NULL
                                        ); """

        daily_care_center_table = """ CREATE TABLE IF NOT EXISTS tblDailyCareCenter  (
                                            daily_care_center_id serial PRIMARY KEY,
                                            daily_care_center  text NOT NULL,                                        
                                            district text NOT NULL,                                            
                                            thana text NOT NULL, 
                                            place text NOT NULL, 
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        employee_table = """ CREATE TABLE IF NOT EXISTS tblEmployee  (
                                            employee_id serial PRIMARY KEY,
                                            user_id integer NOT NULL unique,
                                            designation  text NOT NULL,
                                            grade integer NOT NULL,
                                            cv_pdf  text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        employee_posting_table = """ CREATE TABLE IF NOT EXISTS tblEmployeePosting  (
                                            employee_posting_id serial PRIMARY KEY,
                                            employee_id integer NOT NULL,
                                            daily_care_center_id integer NOT NULL,
                                            designation text NOT NULL,
                                            posting_date text NOT NULL,
                                            resignation_date text NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """ 

        doctor_fee_collection_table = """ CREATE TABLE IF NOT EXISTS tblDoctorFeeCollection  (
                                            doctor_fee_collection_id serial PRIMARY KEY,
                                            employee_id integer NOT NULL,
                                            daily_care_center_id integer NOT NULL,
                                            doctor_appointment_id integer NOT NULL,
                                            daily_care_charge REAL NOT NULL,
                                            amount REAL NOT NULL,
                                            create_date REAL NOT NULL,
                                            status bool NOT NULL
                                        ); """

        help_question_table = """ CREATE TABLE IF NOT EXISTS tblHelpQuestion  (
                                            help_question_id serial PRIMARY KEY,
                                            user_id integer NOT NULL,                                            
                                            help_type  text NOT NULL,                                            
                                            message  text NOT NULL,
                                            answered bool NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        survey_patient_table = """ CREATE TABLE IF NOT EXISTS tblSurveyPatient  (
                                            survey_patient_id serial PRIMARY KEY,
                                            patient_id integer NOT NULL UNIQUE,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        family_patient_table = """ CREATE TABLE IF NOT EXISTS tblFamilyPatient  (
                                            family_patient_id serial PRIMARY KEY,
                                            survey_patient_id integer NOT NULL,
                                            patient_id integer NOT NULL UNIQUE,
                                            family_lead bool NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """ 

        survey_symptom_table = """ CREATE TABLE IF NOT EXISTS tblSurveySymptom  (
                                            survey_symptom_id serial PRIMARY KEY,
                                            symptom_id integer NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        survey_treatment_table = """ CREATE TABLE IF NOT EXISTS tblSurveyTreatment  (
                                            survey_treatment_id serial PRIMARY KEY,                            
                                            survey_treatment  text NOT NULL,                                            
                                            rules  text NOT NULL,
                                            create_date REAL,
                                            status bool NOT NULL
                                        ); """

        survey_symptom_report_table = """ CREATE TABLE IF NOT EXISTS tblSurveySymptomReport  (
                                            survey_symptom_report_id serial PRIMARY KEY,
                                            patient_id integer NOT NULL,
                                            symptom_id integer NOT NULL,
                                            symptom_level integer NOT NULL,
                                            report_date date,
                                            status bool NOT NULL
                                        ); """ 

        survey_treatment_report_table = """ CREATE TABLE IF NOT EXISTS tblSurveyTreatmentReport  (
                                            survey_treatment_report_id serial PRIMARY KEY,
                                            patient_id integer NOT NULL,
                                            survey_treatment_id integer NOT NULL,
                                            taken integer NOT NULL,
                                            report_date date,
                                            status bool NOT NULL
                                        ); """ 

        body_area_table = """ CREATE TABLE IF NOT EXISTS tblBodyArea  (
                                            body_area_id serial PRIMARY KEY,
                                            body_area text NOT NULL,
                                            status bool NOT NULL
                                        ); """
                                         
        
        # tblDistrict..........
        district_table = """ CREATE TABLE IF NOT EXISTS tblDistrict (
                                            district_id serial PRIMARY KEY,
                                            district text NOT NULL UNIQUE,
                                            status bool NOT NULL
                                        ); """
        
        # tblThana..........
        thana_table = """ CREATE TABLE IF NOT EXISTS tblThana (
                                            thana_id serial PRIMARY KEY,                                            
                                            district_id integer NOT NULL,
                                            thana text NOT NULL,                                            
                                            longitude float NOT NULL,                                            
                                            latitude float NOT NULL,
                                            status bool NOT NULL
                                        ); """
        
        # tblThana..........
        village_table = """ CREATE TABLE IF NOT EXISTS tblVillage (
                                            village_id serial PRIMARY KEY,                                            
                                            thana_id integer NOT NULL,
                                            village text NOT NULL,                                            
                                            longitude float NOT NULL,                                            
                                            latitude float NOT NULL,
                                            status bool NOT NULL
                                        ); """



        if self.conn is not None:        
            # create person info table 
               
            # self.drop_table("tblPrimaryTest")
            # self.drop_table("tblSurveyTreatment")
            # self.drop_table("tblSurveySymptomReport")
            # self.drop_table("tblSurveyTreatmentReport")
            # self.drop_table("tblMedicine")
            self.create_table(help_question_table)
            self.create_table(district_table)
            self.create_table(thana_table)
            self.create_table(village_table)
            self.create_table(user_table)
            self.create_table(admin_table)
            self.create_table(employee_table)

            self.create_table(account_balance_table) 

            self.create_table(user_bank_account_table)
            self.create_table(payment_request_table)
            self.create_table(received_money_table)
            self.create_table(pay_doctor_fee_table)
            self.create_table(withdrawal_request_table)
            self.create_table(withdrawal_money_table)

            self.create_table(doctor_table)
            self.create_table(patient_table)
            self.create_table(patient_connection_table) 
            self.create_table(patient_covid_test_table)
            self.create_table(doctor_appointment_table)
            self.create_table(previous_rx_table)
            self.create_table(covid_treatment_table)
            self.create_table(covid_treatment_result_table)
            self.create_table(public_treatment_table)
            self.create_table(treatment_start_table)
            self.create_table(symptom_table)
            self.create_table(disease_table)
            self.create_table(symptom_group_table)
            self.create_table(patient_symptom_group_save_table);


            self.create_table(disease_identify_table)
            
            self.create_table(previous_disease_table)
            self.create_table(covid_symptom_table)
            self.create_table(test_report_table)                                           
            self.create_table(previous_disease_group_table)
            self.create_table(covid_symptom_group_table)
            self.create_table(test_report_group_table)

            self.create_table(primary_test_table)
            self.create_table(patient_dptr_table)

            self.create_table(rx_group_table)
            self.create_table(food_rx_table)
            self.create_table(medicine_rx_table)
            self.create_table(exercise_rx_table)
            self.create_table(extend_rx_table)
            self.create_table(medical_test_rx_table)
            self.create_table(reminded_rx_table)

            self.create_table(food_rx_group_table)
            self.create_table(medicine_rx_group_table)
            self.create_table(exercise_rx_group_table)
            self.create_table(extend_rx_group_table)
            self.create_table(medical_test_rx_group_table)
            self.create_table(reminded_rx_group_table)

            self.create_table(patient_test_report_table)
              
            self.create_table(daily_care_center_table)                   
            self.create_table(employee_table)
            self.create_table(employee_posting_table)
            self.create_table(doctor_fee_collection_table)
         
    
            self.create_table(covid_hospital_table)
            self.create_table(movement_location_table)            
            
            self.create_table(notification_table) 

            self.create_table(medicine_dosage_forms_table)
            self.create_table(medicine_table)
            self.create_table(daily_schedule_table)  
            self.create_table(befor_eating_table) 

            self.create_table(medical_test_table)
            self.create_table(food_table)
            self.create_table(food_rule_table)  
            self.create_table(exercise_table) 
            self.create_table(exercise_rule_table)
            self.create_table(extend_table)  

            self.create_table(patient_daily_medicine_table)
            self.create_table(patient_daily_food_table)
            self.create_table(patient_daily_exercise_table)

            self.create_table(doctor_message_table)

            self.create_table(survey_patient_table)
            self.create_table(family_patient_table)
            self.create_table(survey_symptom_table)
            self.create_table(survey_treatment_table)
            self.create_table(survey_symptom_report_table)
            self.create_table(survey_treatment_report_table)

            self.create_table(body_area_table)

                 

    

        else:
            print("Error! cannot create the database connection.")

    